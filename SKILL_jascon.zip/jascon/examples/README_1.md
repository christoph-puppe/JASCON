# JASCON — Example Bundle (one file per type)
### Companion to Specification v0.5 and the Handbook · illustrative, 2026-07-18

This bundle contains **one worked example file for every JASCON
type**, wired together as a single, closed, cross-referentially
consistent package — the same running story the Handbook tells
(KONF.14.1, the Acme SaaS on a PaaS, finding 017).

## Coverage: the eleven types + sub-objects + bundle artifacts

*Check (type 11) belongs to kernel 2.0.0 since the author's decisions of
2026-11-12 (`drafts/CP-CHECK-1.md` §13); 2.0.0 is a release candidate
and not tagged. Its rows are marked (2.0.0) below.*

| # | Type | File | Demonstrates |
|---|---|---|---|
| 1 | Requirement | `req-konf-14-1.json` | multi-statement clause split (s1 provider / s2 customer), choice parameter + bound `{param:}` token, aliases, framework facet, annotations |
| 1b | Requirement (pure kernel) | `req-ism-1234.json` | the zero-facet minimum |
| 1c | Requirement (deadline) | `req-iec-cso-iir.json` | `calendar-period` parameter with `tightening: lower`, relations, annotations |
| 2 | RequirementSet | `set-crypto.json`, `set-baseline.json` | nesting (set-in-set), `sequence`, **multi-authority membership** (safe under global identity) |
| 3 | Tailoring | `tailoring-elevated.json` | set selection; identity-addressed ops: monotone `set-modality` (KANN→MUSS, no Deviation needed) and in-bounds `set-parameter` |
| 4 | Mapping | `mapping-konf-ism.json` | third-party crosswalk with statement scope, honest `supports`, provenance |
| 5 | Component | `component-paas.json`, `component-acme-saas.json` | identified `authorizations[]`; members + capabilities *(rc.4)* the PaaS authorization carries its `date`. |
| 6 | Implementation | `implementation-acme-konf.json` | per-clause `statement-refs`, shared responsibility, capability + `inherited-from` with **basis-ref → authorization id** |
| 7 | Assessment | `assessment-2026q3.json` | facet-typed method (stdlib `assessment-criteria@1`), subjects, result |
| 8 | Finding | `finding-017.json` | statement-scoped finding, calendar-aware action, **Deviation sub-object** (false-positive, approved) *(rc.4)* `provenance` on the Finding; the Deviation says when it was `decided` and carries a `review-due`. |
| 10 | Risk | `risk-acme-kms-key-rotation.json` | treated Risk on a BSI 200-3 scale, G 0.x threat refs, **treats KONF.14.1 s2** (the clause finding 017 is against — which now carries `risk-refs`), CISO acceptance of the residual, 12-month calendar review; `risk-coverage` on this bundle: 3 selected, 1 justified, 2 uncovered *(rc.4)* `provenance` on the Risk (the CISO) and another on its `rating` (who assessed). |
| 11 *(2.0.0)* | Check | `check-acme-ssh-maxauthtries.json`, `check-acme-ssh-ciphers.json` | typed fact contract (`observes`) + closed comparators (`criteria`); s1 binds `{"param": "max-auth-tries"}` with `at-most` (the parameter tightens lower - CHECK-5); s2 uses `matches-not` with the I-Regexp `.*-cbc` over a list fact; one fact contract, **two collectors** (bash, python) in `collector@1` |
| 1d *(2.0.0)* | Requirement + Set + Tailoring | `req-acme-lnx-ssh-1.json`, `set-acme-linux.json`, `tailoring-acme-linux-prod.json` | Acme's own SSH clause pair; the production Tailoring binds `max-auth-tries` = 4, and that bound value is what both runs used (CHECK-12) *(rc.4)* The Tailoring names its author, and its one operation names another. |
| 5b *(2.0.0)* | Component | `component-acme-bastion.json` | the host under test |
| 7b *(2.0.0)* | Assessment (automated runs) | `assessment-acme-bastion-2026-11-03.json`, `assessment-acme-bastion-2026-11-10.json` | `check-results`: observation inline, verdict **recomputed** by the validator (CHECK-9), result = aggregate (CHECK-10), `tailoring-ref`, `evidence-record` per row; run 1 fails s2 (`aes128-cbc` offered), run 2 passes |
| 8b *(2.0.0)* | Finding | `finding-acme-bastion-ssh-cbc.json` | raised by a check (`check-ref`, CHECK-14), closed after the 2026-11-10 run (related) |
| — *(2.0.0)* | Evidence store | `evidence/sha256/<hex>` | content-addressed blobs beside the manifest, never listed in it: 4 evidence records + 3 collector outputs (the identical MaxAuthTries output of both runs is stored once). Flip a byte and CHECK-15 fails; delete a raw output and the validator reports it *withheld* |
| 5c *(2.0.0)* | Component (a vendor's, imported) | `component-dbvendor-server-7.json` | CP-ADVICE-1: `product-version: "7"` and three recommendations as capabilities - `cap-tls` on KONF.14.1 **s1** with the suggested value `transport-crypto: tls13`, `cap-key-rotation` on **s2**, `cap-audit-log` against a requirement this bundle does not hold (resolves-if-present: a note, not an error). Byte for byte the object of the published pack |
| — *(2.0.0)* | Kept pack manifest | `packs/sha256/<hex>` | the vendor's manifest as it arrived, named by the SHA-256 of its bytes, beside the manifest and never listed in it. It is the import record: publisher, release 3, the one object and its digests (ADVICE-8..10). Edit the vendor's Component and ADVICE-9 names it |
| 6b *(2.0.0)* | Implementation (adopts advice) | `implementation-acme-konf-14-1-s2.json` | `capability-ref` in the form `<component-id>#<capability-id>`: Acme's edge, on Acme's component, cites the vendor's recommendation. `component-acme-saas.json` lists the product as a member, which ADVICE-7 requires |
| 9b *(2.0.0)* | Attestation (the vendor's) | `attestation-dbvendor-server-7-advice.json` + `.dsse` | binds the digest of the kept manifest; the validator reports the pack's publisher **proven** (with `--trusted-keys`: signature verified). Signed with the corpus FIXTURE key, whose seed is public - the mechanism, not a vendor |
| — *(2.0.0)* | The published pack | `../example-packs/dbvendor-server-7-advice/` | the file a vendor publishes: a bundle whose manifest carries the pack header and lists Components only. `validate_core.py --import-advice jascon/examples jascon/example-packs/dbvendor-server-7-advice` answers *already-imported* |
| 9 | Attestation | `attestation-acme-2026.json` | subject **semantic** digests, content-manifest binding, rendering block — *beside* the manifest, never inside |
| — | Content manifest | `content-manifest.json` | both digests per object, exact-pinned facet schemas, rendering digest |
| — | Facet descriptors | `gspp-taxonomy-1.0.0.json`, `assessment-criteria-1.0.0.json` | a custom facet descriptor, and a stdlib descriptor pinned **verbatim** (D26) |
| — | Rendering (L4) | `authorization-summary.md` | the "document as view", digest-bound by the attestation |

## Self-consistency properties (deliberate)

- **Closed object references.** Every object-to-object `ref` resolves
  inside this bundle via the manifest — sealed-mode friendly.
- **Real digests — and now checked.** All `package-digest` values are
  true SHA-256 over the file bytes as shipped (LF line endings, the bytes
  inside the skill zip; `.gitattributes` keeps a Windows checkout from
  re-spelling them). All `semantic-digest` values are SHA-256 over the
  canonicalized object **minus `annotations`**. `validate_core.py`
  verifies this manifest on every run. *Correction (2026-11-10):* it did
  not before, and at 1.0.0 the claim above was false for every checkout —
  8 of the 12 package digests matched CRLF bytes and 4 matched LF bytes.
  Canonicalization note: computed with a JCS-compatible serialization
  (sorted keys, minimal separators, UTF-8, no escaping of non-ASCII)
  — exact for this content, which contains **no floating-point
  numbers and only ASCII keys**; a full RFC 8785 implementation is a
  v0.6-gate deliverable. Empty-omission is satisfied by construction:
  no empty optional arrays/objects were authored.
- **The digests teach.** `req-konf-14-1` and `req-iec-cso-iir` carry
  annotations, so their package- and semantic-digests differ —
  strip the annotations, and the semantic digest still matches
  (Chapter 11's Semantic Match, reproducible by hand).
- **The boundary rule is satisfied.** The implementation's
  `inherited-from` names the PaaS's specific authorization id;
  delete `basis-ref` to reproduce the Chapter 9 fail-closed case.
- **The tailoring is deviation-free on purpose.** Both operations are
  lawful without a Deviation (monotone modality move; in-choice-set
  parameter). Change `set-modality` to `may` against a `must` source,
  or `value` to `"md5"`, to produce the Chapter 6 violations.

## Illustrative caveats (read before reuse)

1. **Namespaces mirror the Handbook's worked examples** (BSI, ACSC,
   FedRAMP, example.org hosts). They are *illustrative*, not official
   publications of those authorities.
2. **ISM-1234's prose is invented** for the example; the real ISM
   control text is not reproduced here.
3. **Party / authority / performer identifiers are used as codes**
   (spec: code-or-ref) — no party objects are bundled.
4. **The calendar is deliberately not bundled.** `calendar-period`
   values are *representable* here but not *computable* — a conformant
   tool asked to do date arithmetic must fail closed (Handbook §10.4).
   This is pedagogy, not an omission.
5. **`assessment-criteria` is pinned verbatim.**
   `assessment-criteria-1.0.0.json` is a byte copy of the normative
   descriptor `schemas/stdlib/assessment-criteria-1.0.0.json`: a pin of a
   stdlib facet id is the descriptor, nothing else (D26). *Correction
   (2026-11-10):* until then this folder pinned an illustrative stub
   under the stdlib id, announced as a placeholder "until the v0.6 gate".
   The normative schema has since shipped (`schemas/stdlib/`), the stub
   stayed, and its schema differed from the descriptor. `validate_core.py jascon/examples`
   failed it; the default run did not, because the example pass checked
   only the pin's digest. Both now load pins with one function. The
   assessment's `summary` became a language map with it: the normative
   schema types `summary` as an object, the stub had typed it as a string.
6. **The attestation is illustrative end to end.** Its
   `template-ref.digest` is a marked placeholder, the DSSE **envelope is
   out of scope** (`envelope-ref` points at a path not included), and —
   not marked until 2026-11-10 — its three `subject-semantic-digests` and
   its `content-manifest-digest` **match no object and no manifest in this
   folder** (they predate the `text` primitive re-run). It shows the
   *shape* of an attestation; it binds nothing here. Making it real, and
   having the validator hold it to that, is backlog #46.
7. One rendering stands in for real deliverables; real bundles list
   as many as they ship.
8. **The check runs assessed no real host.** No runner exists yet
   (CP-CHECK-1 phase 2). The evidence was produced by executing each
   Check's bash collector source *unchanged* against a stub `sshd` that
   prints a fixed configuration; every evidence record says so in its
   `note`. The bytes, digests and verdicts are real; the host is not.
9. **The Risk now names its Tailoring** (`tailoring-refs`, 2026-11-11):
   with the Linux Tailoring this bundle holds two, and RISK-14 asks a
   Risk to say which Statement of Applicability its treatment belongs to.

## Suggested uses

Feed single files to cross-model reviewers; hand the whole bundle to a
prototype validator (Handbook Ch. 12's milestones map 1:1 onto what is
checkable here); break it on purpose using the recipes above to watch
fail-closed behave.
