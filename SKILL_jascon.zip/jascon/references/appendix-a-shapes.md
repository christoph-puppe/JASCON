# The JASCON Handbook
# Appendix A — Shapes Reference

**Purpose:** the eleven types, two sub-objects, and bundle artifacts,
field by field — with the evidence column that makes this appendix
different from a schema dump: which measured corpus reality each field
answers to. Counts cite the three-authority census and the gate-item-1
converter runs (ISM 36,161 · BSI 49,804 · CR26 7,294 leaf values, all
at 100 % declared coverage).
**Convention:** ● required · ○ optional. Field names are normative;
prose here is explanatory, the conformance corpus is definitive.

---

## A.0 Common fields (every object)

| Field | | Type | Meaning & evidence |
|---|---|---|---|
| `id` | ● | URI string | Globally unique, authority-minted, never resolved by tools (string comparison only, D2). Evidence: the twin-catalog collision — 11 shared id strings across two BSI publications, only 1 prose-identical. |
| `version` | ● | string | Object-level version; format is the authority's (dates, semver, timestamps all observed). Absorbs `revision`/`updated` props (ISM ×2,202; CR26 `updated[]` ×377+). |
| `label` | ○ | string | Human display handle. Evidence: ISM `label` ×49 + 1,101 id-derived; BSI group labels ×162; CR26 rule ids as labels. |
| `aliases` | ○ | [{scheme, value}] | Other names, with provenance. Absorbs `alt-identifier` (BSI ×1,219 incl. params), FRD `alts` (×188, in-payload). |
| `lifecycle` | ● | code (A → C.2) | draft · active · deprecated · withdrawn. |
| `title` | ○ | text | Display title — `text` = `{BCP-47: string}` (#12 delivered; D9 rev 2: EU standards must be available in all 27 official languages). All kernel human-readable fields (title, rationale, description) are `text`; identifiers and labels stay strings. |
| `relations` | ○ | [{type, ref}] | Typed outbound links: base codes `related`, `required`, `uses-term`, `reference`, `schema` (C.8; `supersedes` removed v0.6 — backlog #20); extension types SHOULD be namespaced URIs (schema constraint pending the converter rerun that migrates the corpus's bare-word `sharpens` ×28). Evidence: BSI links ×197+67; CR26 `related` ×23, `schema` ×24, `terms` ×222. |
| `facets` | ○ | {facet-uri@major: payload} | Registered extensions; schema-pinned via manifest; semantics per declaration (D10). |
| `annotations` | ○ | {string: any} | Chrome. Compliance-invisible, digest-excluded, strippable. Evidence: `web_name`, `do_not_link` (CR26). |

**Canonical-alias & replaces** (identity events, on the *new* object):
`canonical-alias` ○ {of: URI} — same content, new home (rebrand/domain
loss). `replaces` ○ [{ref, mode}] with mode ∈ revised · split-from ·
merged-into · renamed — content-lineage events. Evidence: the
registry-rot corpse; ISM's own OCR→ISM renumbering history.

---

## A.1 Requirement

| Field | | Type | Meaning & evidence |
|---|---|---|---|
| `statements` | ● | [Statement] | The clause layer. Evidence: 347 BSI nested pseudo-controls (nesting measured to depth 3–4) → 1,015 statements in the converted bundle. |

**Statement:**

| Field | | Type | Meaning & evidence |
|---|---|---|---|
| `id` | ● | string | Unique within the Requirement; stable and citable (tailoring ops, findings, mapping scopes, statement-refs all address it). Converters mint `smt` for the own-clause, child-control ids for flattened clauses. |
| `modality` | ● | code (C.1 lattice) | unspecified · may · should · must · should-not · must-not · may-only. Evidence: BSI `modal_verb` ×1,006 (should 626 / may 225 / must 155); CR26 `force` 246 layered; ISM structurally modal-free → honest `unspecified` ×1,149. |
| `obligated-parties` | ● | [code/ref] | Who the clause binds. Evidence: CR26 `affects[]` (Providers 159 / Agencies 24 / Assessors 23 / FedRAMP 16 / Advisors 3); BSI/ISM: documented single-party defaults. |
| `parameters` | ○ | [Parameter] | Declared insertion points; prose references them as `{param:name}` — an unbound token is a validation error (`prose-params-resolve`). |
| `prose` | ● | text | The normative text — `text` = `{BCP-47: string \| [string]}` (the #12 primitive; formerly named langMap). |

**Parameter algebra (D9/D14):** every parameter carries `name` ● and
`type` ●, optionally `label` ○ (display handle — never an identifier,
never compared) and `default` ○ (advisory, type-valid; resolution
never substitutes it silently — binding is `set-parameter`-only), plus
type-specific fields —

| type | extra fields | evidence |
|---|---|---|
| `string` | — | BSI params ×147 (label/default first-class since the v0.6 cycle — D9 rev, backlog #1; the L2 `param-extras` residue ×179 drains at the next converter run). |
| `choice` | `choices[]{value,label}` ●, `cardinality` (one \| many) | the fused-alternatives lesson ("TLS 1.3 *oder* …"). |
| `integer` | `min?`, `max?` | ODP bounds. An integer is in the number domain: plain digits, magnitude at most 2^53 − 1 (NUMBER-1, D3.9); a larger quantity is a `decimal`. |
| `decimal` | canonical **string** value, `min?`, `max?` | JCS float hazard (D3). |
| `elapsed-duration` | `num` ●, `unit` ● ∈ seconds·minutes·hours | CR26 clocks that run through weekends. |
| `calendar-period` | `num` ●, `unit` ● ∈ days·bizdays·weeks·months·years, `calendar-ref` ● | CR26 bizdays; fail-closed without the calendar. True unit-class crossings measured: **0** (51 first-pass flags were base-absent variants, resolved by the D13 rev — authority-tier ceremony; duration-union question closed no-change, backlog #3). |
| `uri`, `date` | — | declared; not yet corpus-exercised. |

Any parameter may declare `tightening` ∈ lower · higher · none —
which direction counts as stricter (deadlines: lower).

---

## A.2 RequirementSet

| Field | | Type | Meaning & evidence |
|---|---|---|---|
| `members` | ● | [{ref ●, sequence ○}] | Refs to Requirements **or Sets** (nesting = taxonomy & composition, D21). Evidence: membership was the #1 prop imitation — ISM applicability ×5,301 + E8 ×256; BSI sec_level ×998; CR26 subsets/classes/types — all now Sets (589 across the three bundles). `sequence` absorbs sort-id ×2,870. |

Sets-of-sets composition measured live: CR26 class Sets (a–d) and
track Sets (20x/Rev5) are built purely from subset-Set members.

---

## A.3 Tailoring

| Field | | Type | Meaning & evidence |
|---|---|---|---|
| `selects` | ● | [{set-ref} \| {predicate}] | What's in scope; predicates are the closed D14 set. A `set-ref` is closure-required and **typed: it names a RequirementSet** — anything else selected nothing, silently (rc.1 review). |
| `excludes` | ○ | [{ref, rationale?}] | **Selection, never Deviation** (D13) — scoping out is not weakening. `ref` names a Requirement **or a RequirementSet, whose members it excludes**; any other type is an error. |
| `operations` | ○ | [Operation] | Ordered; identity-addressed; same-target twice = error; chaining only via explicit `override`. |
| `deviations` | ○ | [Deviation] | Ex-ante channel — a weakening op **must** reference one. Evidence: CR26's 111 class-variant modality ops needed **zero** (every published delta tightens — measured, not assumed). |
| `provenance` | ○ | {author-ref ●, date ●} | *(2.0.0-rc.4, D26.)* Who wrote this version and when. Each select, each exclude and each operation MAY carry its own; **an entry without one has the Tailoring's.** AUTHOR-1 reports a Tailoring at consumer tier that leaves an entry without an author; an authority's Tailoring is not asked. Evidence: none counted; entered on the author's decision. |

**Operations (D13, closed set of 8):** each op carries
`requirement-ref` ● + `statement-id` ● where it touches a statement.

| op | payload | law |
|---|---|---|
| `set-parameter` | `parameter` ●, `value` ● | value must satisfy declared type **and bounds/choices**; loosening bounds ⇒ Deviation. |
| `set-modality` | `modality` ● | lattice-monotone free; easing ⇒ Deviation; axis change ⇒ Deviation. |
| `set-field` | `field` ●, `value` ● | whitelisted non-normative fields. |
| `replace-prose` | `prose` ●, `intent` ● ∈ editorial · substantive | substantive ⇒ Deviation. Misdeclared intent is forgery (14.2). |
| `add-relation` / `remove-relation` | `relation` ● | graph edits, logged. |
| `attach-facet` / `detach-facet` | `facet` ●, payload | semantics-modifying facet changes ⇒ Deviation. |

---

## A.4 Mapping

| Field | | Type | Meaning & evidence |
|---|---|---|---|
| `source-ref` / `target-ref` | ● | URI | Requirement endpoints. |
| `source-scope` / `target-scope` | ○ | ["statement:<id>"] | Clause precision. |
| `relationship` | ● | code (C.5, IR 8477/OLIR) | equal · subset-of · superset-of · intersects · supports · conflicts. |
| `direction` | ● | code | source-to-target · bidirectional. |
| `confidence` | ● | code (C.7) | draft · reviewed · authoritative. |
| `rationale` | ○ | string | Why the relationship holds. |
| `provenance` | ● | {author-ref ●, date ●} | `date` is `YYYY-MM-DD` since 2.0.0-rc.4 (**DATE-3**); until then any string. **Whose claim this is** — the third-party-crosswalk ownership answer. Evidence: 373 Mapping objects minted from CR26 KSI links at honest `supports`/`draft` (8.6 untyped-import rule). Contradictory mappings coexist by design. |

---

## A.5 Component

| Field | | Type | Meaning & evidence |
|---|---|---|---|
| `kind` | ● | code | system · service · software · hardware · policy · process · … (C.6). |
| `members` | ○ | [{component-ref ●, context ○}] | Composition. |
| `product-version` | ○ | string | *(2.0.0, CP-ADVICE-1.)* The version of the product this Component describes: one opaque string, never parsed, ordered or compared. `version` counts the revisions of the object, this field names the product's. A Component that carries it needs kernel 2.0.0 (KERNEL-1). Evidence: none counted; entered on the author's decision (specification D22). |
| `capabilities` | ○ | [{id ●, requirement-ref ○, statement-ids ○, description ○, parameter-bindings ○}] | What the vendor claims — comp-def's replacement (the PR-#8 duplication axis, deleted). Ids are unique within the Component (ADVICE-4). `requirement-ref` names the requirement a capability is about and **resolves if present**: the component asserts support, no system binds it, and a vendor ships without the catalog. In the bundle it is a Requirement, and `statement-ids` *(2.0.0, CP-ADVICE-1, proposed)* name its clauses (ADVICE-5); `statement-ids` without `requirement-ref` is refused. `parameter-bindings` are the values the vendor suggests: each names a parameter declared once on the covered clauses and lies in its declared space (ADVICE-6). Evidence: one component definition in the corpus (IFA, 3 capabilities); the worked advice pack. |
| `authorizations` | ○ | [{id ●, authority-ref ●, date ○, scope-label ○, includes ○[]}] | **Identified** trust contexts; `includes` scopes; absence is silence, and silence is silence (Ch. 9). `date` *(2.0.0-rc.4, D26)* is the day the authorization was given; AUTHOR-4 reports one without it. |

## A.6 Implementation

| Field | | Type | Meaning & evidence |
|---|---|---|---|
| `component-ref` / `requirement-ref` | ● | URI | The edge's endpoints. |
| `statement-refs` | ○ | [statement-id] | Clause-level granularity — shared responsibility per clause (KONF.14.1 s1 provider / s2 customer). |
| `responsibility` | ● | code (C.4) | provider · customer · shared · inherited. |
| `satisfied-by` | ● | [{capability-ref} \| {inherited-from}] | How. `capability-ref` *(grammar: 2.0.0, CP-ADVICE-1)* is a capability id of the edge's own component, or `<component-id>#<capability-id>`; **closure-required** — the component is in the bundle and declares the capability, and a component other than the edge's own is one of its `members` (ADVICE-7). That second form is how a vendor's advice is adopted. `inherited-from` = {component-ref ●, **basis-ref ●**} — the edge-local boundary rule (D5): every inheritance names the authorization it leans on; chains verify link by link. |
| `parameter-bindings` | ○ | {param: value} | Bound within declared bounds. |
| `status` | ● | code | planned · partial · implemented · not-applicable. |
| `evidence-refs` | ○ | [ref] | Pointers, not blobs. |
| `provenance` | ○ | {author-ref ●, date ●} | *(2.0.0-rc.4, D26.)* Who stated this status and when; `not-applicable` is a decision like any other. AUTHOR-2 reports an Implementation without it. |

## A.7 Assessment · A.8 Finding

**Assessment:** `subject-refs` ● [URI] · `method` ● {facet payload —
assessment-criteria absorbs ISM/BSI documentation duties ×966 and the
CR26 artifacts/key-tests/examples shape} · `performer-ref` ● ·
`time` ● (a date or an RFC 3339 date-time with an offset since
2.0.0-rc.4, **DATE-4**; until then any string) · `result` ● code ·
`evidence-refs` ○ ·
`check-results` ○ [row] *(2.0.0)* — one row per check run: `check-ref` ●,
`check-digest` ● (the Check's semantic digest), `collector-id` ○,
`outcome` ● (C.14), `time` ● (RFC 3339), `parameters` ○ (the values the
run was bound to), `observation` ○ inline *or* `observation-ref` ○
{ref, digest}, `evidence-record` ○ {ref, digest}, `reason` ○ text. The
observation is inline by default, so the Assessment's semantic digest
covers what was observed. With rows, `result` is their aggregate
(CHECK-10). `parameters` names only parameters the Check reads; a
`collector-id` names a collector the Check declares (CHECK-12,
CHECK-13) · `tailoring-ref` ○ URI *(2.0.0)* — the Tailoring whose bound
parameter values the run used; closure-required and typed (CHECK-12).

**Finding:** `assessment-ref` ● · `requirement-ref` ● ·
`statement-ref` ○ · `state` ● code (C.3) · `risk-refs` ○ [URI] — the
ex-post record points at the ex-ante Risk(s) it materialised against;
landmark (assessor bundle → organisation register, 2.0.0), but typed: a
ref that resolves in-bundle must name a Risk (RISK-12) ·
`actions` ○ [{description ●, due ○ {date | datetime | elapsed-duration |
calendar-period}, status ●}] — computable deadlines
(fail-closed without the named calendar). `due` is typed since 2.0.0
(**DATE-2**): a point in time is `{type: date | datetime, value}`, a
duration `{type, num, unit}` plus `calendar-ref` for a calendar period.
1.0.0 accepted any string here; a 1.0.0 bundle that wrote one is not a
2.0.0 bundle ·
`deviations` ○ [Deviation] — the ex-post channel; the four historical
FedRAMP deviation props are its `type` values ·
`provenance` ○ {author-ref ●, date ●} *(2.0.0-rc.4, D26)* — who wrote
this version and when: who raised it, and in a later version who closed
it. AUTHOR-2 reports a Finding without it ·
`check-ref` ○ URI *(2.0.0)* — the Check that raised the finding; typed
if in the bundle, and held to the same requirement and a covered clause
(CHECK-14).

## A.9 Attestation

| Field | | Type | Meaning |
|---|---|---|---|
| `subject-semantic-digests` | ● | [digest] | *Meaning* bound (JCS minus annotations). |
| `content-manifest-digest` | ● | digest | *Package state* bound — enables bi-modal verification (Full vs Semantic Match). |
| `rendering` | ● | {artifact-digest ●, media-type ●, template-ref{id,version,digest} ●, renderer ●} | *Paper* bound; templates are pinned TCB citizens; chrome-only annotation use is the renderer's law. |
| `signer` ● · `timestamp` ● · `envelope-ref` ● | | | `timestamp` is a date or an RFC 3339 date-time with an offset since 2.0.0-rc.4 (**DATE-5**). DSSE profile (stdlib); attestations live **beside** the manifest — nothing signed contains its own signature (D3). |

## A.9b Risk *(kernel 2.0.0 — CP-RISK-1)*

The ex-ante record: why a requirement is in scope. Four authorities encode
it with the same fields (ISO/IEC 27001 6.1.2–6.1.3 / 27005, BSI 200-3,
SP 800-30, OSCAL AR/POA&M `risk`); the *scales* differ and stay in facets.
Common fields (A.0) plus:

| Field | | Type | Meaning & evidence |
|---|---|---|---|
| `scenario` | ● | text | The risk statement — event and consequence (ISO 27005 event-based; BSI 200-3 Gefährdung am Zielobjekt). Multilingual like every normative text. |
| `owner-ref` | ● | URI | The risk owner (ISO 6.1.2 c 2). Landmark ref — a party, not a bundle object. |
| `provenance` | ○ | {author-ref ●, date ●} | *(2.0.0-rc.4, D26.)* Who wrote this version and when; the owner answers for the risk, which is another question. A change is a new version, and who changed it is that version's `provenance`: there is no log inside the object. `rating` and `residual-rating` MAY carry their own; one without has the Risk's. AUTHOR-2 reports a Risk without it. |
| `state` | ● | code (C.3c) | identified · assessed · treated · retired. |
| `threat-refs` | ○ | [URI] | Threat catalog entries (G 0.x, ATT&CK techniques, 800-30 threat events). Landmark. |
| `component-refs` | ○ | [URI] | The assets at risk — Components of this bundle. Closure-required (RISK-7) and typed: each names a Component (RISK-12). |
| `tailoring-refs` | ○ | [URI] | The Statement(s) of Applicability this risk's treatment belongs to — Tailorings of this bundle. Closure-required (RISK-7), typed (RISK-12). Present: the Risk justifies, and is held to RISK-11, only there. Absent: it applies to every Tailoring of the bundle (noted where there is more than one — RISK-14). |
| `rating` | ○ | {level ●, scale-ref ●, likelihood ○, impact ○, override-rationale ○, provenance ○} | Inherent/current level on a named scale. **Required** once `state` ∈ assessed · treated (RISK-2). `likelihood` and `impact` are each `{level ●, scale-ref ●}` — the two inputs ISO/IEC 27001 6.1.2 d, BSI 200-3 and SP 800-30 name; opaque like the level. The kernel defines no way of combining them; where the level scale's pinned definition carries a matrix, the level is the matrix cell or the rating carries `override-rationale` (text) saying why not (SCALE-4). One impact; impact per dimension is the facet's. |
| `residual-rating` | ○ | {level ●, scale-ref ●, likelihood ○, impact ○, override-rationale ○, provenance ○} | The level after treatment, with its own likelihood and impact. Presupposes `rating`, on the **same** `scale-ref`; a likelihood or impact carried on both sides names the same scale as its counterpart (RISK-13). |
| `treatment` | ○ | code (C.10) | modify · retain · avoid · share. **Required** once treated (RISK-3). |
| `treatments` | ○ | [{requirement-ref ●, statement-ids ○}] | **The ISO 6.1.3 b edge**: the controls determined for this risk, to the clause. requirement-ref closure-required (RISK-7) and typed — it names a Requirement, never a Set (RISK-12); statement-ids must address the target (RISK-8). **Required** for `modify` (RISK-4). |
| `shared-with-ref` | ○ | URI | Who carries the shared risk. **Required** for `share` (RISK-5). |
| `acceptance` | ○ | {approver-ref ●, date ●, rationale ●} | The owner's acceptance of the residual (ISO 6.1.3 f). `date` is an ISO 8601 calendar date (`YYYY-MM-DD`), schema-checked. **Required** for `retain` (RISK-6) and once treated (RISK-3). |
| `review-due` | ○ | date \| datetime \| elapsed-duration \| calendar-period | ISO 8.2 "at planned intervals". A point in time is `{type: date \| datetime, value}` — `date` is `YYYY-MM-DD`, `datetime` is RFC 3339 with an explicit offset, both schema-checked; durations as in `Finding.actions[].due` with `num` a positive integer, fail-closed without the named calendar. `datetime` is measured, not designed: OSCAL's `deadline` is date-time-with-timezone and both corpus deadlines are (IFA ×2). *(2.0.0-rc.4.)* **REVIEW-1** reports a Risk still managed whose `review-due` has passed, against the date of the run; a duration counts from `acceptance.date`, and a calendar period is not evaluated without its calendar. Nothing fails by it. |

**Shape-disjointness:** `scenario` + `owner-ref` occur in no other type.
**Closure:** `treatments[].requirement-ref`, `component-refs` and
`tailoring-refs` in-bundle (RISK-7) and typed (RISK-12); `owner-ref`, `threat-refs`,
`shared-with-ref`, `approver-ref`, `scale-ref` landmark. **Liveness:** a
Risk whose `state` is `retired` or whose `lifecycle` is `withdrawn`
justifies nothing (B.1.9). **Justification:** a live Risk justifies a
requirement only once it is published (not `draft`), `assessed` or
`treated`, and carries a `treatment` option — until then it is listed as
`pending` (B.1.9). **Evidence:** example bundle (1 Risk), 73
vectors, and the IFA lifecycle corpus — 2 Risks converted from POA&M
risks. That first corpus also measured what OSCAL cannot give this shape
(A.12): no owner field, no single level, no dated acceptance.

## A.9c Check *(kernel 2.0.0 — CP-CHECK-1)*

How a machine decides a requirement: the facts a collector must report,
and the comparisons that decide. No census authority publishes one; the
type entered under the consumer-side clause of D22, counted on two open
check corpora (D24). Common fields (A.0) plus:

| Field | | Type | Meaning & evidence |
|---|---|---|---|
| `requirement-ref` | ● | URI | The requirement the check discharges. **Resolves if present**, like a Mapping endpoint: a check pack may ship without a catalogue it may not pass on. In the bundle, the edge is typed (CHECK-1). |
| `statement-ids` | ○ | [string] | The clauses covered; absent means all. |
| `platform` | ● | URI | The platform under test, opaque. There is no closed list: platforms change faster than kernels. |
| `observes` | ● | [{`name` ●, `type` ●, `cardinality` ○, `description` ○ text}] | The fact contract. Types C.12; `cardinality` `one` (default) or `many`. Names unique (CHECK-2). |
| `criteria` | ● | [{`fact` ●, `op` ●, `expected` ○}] | A flat conjunction over the twelve comparators (C.13). `expected` is a literal of the fact's type, a list, or `{"param": name}`; `present` and `absent` take none. |
| `applies-when` | ○ | as `criteria` | False: the check is not applicable. With `each`, a filter per resource. |
| `each` | ○ | {`resource` ●, `allow-empty` ●} | The facts repeat per resource and the criteria hold for every one. `allow-empty` must be stated: an empty set passes only where the author said so. |
| `validity` | ○ | {`num` ●, `unit` ●} elapsed | How long a result stays fresh. Read at reading time; nothing is mutated. |
| `confidence` | ● | code C.7 | `draft` (generated) · `reviewed` · `authoritative` (published by the requirement's authority). |
| `provenance` | ● | {`author-ref` ●, `date` ●, `derived-from` ○ [{ref, digest}]} | Whose check this is; `derived-from` pins the text a generator worked from. |

**Shape-disjointness:** `observes` together with `criteria` occurs in
no other type. **Collector code** is not kernel: it rides in the stdlib
facet `collector@1` (Appendix D), `{collectors: [{id ●, runtime ●
(C.15), source ●, privileges ○, timeout-seconds ○, description ○}]}`,
inline so that the Check's digest covers the exact source, and declared
`[]` because nothing in it changes what passing means. Credentials and
target inventory never appear in a bundle. Evidence: the two Checks of
the example bundle, `check-vectors.json` (203).

## A.10 Sub-object: Deviation

`type` ● ∈ false-positive · operational-requirement · risk-adjustment ·
vendor-dependency · derogation · `state` ● (C.3b: investigating →
pending → approved | withdrawn) · `rationale` ● · `approver-ref` ● ·
`opened` ● date · `decided` ○ date · `review-due` ○ · `refs` ○. One
channel, three moments (Tailoring · Implementation · Finding); Excel
dies of enumerated states. `opened` is `YYYY-MM-DD` since 2.0.0
(**DATE-1**); 1.0.0 accepted any string. The five values in the shipped
bundles and the example folder conform.

*(2.0.0-rc.4, D26.)* `decided` is the day the Deviation was approved or
withdrawn; `opened` stays the day it was asked for. AUTHOR-3 reports an
approved or withdrawn Deviation without it. `review-due` is typed as on
a Risk (a date, a date-time, an elapsed duration, or a calendar period
with its calendar). **REVIEW-1** reports an approved Deviation whose
`review-due` has passed, against the date of the run; a duration counts
from `decided`, else `opened`. The report fails nothing, and the
Deviation keeps licensing its weakening until someone acts. Before
rc.4 an exception approved once stayed approved with no date ahead of
it.

## A.11 Bundle artifacts

**content-manifest.json:** `manifest-version` ● (the manifest *format*,
`"1"`) · `kernel-version` ○ (`MAJOR.MINOR.PATCH`, 2.0.0 — the kernel the
content was written against; absent means 1.0.0; **required** once the
bundle carries content a 1.0.0 tool cannot type — a Risk, a Finding with
`risk-refs`, a Check, an Assessment with `check-results` or
`tailoring-ref`, a Finding with `check-ref` — KERNEL-1; a tool that does not implement the pinned kernel
stops and names both versions — KERNEL-2) · `objects[]`
{id, version, **package-digest**, **semantic-digest**, path} ● ·
`facet-schemas[]` {id, **exact-version**, digest, path} ● (exact pins,
never ranges — D3) · `scales[]` ○ {id, **exact-version**, digest, path}
(2.0.0 — pinned scale definitions, below) · `renderings[]` ○ · provenance ○ ·
`pack` ○ (2.0.0, CP-ADVICE-1 — the pack header, below). The manifest is
the sealed resolver: every reference lands here or validation fails
with a rationale.

**Pack header** *(2.0.0, CP-ADVICE-1; in the manifest)*: `kind` ●
code (C.10: `advice`) · `id` ● URI (the pack across its releases) ·
`version` ● string (the release; opaque, never ordered) · `title` ○ text ·
`publisher` ● {`ref` ● URI, `name` ○ text}. Closed. A manifest with the
header is an **advice pack** and pins kernel 2.0.0 (KERNEL-1). ADVICE-1:
every listed object is a Component. ADVICE-2: every object id, `pack.id`
and `publisher.ref` share one origin. ADVICE-3: no facet on a listed
object declares a semantics class. The publisher is *claimed* by header
and origin, *proven* when an Attestation of that origin binds the
manifest's digest and — in verification mode — its envelope verifies.
Without trusted keys the binding is reported as unverified: a tool
shows *attested, not verified*, never proven.

**Kept pack manifest** *(a file beside the manifest, not an object)*:
`packs/sha256/<hex>` — the vendor's manifest as it arrived, named by the
SHA-256 of its bytes, never listed in the bundle's own manifest
(ADVICE-8). Every object it lists is in the bundle at that version with
that semantic digest (ADVICE-9); one kept manifest per `pack.id`, and no
object in two (ADVICE-10). Import — the composition of a pack into a
bundle — adds ids the bundle does not hold and replaces ids an earlier
release of the same pack brought; nothing else (ADVICE-11). Evidence:
`advice-vectors.json` (74), the example bundle's kept manifest.

---

**Scale definition** *(2.0.0; a pinned file, not an object)*: `id` ● ·
`version` ● (`MAJOR.MINOR.PATCH`) · `title` ○ text · `description` ○ text ·
`levels` ● — at least two, **lowest first**, each {`level` ● code,
`label` ○ text, `description` ○ text}. The organisation chooses how many
levels and what they are called. SCALE-1: shape, id and version as
pinned, no level twice. SCALE-2: a level a Risk states on a pinned scale
(`rating`, `residual-rating`, and the `likelihood` and `impact` in each)
is one the scale defines. SCALE-3 *(SHOULD)*: a residual is not above
what it remains of. `matrix` ○ — on the scale of the combined level only:
{`likelihood-scale` ● URI, `impact-scale` ● URI, `cells` ● {likelihood
level → {impact level → level}}}, one cell for every pair, both scales
pinned in the same bundle (SCALE-1). SCALE-4: a rating on such a scale
that states both inputs states the level of their cell; a mismatch
fails unless the rating carries `override-rationale`. Unpinned `scale-ref`s stay landmark and opaque.
Evidence: three scales in the example bundle, `scale-vectors.json` (18).

**Evidence store** *(2.0.0; files beside the manifest, never listed in
it)*: a directory `evidence/sha256/<hex>`, every file named by the
SHA-256 of its bytes, the same placement as signature envelopes. An
**evidence record** (`$defs/evidenceRecord`) is one such file:
`record-version` "1" · `check-ref` · `check-digest` · `collector-id` ·
`subject-ref` · `target` (a descriptor without secrets) · `runner` ·
`started` · `finished` · `exit-status` · `observation-digest` ·
`outputs[]` {name, digest, media-type, size, redacted} · `redactions` ·
`note`. The chain: an Attestation binds the Assessment's semantic
digest; the row holds the observation and the record's digest; the
record holds the digest of the same observation and of each raw output.
A reference into the store is `evidence/sha256/<hex>` and nothing else;
a reference with a URI scheme is a landmark that a validator notes and
does not resolve. Row and record name the same collector, or both name
none. A row carries an observation exactly when its record carries
`observation-digest`: a run that observed nothing has neither.
Redaction happens before hashing. A raw output that is gone is reported
as withheld and is no failure (CHECK-15). Evidence: seven files in the
example bundle.

## A.12 What the three converters actually exercised

Honesty ledger for this appendix: **exercised at scale** — statements
& flattening, modality (full lattice minus may-only: DARF NUR ×0
measured), obligated-parties, choice/string/calendar-period/
elapsed-duration parameters, aliases, sequence, nested Sets &
sets-of-sets, relations, facets & annotations, both digests,
set-modality/set-parameter ops, Mapping at scale (×373), authorizations
+ basis-ref (example bundle). **Declared, not yet corpus-exercised** —
predicate selects, excludes, set-field/replace-prose/relation/facet
ops, uri/date/integer/decimal parameters, canonical-alias/replaces
events, Assessment/Finding/Attestation at scale (example-bundle only).
The gap list is Appendix E's and gate items 2–3's work order.

**Risk (2.0.0), first corpus measurement — IFA re-run 2026-11-10.**
*Exercised:* `scenario`, `owner-ref`, `state`, `component-refs`,
`treatment` + `treatments` (×1), `review-due` (datetime ×2),
`Finding.risk-refs` (×2), a `risk-adjustment` Deviation naming its Risk
(×1). *Declared, not corpus-exercised:* `rating` (with `likelihood`, `impact`), `residual-rating`,
`acceptance`, `shared-with-ref`, `threat-refs`, `tailoring-refs`, and the states `assessed`,
`treated`, `retired`. That list is not an accident of a small corpus: an
OSCAL risk carries likelihood and impact but **no level** (so RISK-2 holds
both risks at `identified`), **no owner** (derived from the imported SSP's
`owner` role, declared in the coverage report) and **no acceptance date**
(so the one `accept` response cannot become `retain` under RISK-6). The
kernel shape and the fourth authority disagree on three required fields;
the disagreement was put to the author and decided on 2026-11-10: **the
rules stay** (specification D23). `assessed` always means "has a level",
`retain` always means "has a dated, attributed acceptance"; an import that
cannot say so stays `identified`, with its source status in a facet.
