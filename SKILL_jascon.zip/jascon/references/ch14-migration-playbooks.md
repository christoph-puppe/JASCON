# The JASCON Handbook
## Part Five — Adoption
# Chapter 14 — Migration Playbooks

**Audience:** [A][T] — authorities carrying legacy corpora and the tool
teams building their converters. Consumers should read §14.1 and §14.6
to know what a converted bundle's labels entitle them to believe.
**Companions:** Specification v0.5 — D16, D19; the v0.6 gate (IV.5),
whose full-corpus converters are this chapter run at scale.

---

## 14.0 The task

You hold inventory. Perhaps a 1.x estate — catalogs, profiles, an SSP
landscape, POA&Ms with years of history. Perhaps CR26-shaped bespoke
JSON. Perhaps the honest worst case: CSV vocabularies and mapping
spreadsheets that were never a standard at all. The task is to move it
— **with bookkeeping**. Migration in this architecture is bookkeeping
first and transformation second: every source element receives one of
three guarantee labels, and a conforming converter emits three
artifacts, not one — the converted bundle, a **coverage report**
(every source field's destination, every unmapped value, percentages
computed by code), and the per-element **level declaration**. A
migration whose losses are enumerated is an engineering act; one whose
losses are vibes is a liability transfer.

## 14.1 The three guarantees — and why "lossless" died

The specification's own history disciplines this section. An early
draft claimed "lossless" migration and "total" export; hostile review
demonstrated both were unprovable and the second currently false, and
the correction is on the record — the same erratum culture that
republished the census counts. What replaced the adjective is a
three-level vocabulary, declared per element:

**Level 1 — native mapping.** The element becomes a normal target
concept: a control becomes a Requirement, membership becomes a Set,
`force` becomes modality. Full semantics, full tooling, no asterisk.

**Level 2 — compatibility mapping.** The element is preserved in a
versioned compatibility facet (the `oscal-1x-prop`-style holding pen):
schema-carried, digest-pinned, visible — but its *meaning* awaits
adjudication. A promise to decide, not a decision.

**Level 3 — opaque preservation.** The canonical source payload rides
along with **no semantic claim whatsoever** — exotic part structures,
process-flow graphs, anything the model deliberately does not speak.
Present, hashable, honest about being cargo.

The honest summary claim, verbatim from the specification:
*information-preserving for the supported corpus*, verified by a
round-trip conformance corpus against a **published equivalence
relation** — a defined relation, never a magic word (§14.7).

> **Don't** ship a converter without its coverage report. The failure
> this prevents is silent smoothing: this project's own first scan
> undercounted a national corpus (651 for 998) until nested controls
> were caught, and the same corpus carries 781 lists packed into
> comma-separated strings that a "helpful" converter would either split
> without a word or carry on as text. Unmapped and defective source
> values are *findings about the source* — they belong in a generated
> list, not in the void, and each is checked against the source's own
> notation before it goes there.

A coverage report has two depths, and only the second one supports a
claim about values. The **path map** says where each source path is
*declared* to go; a converter can declare a destination and never write
to it. The **conversion ledger** says where each source *value* went: one
entry per source leaf, keyed by document and indexed JSON Pointer, with
the destination and one of five outcomes: `copied`, `transformed` by a
named rule, `not-content` by a rule the ledger checks,
`intentionally-dropped` with a reason, or `unaccounted`. A converter run
with an unaccounted value ends with exit code 1.
`oscal_conv_lib.Ledger` builds it from what the converter does. Every
scalar read from a source carries its origin for as long as it is handed
on unchanged; what the converter computes is stated at the place it is
computed, with the function, which is then applied again to the source
and compared; and every entry is checked against the written files.

> **Don't** measure arrival by looking for an equal value in the output.
> This project did, on its one corpus with a value-level figure: 835
> source values, a path map that read 835 of 835, and a check that found
> 394 of them "arrived". That check matched substrings ("open" inside
> "not-open") and, once corrected to 283, still counted every value that
> happened to equal another: three systems rated `fips-199-low`, two of
> them never carried. The ledger of the same conversion (2026-11-13)
> reads 232 copied, 26 transformed, 104 identifiers dropped by a declared
> rule and **473 unaccounted**, and it found an address that the
> converter overwrote because two props shared a name (fixed the same
> day: a repeated name keeps every value). An equal value
> elsewhere proves nothing; follow the value.

The 473 were then decided, class by class, and the decisions are the
part another converter can reuse. **Carry** what the bundle has a place
for. The leveraged and the leveraging system got what the main system
had; the inventory kept the class of each prop; the component definition
its clause texts and parameter values; each Component its description,
status, props and roles; the Implementation its narrative, statement by
statement; the Assessment its activities, tasks and observations; and
each source document its title, version and dates in the manifest's
`provenance`. **Resolve** what the source states as a reference: an edge
is the result of looking up the uuid the source gives, never a value
typed into the converter. Four hand-wired edges resolved to what they
had been. Two were wrong in a bundle that had shipped: a capability sat
on the wrong Component, and another carried the text of a neighbouring
component. **Do not drop content.** On 2026-11-13 this conversion dropped
five classes for a declared reason (revision history, the directory of
parties and roles, back-matter and import links, type tags, the uuids of
source elements), 298 values. The author's rule of the next day ended
that: *real content is never dropped*, not by a bug, not by a sentence of
the path map, not by a declared drop. What may stay out of a bundle is
what is no content, each by a rule the ledger checks: a name that only
selects a field, a namespace, an id that can be rebuilt exactly from
another value, and a back-matter resource that nothing in its document
refers to. Everything else is carried, and where the kernel and the
standard facets have no place for a value, it is carried in the compat
facet and the gap is reported as a finding about the kernel (backlog
#80 to #85); it is no reason to drop. **Declare** what the source gets
wrong: three references that name nothing their document defines are
carried as the source writes them and named in the report as defects of
the source; nothing is invented for them. Keep roles at two levels,
the Component and the whole scope; an assignment below that is rolled up
and linked to them, because a role per statement, task and capability
multiplies entries without adding a fact. The ledger of that conversion
now reads 762 copied, 62 transformed, 11 no content by a checked rule,
none dropped, none unaccounted and no failed check; the ledgers of the
five other corpora that have one read the same two zeros (214,455 source
values in all, 2026-11-14).

> **Don't** read "none unaccounted" as "right". It says that every
> source value has a destination or is no content by a rule that was
> checked. A ledger holds a rule to what the rule wrote, not to whether
> the rule is right: a table that maps a status word to the wrong
> lifecycle passes it, and only a test of the converter catches that.
> And the ledger runs one way: it follows source values into the bundle.
> A value the converter writes on its own has no entry — in this
> conversion three party URIs that no source names — so the report has
> to say it in words.

> **Don't** let a conversion become a historical document. Pin the
> source files by digest and reproduce the conversion on every change of
> the kernel, the library or the converter: fetch, check the digests,
> convert, and compare byte for byte with what is committed. This
> project's workflow does that for every corpus whose bundle it ships
> (`SOURCES.sha256` beside the bundle). A report nobody reproduces
> describes a converter that may no longer exist.

## 14.2 Playbook: OSCAL 1.x catalogs and profiles

**Controls.** Each becomes a Requirement, **at every depth: a nested
control is a full control.** Grundschutz++ nests controls to group them,
and the nesting becomes a Set whose members are the control's own
Requirement and then the controls nested in it. SP 800-53 nests its
enhancements and states the dependency itself, as a `required` link,
which becomes a relation. Do not turn a nested control into a statement
of its parent: the Grundschutz++ converter did until 2026-11-14 and lost
the nested controls' own links (75 of 266).
Statement parts feed `statements[].prose`, with ODP-style insertion
points analyzed into typed parameters — the fused-alternatives lesson
("TLS 1.3 *oder* …") means this step is analysis, not string
substitution. Guidance and objectives prose takes one of two Level-1
homes by a single rule: NIST-conventioned content (800-53's
statement/guidance/objective grammar) lands in the Canonical Reference
Facet where those conventions now live; framework-own narrative
becomes prose-only statements with `modality: "unspecified"` — 
first-class at Core, losing nothing it had.

**The identity block.** `label` props → kernel `label`, on the object
and, for the label printed beside a statement part, on the statement
(SP 800-53: ×1,122); `alt-identifier` (×1,219 in the German corpus
alone) → `aliases[]` with schemes; `sort-id` (×1,150 Australian) →
`sequence`; a per-control revision → the Requirement's `version`, and
the date of its last change → its `history` (ISM: ×1,101 each, the month
`Jun-25` written `2025-06`); groups → nested Sets. This whole row is Level 1 and mechanical — Chapter 5's
§5.3 pipeline *is* the worked playbook, twenty lines of code and a
funeral.

**Props.** Run each prop name through Chapter 7's five-question map.
The census's standing odds: **over 70 %** are kernel imitations —
Level 1 into mechanics, no facet at all. Semantically real clusters go
Level 1 into stdlib or framework facets (grammar, security
objectives, taxonomy — Chapters 4 and 7 carry the worked German
cases). What resists adjudication goes Level 2 into the compatibility
facet — *visibly*, with §14.6's clock ticking. Level 3 is rarely
needed for props; it exists for structures, not values.

**The document, its resources, its assessment objectives** *(the
author's decisions of 2026-11-14, specification D27)*. What the
catalogue says of itself goes to the manifest: one entry of
`provenance.sources` with title, version, uuid, the author the
metadata names, the day of `last-modified`, and `OSCAL` with its
`oscal-version` as format. The rest of `metadata` (roles, parties,
links, revisions) stays in the compat facet on the root Set.
Back-matter resources that something in the document refers to go to
`references@1` on the root Set, each as written, its `uuid` as `id`; a
resource nothing refers to is an orphan and is not carried. SP 800-53A
objectives go to `assessment-criteria@1` (1.1.0), each `assessment-for`
link as an address: a statement, a statement of another control, the
control as a whole, or the source's `href` where it names nothing.
Do not write `{"statement-id": "smt"}` for "the control as a whole"
when the control has several statements: it names no statement, and
since that day a validator says so (the SP 800-53 converter did, 217
times).

**Profiles.** `import` + selection becomes a Tailoring's `selects`
and `excludes`; `set-parameters` becomes `set-parameter` operations;
`alters` become `replace-prose` (with the intent flag honestly set —
a 1.x alter that changed meaning is `substantive`, and converting it
as `editorial` is forgery by migration) or `attach-facet`. One thing
has **no target**: merge strategies. Use-first, keep, combine — the
concepts do not exist, because identity collisions cannot. Where a
legacy profile's semantics genuinely depended on merge behavior,
resolve it *in the old world first* and migrate the resolved catalog;
importing an ambiguity is not preservation, it is contagion.

## 14.3 Playbook: SSPs, component definitions, assessments, POA&Ms

**The SSP** unbundles along Chapter 9's seams: system-characteristics
→ a Component with identified `authorizations[]` plus the
`system-context` facet (carrying, per the book's evidence rule, its
medium-confidence flag); implemented-requirements → Implementation
edges, with by-component granularity landing in `statement-refs` and
`responsibility`; leveraged-authorizations → `inherited-from` edges
whose `basis-ref` names the specific authorization id — the
conversion *forces* the question 1.x let slide ("inherited under
*which* authorization?"), and a source SSP that cannot answer it has
found a real gap, not a converter bug. **Component definitions**
become `capabilities[]` on vendor Components — the duplication axis
whose complexity drove a professional team's public retreat (PR #8)
simply ceases to exist as a second document. *(2.0.0, CP-ADVICE-1:
a component definition is also the natural source of an advice pack —
one Component per component, one capability per implemented
requirement, `statements[]` to `statement-ids`, `set-parameters` to
`parameter-bindings`. The pack builder
(`one-page-apps/jascon-pack-builder.html`) does exactly this on import and
reports what it could not place. Three things in real files to expect: a
`source` that is a `#uuid` into the back-matter rather than a URL, Rev 4
sources whose control and parameter ids are not the Rev 5 conversion's,
and OSCAL's `{{ insert: param, … }}` markup inside the texts; the import
handles or names each (`drafts/cp-advice-1-census/`). The conversion in the repository,
of NIST's example file inside the IFA corpus, has followed the same
mapping since 2026-11-13 (backlog #64, closed). Until then it carried
the control-level description only, while its coverage report counted 2
clause-level texts and 2 parameter values as carried. One difference
remains: it writes `requirement-ref` into the NIST namespace by rule and
carries the `source` of the control implementation beside it. Chapter 9.7; `drafts/CP-ADVICE-1.md` §12.)* **Assessment plans and
results** become Assessment objects (methods via
`assessment-criteria`) and Findings; **POA&M items** become
`Finding.actions[]` with computable due dates; and the four
historical deviation-workflow props — false-positive,
operational-requirement, risk-adjustment, vendor-dependency, each
hand-carrying the identical state machine — convert one-to-one into
typed Deviations, their four names now values of one field. The
UUID-plumbing cluster (party-uuid, import-profile, attachment
hashes) dies into L0 references and the content manifest: Level 1 by
deletion.

**Risk (2.0.0 — CP-RISK-1).** OSCAL 1.x `assessment-results`/`poam`
`risks[]` become **Risk** objects. As run on the IFA corpus (2026-11-10):
`statement` → `scenario`; `deadline` → `review-due` as a `datetime` (the
OSCAL type is date-time-with-timezone); the POA&M `system-id` →
`component-refs`; the response's `type` prop → `treatment` (`mitigate` →
`modify`, `accept` → `retain`, `transfer`/`share` → `share`, `avoid` →
`avoid`; `none` and `contingency` have no code and give no `treatment`,
C.10); the assessment finding's `related-risks` edge → `treatments[]`;
`threat-ids` → `threat-refs` (none in the corpus). `remediations` stay
`Finding.actions[]`; `related-observations` ride the Finding's evidence;
the Finding gains `risk-refs`. `characterizations`, `mitigating-factors`,
the source status and the response narrative go to a `risk-analysis@1`
framework facet (the L2 holding pen for the parked stdlib facet).
Three fields the Risk shape requires have **no OSCAL source**, and the
playbook says so instead of inventing them: (1) **owner** — OSCAL's risk
has no owner; take the system owner from the imported SSP and declare the
derivation. (2) **level** — a characterization carries likelihood and
impact, never the combined level, so `risk-status` maps to `identified`
(or `retired` for `closed`) and nothing else; `assessed` and `treated`
need a `rating` the source does not hold. The kernel's `likelihood` and
`impact` do not help here: they live inside a rating, so without a level
the source's two values stay in the facet. (3) **acceptance date** — a
`deviation-approved` risk with an `accept` response has a rationale and,
in prose, an approver, but no date; without one `retain` cannot be written
(RISK-6), so the approval stays where the source put it — on the
`risk-adjustment` Deviation, which names the Risk (RISK-9). The split the
kernel wants — `Risk.acceptance` (the owner) beside the Deviation (the
implementer), because `deviation-approved` fused two acts by two roles
and lost the owner — becomes writable the day the source records that
date.

One consequence follows and is not softened: an imported Risk that stays
`identified` is *pending* for `risk-coverage` (B.1.9) — it justifies
nothing, because a justification rests on an assessed risk with a chosen
option. A Statement of Applicability built on imported OSCAL risks reports
its controls as uncovered until someone records the level natively. The
converter reports that gap; it does not close it.

**Who wrote a record, and when (2.0.0-rc.4 — backlog #69).** A converter
pre-fills `provenance` from the source and lets the caller overwrite it
(author decision 2026-11-13). OSCAL says who is responsible for a
document, by role, and when the document was last changed. It does not
say who wrote one implementation statement, finding or risk. So the most
a converter can take is the author of the document, and
`document_author()` in `oscal_conv_lib.py` is the one rule for it: the
party named as `creator`, else as `prepared-by`, else the one party the
responsible-parties name at all, else the one party the document
defines, else the one organization among its parties, else nobody. "The
one" is exact; two candidates are no answer. The date is the day of the
document's `last-modified`, which is the latest day the record can have
been written and not the day it was. `--author-ref` and `--date`
overwrite either, field by field, on every record of the run; a record
gets `provenance` only when both are known. The app's importer follows
the same rule (`jascon-oscal.js`), with the two values in fields the
user may change before the import.

As run on the IFA corpus: of seven records that may name an author, one
gets one from its source — the system's Implementation, from the agency
its plan defines. The plan of action defines no party, and the leveraged
pair defines parties without a name, so two Implementations, two
Findings and two Risks say nobody, and the validator reports each
(AUTHOR-2). The two authorizations carry the day the source states
(`date-authorized` → `authorizations[].date`). The approved Deviation
has no day of decision in the source, and none is written (AUTHOR-3).

> **Don't** fill the gap with the person who ran the converter, or with
> today. An author nobody stated is a false record of a decision, and it
> silences the one report that would have asked the question. Overwrite
> when you know who answers for the import, and say that you did.

*(The same re-run moved the Attestation of the ATO out of the object
list and beside the manifest, where D3.1 puts it: listed, it could only
bind a list of its own subjects in place of the manifest's digest, and
one of its three subject digests had matched no object since the text
of the bundle was language-tagged at the write. The converter now
checks, before it ends, that the Attestation binds the manifest as
written and that every payload passes the schema the bundle pins for
it. Since 2026-11-14 the validator reads the Attestation beside every
bundle's manifest and holds it to the same two things (`attestation-binds`,
Appendix B.1.7): the IFA bundle's reads FULL MATCH.)*

## 14.4 Playbook: CR26 and other bespoke JSON

The American corpus converts almost by table lookup, because
Chapter 6 already worked the hard part: `force` → modality; `affects[]`
→ `obligated-parties[]`; timeframes → durations, split honestly into
elapsed and calendar (with the calendar reference becoming a
publication duty); `varies_by_class` and the `pain_timeframes`
matrices → one base Set plus four class Tailorings, by the matrix rule
(*rows become parameters, columns become Tailorings*); `subsets` and
per-class baseline lists → Sets; `updated[]`, the update history of an
entry → the kernel's `history` of the rule or indicator, the entries put
oldest first where the source lists the newest first, and for a term,
which is an entry of the glossary and no object, the converter's own
narrative facet (specification D27); the FRD glossary → `terminology@1`;
notifications and required-information → `reporting-obligation@1`;
artifacts, key tests, examples, and the KSI shape →
`assessment-criteria@1`; `effective` windows → `effectivity@1`;
schema and legal references → typed links; `web_name` → annotations;
`do_not_link` → `terminology@1`; a family's or a KSI category's `status`
→ the lifecycle of its Set and of what is made from it (`stable` →
`active`, `placeholder` → `draft`), with the source's word kept beside
it; the id of a KSI category → an alias of its Set; the 263 bare control
links → Mapping
objects imported at honest strength (`supports`, provenance named,
per §8.6). Nothing is left out. `flows[]`, a process flow the source
writes out (an activity, its nodes, its steps), is carried on its
family's Set in the compat facet; until 2026-11-14 it was a declared
non-conversion, on the reading that a flow is a linked diagram, which
this one is not. Anything else that resists is Level 2 with a ticket,
never a silent prop.

For bespoke formats that are *not* CR26, the meta-playbook is this
book's own method: run a **field census first** — every key path,
frequency, enum candidates — then adjudicate each field against the
convergence table's pattern rows (membership? modality? aliases? history?
deadlines?) before writing a line of converter. The census is the
converter's specification; everything else is typing.

## 14.5 Playbook: spreadsheets and shadow vocabularies

The CSV vocabulary behind a props estate converts by Chapter 7's
worked example: the value list becomes a facet schema, the schema
becomes the vocabulary, drift becomes a validation error — 3,431
German taxonomy props into one descriptor is the measured
before/after. Mapping spreadsheets convert by Chapter 8's §8.5–8.6:
one row, one Mapping object, honest relationship codes, and imported
link-lists graded `supports` rather than flattered into `equal`.

And the German catalog's 781 packed lists — 125 `tags`, 616 `threats`,
40 target object categories, each several vocabulary terms joined by
commas in one prop value — deserve their explicit converter policy,
because every option except one is a trap: keeping them as strings
carries the defect into the new world and fails a pinned facet schema
that wants an array; splitting them without a word repairs the source
behind its authors' backs; dropping them hides evidence. The one correct
behavior: split them by a declared, counted rule **and report them** — a
coverage-report section of defective source values, queued for the
*authors*, because they were always authoring defects that no tool had
eyes to see. The converter's job is to give them eyes, not amnesia.

Eyes have to read the source's own notation first, and this project
learned that the hard way. Until 2026-11-12 the BSI converter reported
213 values containing `{{…}}` in the sentence-template props
(`result`, `result_specification`) as "pseudo-placeholders". They are the
template's parameter slots: each of the 221 slots stands exactly where
the statement prose inserts a parameter, and 219 repeat that
parameter's label. A suspected defect is therefore tested against the
source before it is queued — here, every slot is compared with the
prose, and only a slot that stands where no parameter is inserted would
be reported.

## 14.6 The compatibility facet's half-life

Level 2 is a waiting room with a clock, and the clock is the point.
The compatibility facet exists so migration never blocks on
adjudicating every last prop — but a compatibility payload that
*stays* is just a prop with a registration number, and the smell is
the same. Two disciplines keep the room from becoming a residence:
publish the facet with **intended deprecation** in its descriptor
metadata from day one; and track **compatibility residue per
release** as a first-class migration KPI — the number should fall
toward zero, each line either graduating to a Level-1 home (a real
facet, a kernel field, the graveyard) or dying a documented death.
An authority's migration is *finished* when the residue is zero, not
when the converter first ran.

## 14.7 Round trips and dual running

For the transition years, the engine posture (Chapter 15 owns the
politics) means many of you will run dual: the Core as source of
truth, 1.x artifacts generated for regulators who still require them.
Three honesty rules make dual running survivable.

**Export flattens, and says so.** Kernel-native concepts degrade on
the way down: global identities and typed Deviations become props and
links — syntactically valid 1.x, semantically reduced; Mappings
alone export *natively*, into the 1.2.2 Mapping Model they
supersede. Consumers of your generated 1.x deserve the same level
labels your imports carry.

**Round-trip is a defined relation.** Up-convert, down-convert,
compare — against the *published equivalence relation*, verified by
the corpus at the v0.6 gate. Not byte identity, not "looks the
same": a relation you can read, with test cases you can run.

**Never dual-edit.** One direction is authoritative; the other is
generated. The moment both worlds accept edits, you have rebuilt the
duplicated-truth architecture whose measured cost — a professional
team's public retreat, a decade of sync props — opened this book.

> **Don't** edit generated artifacts. The failure this prevents is
> the oldest one in the census: two representations of one truth,
> drifting — the twin-catalog collision and the comp-def/SSP
> duplication were both this mistake wearing different clothes, and
> both required this architecture to un-make them.

---

Your estate now has a path: three labels, per-source playbooks, a
waiting room with a clock, and round trips you can test instead of
trust. What remains is the part no single organization controls — the
tiers a vendor may claim and what each claim entitles you to demand,
the registry and its transparency log, who stewards the standard
library, how primitives and operations evolve without re-growing a
committee bottleneck, and the sunset trigger that one day ends dual
running. That ecosystem contract — governance, conformance, and how
this architecture intends to coexist with, and eventually retire, the
world it came from — is Chapter 15, the last.
