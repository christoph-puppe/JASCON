# The JASCON Handbook
# Appendix B — Primitives, Operations, Predicates

**Purpose:** the complete computational vocabulary — eight primitives,
three predicates, eight tailoring operations — one entry each, in the
format the anti-#2118 rule demands: **signature, tier, semantics,
rationale (with its corpse), and the failure message that prints.**
Nothing here is illustrative filler: a rule that cannot name what it
prevents is a rule this project deletes, and this appendix is where
every rule names it.

**Conventions.** Rule ids shown as `[name]` pending the executable
schemas (gate item 2), where they gain stable machine ids. Failure
messages are templates: `<...>` marks interpolation. Tier column per
the D15 matrix: **all** = Core, Portable, Authority; **P+** = Portable
and above (Core carries the data passively, computes nothing).

---

## B.1 The eight primitives

### 1 · `references-resolve` — *all tiers*

**Signature:** (object graph, content manifest) → verdict per reference.
**Semantics:** every reference string in every object must land on a
manifest entry (id + version); sealed mode means the manifest is the
*only* resolver — no network, no guessing, no partial credit.
**Rationale:** the old world's reference layer was UUID plumbing that
tools generated and no human audited; dangling references were
discovered at consumption time, in someone else's pipeline. Here a
bundle that doesn't close doesn't validate.
**Failure:**
```
FAIL [references-resolve] <object-id>
  reference "<ref>" has no entry in content-manifest.json
  rationale: sealed validation resolves only through the manifest;
  an unresolvable reference is the publisher's defect, surfaced now
  rather than in a consumer's pipeline.
```
**Exercised:** at scale — all nine bundles close over the
closure-required reference class: Set members resolve in-bundle 14,508/
14,508 (5,470 objects at HEAD; the original "3,066" predates the
validation corpora). Mapping endpoints and party URIs are LANDMARK
references — resolvable outside the bundle by design; the normative
reference taxonomy is normative since 2026-07-21 (register
"P9-applied"; conformance family `reference-vectors.json`, 9 cases).
The example bundle documents the break-it recipe.

### 2 · `digest-verified` — package domain · *all tiers*

**Signature:** (file bytes, manifest entry) → match | mismatch.
**Semantics:** SHA-256 over the shipped bytes equals the manifest's
`package-digest`. This is the *bytes* question only; meaning is
`attestation-binds`' job.
**Rationale:** pins are the trust anchor because published locations
rot — the flagship's own extension registry vanished with its
repository. A digest mismatch is an integrity alarm, never a
retry-with-network condition.
**Failure:**
```
FAIL [digest-verified] <path>
  computed sha256:<x> != manifest sha256:<y>
  rationale: the pin is the trust anchor; a mismatch means the
  supply chain changed the bytes, not that the tool should fetch
  a fresher copy.
```
**Exercised:** at scale — real digests on all bundle objects.

### 3 · `unique-within(scope, field)` — *all tiers*

**Signature:** (scope, field) → duplicate list (empty = pass).
**Semantics:** enforces uniqueness where the model requires it —
statement ids within a Requirement, object ids within a bundle, exact
facet versions per major line within a manifest.
**Rationale:** the twin-catalog measurement: 11 id strings shared
across two publications of one authority, only 1 prose-identical — ten
silent divergences that no tool could see because nothing checked.
Uniqueness violations are how duplicated truth begins.
**Failure:**
```
FAIL [unique-within] scope=<scope> field=<field>
  duplicate value "<v>" (first at <a>, again at <b>)
  rationale: two carriers of one identity drift independently; the
  measured case is 11 shared ids with 10 diverged texts.
```
**Exercised:** implicitly by construction in the converters; corpus
negative cases are gate-item-2 work.

### 4 · `code-from(codesystem@v)` — *all tiers*

**Signature:** (value, code system + version) → member | not-member.
**Semantics:** enum fields validate against *versioned* code systems
(Appendix C); unknown values are errors, not warnings, because the
next tool would have to guess what they mean.
**Rationale:** measured vocabulary drift in the wild: `normal-SdT`
coexisting with bare `erhöht`; `Compliance Management` with
`Compliance-Management`. Unpoliced value spaces fork silently; the
pinned code system freezes them and makes the fork visible.
**Failure:**
```
FAIL [code-from] <object-id>.<field>
  value "<v>" is not in <codesystem>@<version>
  rationale: enum drift measured in the field (sec_level, tags);
  an unknown code is a fork, and forks get reported, not guessed.
```
**Exercised:** modality/lifecycle codes at scale; drift *findings*
produced by the BSI converter are the negative corpus in waiting.

### 5 · `prose-params-resolve` — *all tiers*

**Signature:** (statement) → verdict per `{param:name}` token.
**Semantics:** every token in prose binds to a declared parameter of
that statement; every declared parameter is referenced or explicitly
marked display-only. Unbound token = error. Structural check only —
no evaluation, which is why Core can run it.
**Rationale:** a token is a contract or it is a defect; this
primitive is the eyes. A slot in prose that names nothing has no
value to insert, no type to check and nothing to tailor. The German
catalog does this right in its own notation: its 224 insertions all
name declared parameters, and its sentence template marks the same
slots as `{{Label}}`, each where the prose inserts the parameter.
**Failure:**
```
FAIL [prose-params-resolve] <req>/<statement>
  token {param:<name>} has no declared parameter
  rationale: a slot in prose must name a declared parameter, or it
  has no value, no type and nothing to tailor.
```
**Exercised:** at scale (converter token conversion in every corpus;
the BSI run binds all 224 parameters); the negative cases are the
conformance corpus's.

### 6 · `modality-monotonic` — *P+*

**Signature:** (from-code, to-code, D9 partial order) → monotone |
easing | axis-change.
**Semantics:** compares two modality codes on the lattice (C.1):
same-axis moves upward are free; downward moves and axis changes
require an attached Deviation. `unspecified` sits below everything —
specifying is always monotone. Tier scope (v0.6 cycle, D13 rev): the
Deviation duty binds consumer-tier Tailorings; an Authority-tier
Tailoring is normative source and owes no Deviation — the
classification (monotone | easing | axis-change) still computes and
reports for both. The tier itself is DERIVED (layered anchor, #19):
id-origin match = claimed, authority Attestation over the Tailoring =
proven, else consumer — `tier-vectors.json` derives all three from
data alone.
**Rationale:** weakening must be *possible* (real programs ease with
justification — four FedRAMP prop-workflows existed to do it) but
never *silent*. Measured bonus: CR26's 111 published class-variant
modality moves contained **zero** easings — the channel's emptiness
is now a fact, not an assumption.
**Failure:**
```
FAIL [modality-monotonic] <req>/<stmt>  <from> -> <to>
  non-monotone move without an attached Deviation
  rationale: easing without a record is how baselines rot invisibly;
  the Deviation channel exists precisely so this edit can happen
  in the open.
```
**Exercised:** 111 monotone ops emitted (CR26 tailorings); easing
negatives in the example bundle's break-it recipes.

### 7 · `attestation-binds` — semantic domain + manifest · *P+*

**Signature:** (attestation, bundle) → Full Match | Semantic Match |
fail (+ per-subject detail).
**Semantics:** verify signature (envelope, stdlib DSSE profile); check
`content-manifest-digest` against the manifest as shipped; recompute
each subject's semantic digest (JCS canonicalization of the object
*minus annotations*, with the empty-omission and decimal-as-string
guards) and compare. All subjects match + manifest matches = **Full**;
all subjects match, manifest differs = **Semantic** (report, not
defect); anything else = fail.
**Rationale:** signatures must survive legitimate repackaging
(annotation stripping, re-serialization) while tampering has nowhere
to hide — the two-digest design exists for exactly this verdict
shape. Moved to Portable in v0.5 because JCS lives there; Core treats
Attestations as passive data.
**Failure:**
```
FAIL [attestation-binds] <attestation-id>
  subject <id>: recomputed semantic digest sha256:<x>
                signed                       sha256:<y>
  rationale: normative content changed after signing; packaging-only
  deltas would have produced Semantic Match instead.
```
**Applied to a bundle *(2.0.0 — backlog #46, 2026-11-14)*.** The
bundle's side of the signature is: the objects the manifest lists, the
digest of the manifest's bytes as delivered, and the digests of the
pack manifests it keeps (`packs/sha256/`, D25). A subject that names an
id is compared with the object of that id; a bare digest matches when
any listed object carries it. Per subject: `match`, `differs` (the
object of that id carries another digest) or `absent` (no such object,
or no object with that digest). The manifest bound: `this`, `kept-pack`
or `other`. Full = all subjects match and the manifest is this one or a
kept pack's; Semantic = all match and the manifest is another; fail =
anything else. A tool applies the primitive to every Attestation it
reads with a bundle: those beside the manifest (D3.1) and any a manifest
lists. A `fail` fails the bundle when the Attestation's lifecycle is
`active`; for `draft`, `deprecated` and `withdrawn` the verdict is
reported and nothing fails *(argued: the primitive does not speak of
lifecycle, and without this a bundle whose attested object changed could
never validate again)*. The signature is the envelope's matter (B.1.7
DSSE profile) and is reported beside the verdict.
**Exercised:** `attestation-vectors.json` — five vectors on the two
digests of one object, and nineteen `binds-vectors` on a bundle, each
expecting the verdict, the manifest bound, the status of every subject
and whether the bundle fails. In the repository: the example folder's
own Attestation (Full Match; signature verified under the public
fixture key in verification mode), the vendor's beside it (Full Match
against the kept pack manifest), the worked pack's and the IFA
bundle's. `scripts/test_attestation_binds.py` runs the reference on
eight changed copies of the IFA bundle.

### 8 · `conditional-apply(trigger, enforcement)` — *P+*

**Signature:** (trigger predicate, enforced primitive-instantiation)
→ enforcement verdict where trigger holds; no-op elsewhere.
**Semantics:** the one bounded conditional. Trigger is exactly one of
the three predicates (B.2), ≤1 reference hop, no nesting on either
side; enforcement is an instantiated primitive (bounds, code-from,
uniqueness…). Facets *instantiate* this with bound arguments — they
never define new computation.
**Rationale:** parameter-conditioned allowed values are interchange
semantics on all three authorities ("if class=a then deadline ≤ X") —
refusing conditionality would push it into prose or facets-as-code.
The leash is the lesson of the caught regression: an earlier draft's
casual "selection by facet query" was an expression language wearing
a trench coat. The predicates you get are the predicates there are.
**Failure:**
```
FAIL [conditional-apply:<instance-id>] on <object-id>
  trigger: <predicate> held; enforcement [<primitive>] failed: <detail>
  rationale: <the instantiating facet's declared rationale prints
  here - authored once, read at 2 a.m.>
```
**Exercised:** declared; corpus instantiation is gate-item-2 work
(the CR26 class-conditioned timeframes are the natural first cases).

### B.1.9 `risk-coverage` *(2.0.0 — CP-RISK-1, the ninth primitive)*

**No Tailoring, no scoping.** A bundle that carries no Tailoring at all
has scoped nothing out: every Requirement in force is in play, and the
primitive reports that implicit selection under the key `*`. A bundle
whose Tailorings are all `withdrawn` is a different statement — there was
a Statement of Applicability and it is no longer in force — and selects
nothing.
**What it computes:** for each Tailoring **in force** (`lifecycle` ≠
`withdrawn`), the selected requirements — set-refs expanded through nested
Sets to any depth, excludes removed (an exclude that names a Set removes
its members), `withdrawn` Requirements dropped — joined to the Risks that
**justify** them.
**Who justifies.** A Risk justifies the requirements its `treatments` name
once a treatment *decision* rests on an *assessed* risk: it is live
(`state` ≠ `retired`, `lifecycle` ≠ `withdrawn`), published (`lifecycle` ≠
`draft`), its `state` is `assessed` or `treated`, and it carries a
`treatment` option. ISO/IEC 27001 6.1.3 a–b: controls are determined to
implement the option chosen for an analysed risk. Without this rule a
three-field stub — scenario, owner, treatments — satisfies the policy
switch, and RISK-2/3/6 are strict about fields coverage never reads.
**Scope.** A Risk's `tailoring-refs` name the Statement(s) of
Applicability its treatment belongs to: it justifies, and is held to
RISK-11, only there. Without them it applies to every Tailoring of the
bundle — and where more than one is in force that is noted (RISK-14,
SHOULD), because a risk about system A then justifies the control in
system B's Statement of Applicability.
**Output:** per Tailoring `covered` {requirement → [risk ids]},
`uncovered` [requirement ids], and two subsets of `uncovered` that say
*why*: `pending` {requirement → [live Risks without an assessed treatment
decision]} and `lapsed` {requirement → [retired or withdrawn risk ids]};
`open-selection`, `excludes-without-rationale`; per bundle
`treatment-out-of-scope`.
**Open selections:** a predicate select (B.2) is resolved by the tailoring
engine, not by this primitive, so a Tailoring that carries one has an
*open* selection — the computed set is a lower bound, and nothing is
concluded from a requirement's absence.
**Verdict:** a report by default — `uncovered` fails only under the
program's policy (`--require-risk-basis`; ISO 27001 6.1.3 d says every
SoA row, BSI 200-2 says the baseline justifies itself). Under the switch
a bundle that carries a Tailoring and no Risk at all fails for every
selected requirement — the empty register is the limiting case, not an
exemption.
`treatment-out-of-scope` fails (RISK-11: a live Risk leans on a control
the SoA dropped) in every bundle — without a Tailoring only a withdrawn
Requirement can be out of play —, including the case where everything was
excluded, where the only
Tailoring is withdrawn, and where the named Requirement is withdrawn. The
rule is asked of the Tailorings the Risk belongs to; where one of *those*
has an open selection it is reported as *undecided*, never guessed — an
open Tailoring the Risk does not belong to decides nothing. An unresolved or mistyped
target is RISK-7/RISK-12's failure, not a second one here.
**Rationale:** 6.1.3 b/d make "every control rests on a treatment
decision" a documented property; a property that can be computed must not
be audited by hand.
```
FAIL [risk-coverage] <tailoring>  selected <req>
  justified by no Risk
  rationale: ISO/IEC 27001 6.1.3 d — inclusion in the Statement of
  Applicability carries its justification
```
**Exercised:** `risk-vectors.json` (38 bundle vectors); the example bundle
(3 selected, 1 justified, 2 uncovered). Not yet at corpus scale: the one
corpus with Risks (IFA) carries no Tailoring, and no corpus Tailoring
carries excludes or predicate selects.

---

### B.1.10 `check-verdict` *(2.0.0 — CP-CHECK-1, the tenth primitive)* — *P+*

**Signature:** `check-verdict(check, observation, parameters) →
satisfied | not-satisfied | inconclusive | not-applicable`, with
reasons. The observation is `{facts}` or, for a Check with `each`,
`{resources: [{id, facts}]}`. The parameters are the values the run was
bound to.

**The twelve comparators (C.13).**

| Op | Fact | `expected` | Holds when |
|---|---|---|---|
| `equals` | one; any type | scalar or param | the value equals expected (decimals by value) |
| `not-equals` | one; any type | scalar or param | the value differs from expected (decimals by value) |
| `one-of` | one; string, code, integer, decimal | non-empty list or list param | the value is in the list |
| `at-least` / `at-most` | one; integer, decimal | scalar or param | ordering; decimals by value, never as floats |
| `present` / `absent` | any | none | the key is, or is not, in the observation |
| `includes-all` | many | non-empty list | every listed value occurs |
| `excludes-all` | many | non-empty list | no listed value occurs |
| `subset-of` | many | list, may be empty | every observed value is listed; `[]` means "must be empty" |
| `matches` / `matches-not` | string, code; one or many | I-Regexp literal | the whole value matches, or does not; on a list every element, or no element |

There is no OR, no NOT, no nesting, no arithmetic, no path and no
comparison between two facts: the leash of B.4, applied once more.

**Evaluation.**

1. No observation: `inconclusive`.
2. `applies-when` false: `not-applicable`; unknown: `inconclusive`.
3. An undeclared fact, an unobserved fact, a mistyped value, an unbound
   parameter or a mistyped bound value: `inconclusive`. **A default is
   never substituted** (D9). `not-equals` on a missing fact is
   `inconclusive` as well, never satisfied. An `integer` fact outside
   the number domain (NUMBER-1: plain digits, magnitude at most 2^53 − 1)
   is mistyped: beyond that, two engines read two values, and neither
   may return `satisfied` or `not-satisfied` from it.
4. **Strong Kleene AND:** one `not-satisfied` decides; else one
   `inconclusive` decides; else `satisfied`. A definite failure is never
   hidden behind an unknown elsewhere.
5. `each`: **every resource is evaluated**, none is skipped after the
   first failure. Resources whose `applies-when` is false are not
   applicable; the rest combine by step 4, so the outcome is for-all.
   With no applicable resource: `satisfied` if `allow-empty`, else
   `inconclusive`. Beside the outcome a tool reports `applicable`,
   `not-satisfied`, `inconclusive`, `not-applicable` and the share of
   not-satisfied among applicable resources as a whole percentage:
   `(200·part + whole) div (2·whole)` in integers, so rounded half up,
   but 1 at the least while one resource fails and 99 at the most while
   one passes. When the outcome is not `satisfied`, the first reason is
   that count. The counts are recomputed from the recorded observation
   and stored nowhere.
6. Aggregate over an Assessment's rows (CHECK-10): `not-applicable`
   rows are dropped; with none left the result is `inconclusive`.

An absent key means *observed absent*. A collector that could not look
prints nothing. A collector reports **effective** values, defaults
resolved and drop-in files merged.

**Regular expressions.** I-Regexp, RFC 9485. Fixed by the kernel: the
pattern matches the **whole value** (`^` and `$` are ordinary
characters, `.` excludes `\n` and `\r`; several lines need
`(.|\n|\r)*`); a pattern has at most 256 characters, its compiled
program at most 1,000 states, a value at most 4,096 characters, else
`inconclusive`; and **no host engine**: an implementation parses the
grammar and matches by simulating the set of live states, without
backtracking. The grammar is the RFC's as published: a surrogate code
point (U+D800 to U+DFFF) is no pattern character. One dependence is left: a category `\p{..}` is read from
the host's Unicode database (backlog #59).

**The rules that rest on it.**

| Id | Rule | Failure message (abridged) |
|---|---|---|
| CHECK-1 | An in-bundle `requirement-ref` is a Requirement; `statement-ids` name its statements. | `<check>: statement-id 's9' names no statement of <req>` |
| CHECK-2 | Fact names are unique; every assertion reads a declared fact. | `criteria[1] reads fact 'sshd.permitrootlogin', which observes does not declare` |
| CHECK-3 | The operator fits the fact's type and cardinality; a literal has the fact's type. | `criteria[0]: not-equals does not fit a code list fact` |
| CHECK-4 | `{param}` names a parameter declared exactly once on the covered clauses, with a fitting type; the requirement is in the bundle; a pattern is never a parameter. | `criteria[0]: parameter 'max-tries' is declared 0 times on the covered statements` |
| CHECK-5 | `at-most` never binds a parameter that tightens `higher`, `at-least` never one that tightens `lower`. | `at-most against parameter 'max-auth-tries', which tightens higher - tightening it would loosen the check` |
| CHECK-6 | A pattern is I-Regexp within the size limits. | `escape \w is not I-Regexp (no \d \w \s \b, no back-references) at position 0` |
| CHECK-7 | `collector@1` matches its schema; collector ids are unique. | `collector id 'bash' is used twice` |
| CHECK-8 | A row's `check-ref` is a Check; `check-digest` matches it. | `check-digest does not match <check> - the check changed after the run` |
| CHECK-9 | A row's outcome equals `check-verdict` over its observation and parameters. | `recorded satisfied, check-verdict computes not-satisfied (sshd.maxauthtries at-most 4: observed 5)` |
| CHECK-10 | One row per check; `Assessment.result` is the aggregate of the rows. | `result is satisfied, the aggregate of its check results is not-satisfied` |
| CHECK-11 | A row without an observation is `inconclusive` and carries a `reason`. | `no observation, yet the outcome is satisfied and no reason is given` |
| CHECK-12 | `tailoring-ref` resolves to a Tailoring. A row names only parameters its Check reads, with or without a `tailoring-ref`; with one, their values equal what it binds. | `the run used max-auth-tries=6, <tailoring> binds 4` · `the row records parameter 'unbound-extra', which <check> does not read` |
| CHECK-13 | A row's `collector-id` names a collector the Check declares; a Check without `collector@1` declares none. | `collector-id 'python' names no collector of <check>` |
| CHECK-14 | A Finding's in-bundle `check-ref` is a Check about the same requirement and a covered clause. | `statement-ref 's2' is not a clause check <check> covers` |
| CHECK-15 | A relative evidence reference is `evidence/sha256/<hex>` with `<hex>` its recorded digest; every digest verifies; row and record name the same check, digest and collector, the record's subject is a subject of the Assessment, and a row carries an observation exactly when its record carries an `observation-digest`. | `output 'stdout' evidence/sha256/2d66… does not match its digest` · `evidence record ref alternate/393c… is outside the store` · `the row records an observation, the evidence record binds none` |

Notes, never failures: a row whose Check is outside the bundle (*not
recomputed*); a row with `parameters` and no `tailoring-ref` (*the
performer's statement*); a withheld raw output; and, for a per-resource
row, the count of step 5.

**Rationale, with its corpse.** 291 of the 312 rules of the CIS Ubuntu
24.04 Benchmark are marked automated and reached this format as prose in
an `audit` string. An exit code hides its threshold, cannot be reached
by a tailored parameter and leaves a bit where an observation should be.
**Measured fit:** 481 of 510 rules of the CIS Ubuntu 24.04 profiles of
ComplianceAsCode; the operators of kube-bench `cis-1.12` map onto the
set (CP-CHECK-1 §2.2). **Exercised:** `check-vectors.json`, 203 cases;
the worked example LNX-SSH-1 with two runs.

## B.2 The three predicates (shared vocabulary, one leash)

Used identically as `conditional-apply` triggers and in
`Tailoring.selects` — one grammar, one **≤1-hop, no-nesting** budget
(the P8-E3 harmonization: two dialects of "conditional" were one too
many).

**`field-equals(path, value)`** — kernel field comparison, one hop
allowed to follow a single reference. *Selects all Requirements where
`lifecycle` = `active`.* Failure names path, observed value, expected.

**`param-equals(name, value)`** — declared-parameter comparison on
statements. *Trigger for class-conditioned bounds.* Failure names the
statement address and the binding state (unbound is its own error via
prose-params-resolve, not silently false).

**`present(path)`** — existence, nothing more. *Selects Requirements
carrying a given facet.* The deliberately boring one; boring is the
point.

What there deliberately isn't: negation chains, boolean composition,
regex, arithmetic, path wildcards. Every one of those is a real
request someone will make; every one is answered by the escape path
(B.4), not by a grammar extension in place.

---

## B.3 The eight operations (addressing + law + failure)

All operations address by **identity**: `requirement-ref` +
`statement-id` (+ field name) — never by position. Two ops on one
target in one Tailoring = validation error (override happens by
chaining Tailorings, where auditors can see it). Order is list order;
application is on deep copies; every halt prints its rationale.

**`set-parameter`** — law: value satisfies the declared type *and*
bounds/choices; loosening bounds ⇒ Deviation. Corpse: the fused
alternative that hid "oder" inside prose; the md5-outside-choices
demo. Failure:
```
FAIL [op:set-parameter] <req>/<stmt>/<param>
  value "<v>" outside declared <choices|bounds>
  rationale: parameters are contracts with edges; an out-of-bounds
  assignment is either a typo or a weakening - both need daylight.
```

**`set-modality`** — law: `modality-monotonic` (B.1.6) with Deviation
on easing/axis-change. Failure: as B.1.6, prefixed with the op
address. Measured: 111 emitted, zero easings.

**`set-field`** — law: whitelisted non-normative fields only (title,
label, annotations); normative fields have their own ops precisely so
this one stays harmless (`sequence` struck v0.6 — it lives on Set
members, unaddressable by operations; backlog #21). Failure names the
field and the whitelist.

**`replace-prose`** — law: `intent` ∈ editorial | substantive is
mandatory; substantive ⇒ Deviation. Misdeclared intent is forgery
(the migration chapter's word, kept). Corpse: 1.x `alters` that
changed meaning while looking like formatting. Failure:
```
FAIL [op:replace-prose] <req>/<stmt>
  intent "substantive" requires an attached Deviation
  rationale: prose is the normative payload; changing what it
  obligates without a record is the silent-baseline-rot pattern.
```

**`add-relation` / `remove-relation`** — law: typed edges only
(C.8 codes); removal of `required` edges ⇒ Deviation (removing a
dependency is a weakening of the graph). Corpse: BSI's 67 `required`
links — real dependency semantics that props could only gesture at.
Failure names edge, type, and — for removals — the missing Deviation.

**`attach-facet` / `detach-facet`** — law: attaching or detaching a
facet whose declared `modifies-semantics` is non-empty ⇒ Deviation;
chrome-class facets move freely. Corpse: detaching the
assessment-criteria facet from a German requirement *changes what
assessors check* — that's a semantic act wearing a housekeeping
costume. (P9b-8 erratum: an earlier draft named the grammar facet here;
`statement-grammar@1` declares `[]` per the D.12 audit —
chrome-for-computation — so this law never fires on it. The corpse
belongs to a declared `[assessment]` facet.) Failure:
```
FAIL [op:detach-facet] <req>  facet <uri>@<major>
  facet declares modifies-semantics [<classes>]; detach without
  Deviation refused
  rationale: removing declared semantics changes the object's
  meaning for every downstream computation of those classes.
```

---

## B.4 The budget and the escape path (one page, load-bearing)

Three sentences govern everything above. **One leash:** every
conditional construct in the model — predicate selects and
conditional-apply triggers alike — shares one vocabulary and one
≤1-hop, no-nesting budget; needs that exceed it are answered by
moving the rule to where one hop suffices (the D5 edge-local lesson:
the inheritance-boundary rule works *because* it was relocated, not
because the need was denied). **One instantiation rule:** facets
instantiate primitives with bound arguments — machine id, human
rationale, failure message, rationale printing on failure — and never
define new computation; that is the entire difference between a
semantic contract and an embedded language. **One escape path:**
primitives, operations, and predicates are *versioned closed sets*
(R3: contained, never a language) — the ninth primitive, when its
evidence arrives, ships as a set version through the Chapter 15
process, with counts, corpus cases, and two implementations. Until
then, the honest inventory stands: **ten**, eight, and three — every
one carrying the reason it exists, printed at the moment it says no.
The ninth (`risk-coverage`, B.1.9) arrived that way in the 2.0.0 cycle:
counts (CP-RISK-1 §2), corpus cases, and two implementations green:
the Python reference and, since its first run on 2026-11-11, the
PowerShell twin, both on the same 73 risk vectors. Both were written by
the same author, so their independence is one of language and runtime,
not of reading.
The tenth (`check-verdict`, B.1.10) arrived in the same cycle: counts
(CP-CHECK-1 §2), 188 vectors, and the Python reference with the app's
port green on them. The PowerShell twin passed the 156 vectors of the
proposal on 2026-11-11; what came after (the twelfth comparator, the
per-resource counts, the surrogate rule) ran there on 2026-11-12: 188 of
188. With it comes a
second closed set, the twelve comparators, under the same leash: a
thirteenth is a set version with counts, never a facet.
