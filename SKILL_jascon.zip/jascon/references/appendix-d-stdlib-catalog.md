# The JASCON Handbook
# Appendix D — stdlib Facet Catalog

**Purpose:** the standard library's facets — what each is for, what it
declares, what its payload looks like **in the field**. Every example
below is quoted verbatim from the gate-item-1 bundles (ISM, BSI,
CR26), not composed for the page: this catalog describes facets that
have already carried 93,259 values.

**Status convention.** The normative JSON Schemas shipped with gate
item 2 (2026-07-21): `schemas/stdlib/` carries the six descriptors,
`scripts/validate_core.py` is the executable, and the bundles'
in-place stubs are superseded: the converters pin the descriptors
verbatim (`Bundle.pin_stdlib`, converter rerun 2026-07-22), and the
skill's example bundle, which kept a stub of `assessment-criteria`
until 2026-11-10, does the same. Both converter-established shape
conventions are now decided: (a) the `by-statement` keying pattern is **normative** (D10
rev, backlog #7 — a payload key naming no statement of the host is a
validation error); (b) glossary hosting on a Set — typically the
corpus root — is **normative** (backlog #6, closed at gate 2; carrier
rejected via the D22 absorption clause). The D.12 audit promotions
shipped in the descriptors (backlog #8).

---

## D.1 `statement-grammar@1`

**Purpose:** the controlled-grammar decomposition of a clause —
action, result, specification, target categories — the authoring/QA
vocabulary behind BSI-style requirements engineering.
**Declares:** `[]` (chrome for computation; assessment semantics live
in D.6). **Payload:** `by-statement: {sid: {action, result,
result-specification?, target-object-categories[]}}`.
**Field sample** (BSI MS-TLS, KONF.14.1/smt):
```json
{"action": "verschlüsseln",
 "result": "Kommunikation beim Transport",
 "result-specification": "über Netze nach {{einem anerkannten Standard}}",
 "target-object-categories": ["Anwendungen"]}
```
Note the passenger: the template's parameter slot
`{{einem anerkannten Standard}}` rides *inside* the grammar payload as
published, while the prose binds the same parameter as a token; the
converter checks that the slot stands where the prose inserts it
(§14.5). **Absorbs:** modal_verb/action_word/result/… ×~4,000 grammar
props. **Status:** high confidence; exercised at 1,015 statements.

## D.2 `security-objectives@1`

**Purpose:** protection-goal ratings and threat linkage per clause.
**Declares:** `[]` as shipped; **open question:** selection-class
candidacy (baselining by objective is a real selection use).
**Payload:** `by-statement: {sid: {confidentiality, integrity,
availability, authenticity, threat-refs[]}}` — rating values are the
authority's own scale, frozen by the pinned schema, not normalized.
**Field sample** (GS++, REA.1.2):
```json
{"confidentiality": "1", "integrity": "1", "availability": "1",
 "authenticity": "0",
 "threat-refs": ["https://ns.bsi.bund.de/gspp/threat/G-0.18"]}
```
**Absorbs:** C/I/A/Auth + threats ×4,494. **Status:** high;
exercised (899 threat-linked clauses).

## D.3 `terminology@1`

**Purpose:** defined terms with aliases — because, in the source's
own framing, when a defined term appears in a rule the definition is
part of the rule. **Declares:** `[]`. **Payload:** `terms: {id:
{term, definition, tag?, aliases[], note?, reference(+url)?,
do-not-link?}}` (+ `glossary-info` carrying the source block's
metadata). **Field sample** (CR26, FRD-IIR):
```json
{"term": "Initial Incident Report (IIR)",
 "definition": "An initial report about an incident that is supplied
  by FedRAMP Certified cloud service providers to FedRAMP and agency
  customers, ...", "tag": "Incident",
 "aliases": ["initial incident report", "IIR", ...]}
```
**Absorbs:** 75 FRD terms, 188 aliases; `uses-term` relations ×264
point in. **Hosting rule (decided at gate 2, backlog #6):** the glossary is
hosted on a **Set** — typically the corpus root — whose identity,
version, and lifecycle govern it; a dedicated carrier was rejected via
the D22 absorption clause (264/264 resolution measured with zero new
structure). **Status:** high; exercised; normative descriptor shipped.

## D.4 `reporting-obligation@1`

**Purpose:** who must be told what, where, how — the notification
duties that rules attach. **Declares:** `[]` as shipped; **open
question:** assessment-class candidacy (report duties are checkable).
**Payload:** `{notification[]: {party, method, target, name},
following-information[], following-information-bullets[]}`.
**Field sample** (CR26, IEC-CSO-IIR):
```json
{"notification": [
  {"party": "FedRAMP", "method": "email",
   "target": "fedramp_security@fedramp.gov", ...},
  {"party": "Agency Customers", "method": "varies",
   "target": "varies by agency",
   "name": "Follow agency-specific incident reporting procedures"}]}
```
That second entry is the honest kind: `varies` is data, not a gap.
**Absorbs:** notification ×23, following_information ×32+2.
**Status:** high; exercised.

## D.5 `effectivity@1`

**Purpose:** when obligations bite — enactment, maintenance,
adoption, grace. **Declares:** `[]` as shipped; **open question:**
selection-class candidacy (time-gated applicability is selection by
calendar). **Payload:** `{default?: window, <track>?: window}` with
window = `{is, current_status, date{obtain, maintain,
optional_adoption, grace{...}}}`. **Field sample** (CR26, family CCM,
per-track):
```json
{"20x":  {"is": "required", "date": {"obtain": "2026-07-04",
          "maintain": "2027-01-01", "grace": {"default": "2027-01-01",
          "until_next_assessment": true}}},
 "rev5": {"is": "required", "date": {"obtain": "2027-01-01", ...}}}
```
**Absorbs:** family effective ×7 + per-track ×20 — the RFC-0024
deadline machinery, machine-readable. **Status:** high; exercised.

## D.6 `assessment-criteria@1`

**Purpose:** what an assessor checks — required documentation,
artifacts, examples, key tests. The KSI shape's home. **Declares:**
`["assessment"]` — the one stdlib facet with computation semantics
from day one: tools that assess must understand or halt.
**Payload:** `{required-documentation[]?, required-artifacts[]?,
default-artifacts?, examples[]: {id, examples[], key-tests[]}?,
objectives[]?, audit?, remediation?, method?: automated|manual,
frequency?, summary?}` (by-statement keyed where per-clause). The
descriptor closes the shape. It types `summary` as an object; the
example bundle carries a language map there (`{"en": "…"}`).
**Field samples** — GS++ (REA.1.2): `{"required-documentation":
["Übungs- und Prüfplan"]}` · CR26 (SCN-TRF-TPR):
```json
{"id": "Tips on transformative changes",
 "examples": ["The addition, removal, or replacement of a critical
   third party service ...", "Increasing the security categorization ..."],
 "key-tests": [...]}
```
**Absorbs:** documentation ×966, artifacts ×53+, examples/key-tests,
the corpus default-artifacts block. **Status:** high; exercised
across all three corpora.

## D.6b `collector@1` *(2.0.0 — CP-CHECK-1)*

**For:** the code that observes what a Check declares. It sits on the
Check, so the Check's semantic digest covers the exact source.
**Declares:** `[]`. Nothing in the payload changes what passing means;
the criteria do, and they are kernel (D24). A tool that cannot run a
runtime still validates, recomputes and renders.
**Payload:** `{collectors: [{id ●, runtime ●, source ●, privileges ○
(unprivileged | root), timeout-seconds ○, description ○}]}`. `runtime`
is `sh · bash · powershell · python · ansible · http-api` or a
namespaced URI (C.15). One Check may carry several collectors for the
same fact contract; a run names the one it used (`collector-id`,
CHECK-13).

In the field, from the example bundle (the only bundle that carries
one; no converted corpus does):

```json
{ "id": "bash", "runtime": "bash", "privileges": "root",
  "timeout-seconds": 30,
  "source": "#!/bin/bash\nset -o pipefail\nv=$(sshd -T | awk '$1==\"maxauthtries\"{print $2}') || exit 1\n…" }
```

**The contract of a collector.** It prints one observation and decides
nothing. It reports effective values, with defaults resolved. A fact it
looked for and did not find is left out; a collector that could not
look prints nothing. Credentials and target inventory never appear
here: they are the runner's configuration.
**Open:** the `source` of an `http-api` collector is free text, which no
tool can execute as it stands (backlog #62).

## D.7 `system-context@1` — *medium confidence*

**Purpose:** the SSP's system-characteristics residue — deployment
model, data types, boundary narrative — as a facet on Components.
**Declares (planned):** `[]`. **Status:** medium, **pending Rev5-era
verification** of the field inventory; concept-exercised in the
example bundle only, not yet corpus-driven. The honesty rule: this
entry ships as a placeholder with its evidence gap named, or it
doesn't ship.

## D.8 `assurance-levels@1` — *medium confidence*

**Purpose:** graded assurance/impact levels (Low/Moderate/High
families and kin) as declared vocabulary rather than magic strings.
**Declares (planned):** `["selection"]`. **Status:** medium, pending
the same Rev5-cycle confirmation; unexercised. Candidate first
corpus: the CR26 class system's interplay with impact levels.

## D.9 The Canonical Reference Facet (`sp800-53@…`) — NIST-owned

**Purpose:** SP 800-53's document conventions — statement/guidance/
objective structure, ODP practices — as a facet **NIST owns and
maintains**, shipped by default, first among equals in visibility,
governed by the same rules as everyone (D11: "the standard library,
not the constitution"). **Status:** the arrangement is decided; the
schema is NIST-side work aligned with gate items 2–3 (the CTL
overlay's ODP assignments are its first waiting customer — see
D.10).

## D.10 The compat facet (`oscal-1x@1`) — the waiting room, clocked

**Purpose:** Level-2 migration holding pen (D16): preserved,
schema-carried, visibly *undecided* — with intended deprecation in
its descriptor and a residue KPI per release (§14.6).
**The clock started at these measured numbers:**

| Corpus | Residue | Content |
|---|---:|---|
| ISM | 539 payload entries | guideline `overview` narratives on Sets |
| BSI | 179 requirements | `param-extras` (label/default/alt-id) — feeds the open D9 scalar-default question |
| CR26 | 29 + 5 objects | rule & KSI `class-variants` (full variant fidelity; feeds the open D13 ceremony question) |
| CR26 | 79 entries | the CTL Rev5 overlay — parked until the NIST catalog conversion (gate 3) supplies statement addresses |

Every row has a named exit: a spec decision, a facet graduation, or a
gate-3 dependency. A row without an exit would be a prop with a
registration number — the smell §14.6 warns about.

## D.11 Framework facets (the sanctioned open category — not stdlib)

Authorities mint their own, registered and pinned like anything else.
The gate produced five real ones: **`gspp-taxonomy@1`**
(sec-level/effort/tags/class/practice — sample from KONF.14.1:
`{"sec-level": "normal-SdT", "effort": 2, "tags": ["Produktbeschreibung",
"Cryptography", "Zero Trust"], ...}`), **`gspp-narrative@1`**
(guidance + layer descriptions), **`cr26/scope@1`** (subset
applicability — sample: `{"types": ["20x","Rev5"], "paths":
["Program","Agency"], "classes": ["B","C","D"], "affects":
["Providers"]}` — declares `["selection"]`, and earns it: the class
Sets are computed from it), and **`cr26/narrative@1`** (notes,
danger, corrective actions). The five-question routing map that
decides kernel-vs-stdlib-vs-framework-vs-annotation-vs-nothing is
Chapter 7's; the measured base rate stands: >70 % of legacy props
needed **no** facet at all.

## D.12 Declaration audit & the parked list

| Facet | Normative declaration (gate 2) | Disposition |
|---|---|---|
| statement-grammar | `[]` | chrome-for-computation confirmed |
| security-objectives | `[selection]` | **promoted** (backlog #8): objective-driven baselining is selection |
| terminology | `[]` | **hosting decided** (backlog #6): Set-hosted, typically corpus root; carrier rejected (D22 absorption) |
| reporting-obligation | `[assessment]` | **promoted** (backlog #8): notification duties are checkable; anticipated kernel candidate when an EU corpus lands |
| effectivity | `[selection]` | **promoted** (backlog #8): time-gated applicability is selection by calendar |
| assessment-criteria | `[assessment]` | confirmed by use; gains `frequency` (CIS cadence) and audit/remediation/method (benchmark shape) |
| cr26/scope (framework) | `[selection]` | the exemplar the promotions followed |
| system-context · assurance-levels | — | **parked** (P10 #35, 2026-07-22 — the gate-3 clock ran out and the verdict is recorded): the Rev5/IFA corpus surfaced the need as a *framework* facet (`https://ifa.gov/goodread/facet/system`) and as levels-as-Sets, not as stdlib payloads; both park beside `privacy-assessment@1` and ship when a corpus demands the stdlib shape |

The governing principle, quoted from the user directive that decided
#8: **a tool that cannot handle a facet must stop working on that
data** — fail-closed engages only when declarations are honest.

**Parked (2.0.0, named exit):** `risk-analysis@1` — the scoring method
where it is more than a table (method-ref, CVSS, FAIR), impact per
dimension, characterizations, mitigating
factors: what Appendix F Q14 keeps out of the kernel now that the Risk
*object* is kernel (A.9b) and its rating carries likelihood and impact as
plain levels. Likelihood and impact *without* a combined level — what an
OSCAL risk has — still belong here, because the kernel holds them only
inside a rating. The plain likelihood-impact *matrix* is not facet
material: it is part of the pinned definition of the level scale (A.11).
First corpus, measured 2026-11-10: the IFA re-run retired the `risk@1`
framework facet (it sat on Findings) and carries the same content on the
two Risk objects as `ifa.gov/goodread/facet/risk-analysis@1` — the L2
holding pen. Observed payload: `characterizations` (likelihood and impact
as name/value pairs under a scale `system` URI, plus origin actors) ×2,
`responses` (type, lifecycle, title, narrative, tasks) ×2,
`mitigating-factors` ×1, the source `risk-status` and `description`. What
that one corpus already says about the design: the level is NOT in the
source — a stdlib facet that wants to explain a `rating` must carry the
method that combines the two inputs. Second corpus: a BSI 200-3
Risikoanalyse export. Ships when both are measured.

**Parked:** `privacy-assessment@1` — deliberately not shipped until
the Rev5-era privacy corpus is measured; a privacy facet designed
from memory would violate the book's only method. The audit table
above *is* the candidate list: no facet is proposed here that the
corpora haven't already asked for.
