# The JASCON Handbook
# Appendix C — Code Systems

**Purpose:** every enumerated vocabulary the kernel validates against —
each a **versioned closed set** (`codesystem@major`), checked by the
`code-from` primitive, changed only through the Chapter 15 process.
An unknown code is an error, never a warning, because the next tool
would have to guess — and the measured cost of unguarded value spaces
(`normal-SdT` beside bare `erhöht`; `Compliance Management` beside
`Compliance-Management`) is silent forking. Where the gate-item-1
converters produced real distributions, the observed numbers are
printed with the codes: a code system with usage data is governance
with eyes.

Section numbers below are the anchors Appendices A and B cite.

---

## C.1 Modality — the lattice

Seven codes on a **partial order**, two axes:

```mermaid
graph BT
  U["unspecified"]
  MAY["may<br/>(KANN)"]
  SHOULD["should<br/>(SOLLTE)"]
  MUST["must<br/>(MUSS)"]
  MO["may-only<br/>(DARF NUR)"]
  SN["should-not<br/>(SOLLTE NICHT)"]
  MN["must-not<br/>(DARF NICHT)"]
  U --> MAY
  MAY --> SHOULD
  SHOULD --> MUST
  MAY --> MO
  U --> SN
  SN --> MN
```

**Reading the lattice:** upward moves are monotone — free in any
Tailoring. Downward moves, and any move *across* branches (obligation
↔ prohibition, or between `may-only` and the should/must chain, which
are incomparable), require an attached Deviation
(`modality-monotonic`, B.1.6). `unspecified` sits below everything:
specifying is always tightening. `may-only` is the German
regulatory gem — *DARF NUR*: permitted **exclusively** under the
stated condition — which restricts rather than obliges, hence its own
branch above `may`.

**Observed (gate item 1):** three corpora, three signatures.
BSI GS++/MS-TLS is **should-heavy** (should 626 · may 225 · must 155 ·
unspecified 9 · **DARF NUR ×0** — anticipated by the lattice, unused
by the corpus). CR26 is **must-heavy** at rule level (must 136 ·
should 45 · may 20 · must-not 11 · should-not 5 · unspecified 29).
ISM is honestly **unspecified ×1,149** — declarative present-tense
prose, binding force via baseline membership. Three healthy
frameworks, three different force distributions: the lattice encodes
all of them without flattery.

## C.2 Lifecycle

`draft · active · deprecated · withdrawn` — on every object (A.0).
Deprecation is a state *with a successor pointer* (`replaces` on the
new object carries the mode); withdrawal is terminal, and in a bundle
that holds an object as withdrawn nothing in force leans on it
(WITHDRAWN-1, Chapter 12; the record may still name it). Identity events
(rebrand, split, merge, rename) are **not** lifecycle codes — they
are `canonical-alias`/`replaces` records (Chapter 3), because a state
field cannot carry a forwarding address.

## C.3 Workflow states

**Finding states (seed set):** `open · in-remediation · closed`.
Deliberately small — dispositions (false positive, accepted risk,
vendor dependency) are **Deviations**, not extra states, and deadlines
live in `actions[].due`. The corpse this smallness honors: the old
world encoded disposition workflow as four prop families, each
hand-carrying its own state machine through spreadsheets. Seed status:
gate item 2 confirms or extends with lifecycle-corpus evidence.

**C.3b Deviation states:** `investigating → pending →
approved | withdrawn` — one machine, four historical prop-copies
retired. Terminal states are terminal; re-litigation is a *new*
Deviation with its own record.

**C.3c Risk states** *(2.0.0)*: `identified → assessed → treated →
retired` — forward only, skipping allowed (RISK-2/3 make the skipped
content mandatory anyway), `retired` terminal: a recurrence is a *new*
Risk, the Finding `closed` rule applied once more. Dispositions are the
`treatment` code (C.10), never extra states. `retired` has a consequence
beyond the state machine: a retired Risk justifies nothing (B.1.9) and is
exempt from RISK-11 — retiring a risk and then
dropping its control is the ordinary end of a treatment. `assessed` has
one too: a Risk justifies a requirement only from `assessed` on, and only
with a `treatment` option chosen — an `identified` Risk is listed as
pending (B.1.9).

## C.4 Responsibility

`provider · customer · shared · inherited` — on Implementation edges.
`shared` composes with `statement-refs` for clause-level splits
(KONF.14.1: s1 provider, s2 customer); `inherited` requires
`satisfied-by.inherited-from` with its `basis-ref` (the D5 boundary
rule). Observed: the CR26 party universe (`affects[]`: Providers 159 ·
Agencies 24 · Assessors 23 · FedRAMP 16 · Advisors 3) maps onto
obligated-parties, with responsibility as the implementation-side
complement.

## C.5 Mapping relationships (IR 8477 / OLIR)

`equal · subset-of · superset-of · intersects · supports · conflicts`
— adopted, not invented: NIST IR 8477's harmonized set, so crosswalks
speak the vocabulary the mapping community already standardized.
Stewardship of the code system tracks upstream (the R13 standing
duty). The composition arithmetic (what survives a two-hop chain)
is Chapter 8's table; the short version: `equal` chains, everything
else degrades honestly toward `intersects`/`supports`.
**Observed:** 652 Mapping objects minted from CR26's untyped control
links (558 of KSIs, 94 of rules; publication 2026.11.02.01 of
2026-11-02) — all `supports` per the §8.6 import rule, because flattering
an untyped link into `equal` is how crosswalk trust dies.

**`supplements`** *(v0.6 cycle, 2026-07-21)* — the one code beyond the
adopted IR 8477 set, clearly marked as a JASCON stdlib
extension: source attaches additional normative content to target,
the clause-precision edge of the supplement pattern (§6.A). It is not
a crosswalk claim: it does **not** chain in Chapter 8's composition
arithmetic (degrade as `supports`), and OLIR-facing exports MAY
down-translate it to `supports` losslessly for exactly that reason.

## C.6 Component kinds

`system · service · software · hardware · policy · process` — the
seed set covering the census's component universes (CSO stacks,
platform inheritance, organizational policies as components).
Interconnections are **relations between Components**, not a kind.

## C.7 Confidence

`draft · reviewed · authoritative` — on Mappings. The grade answers
"how much diligence stands behind this claim," and provenance answers
"whose diligence" — together they let contradictory mappings coexist
without a fistfight (D20). **Observed:** 652 × `draft` (CR26
publication 2026.11.02.01 of 2026-11-02) — correctly
humble for machine-imported link lists; `reviewed` appears in the
example bundle's hand-checked crosswalk; `authoritative` is reserved
for the mapping's *owner-of-record*.

## C.8 Relation types — the one extensible surface

Stdlib base codes: `related · required · uses-term · reference ·
schema`. Semantics that compute: removal of a `required`
edge in a Tailoring ⇒ Deviation (B.3); `uses-term` resolves into
terminology payloads; the rest are typed navigation.
**`describes`** *(2.0.0, CP-ADVICE-1; URI-typed:
`https://ns.jascon.net/stdlib/relation/describes`)* — on a Component,
pointing at another Component: "this object is about that product". It
is how a third party's advice names the vendor's product it was written
for (Chapter 9.7). Carried and displayed, never computed. Observed: 0
instances in the corpora; two conformance vectors.
**Removed (v0.6 cycle, backlog #20):** `supersedes` — D2 split that
conflated concept into `canonical-alias` (identity) and `replaces`
(lineage) after P7-B4 proved "supersedes = equivalence" unsafe; a
second, un-split lineage carrier on the relations channel would
resurrect exactly that hazard. No corpus used it (0 instances).
**Extension rule:** this is deliberately the *one* open-ish code
surface — authorities may mint additional, namespaced relation types
(URI-typed), which conformant tools **carry and display but do not
compute**. Rationale: link vocabularies are where legitimate
framework diversity is widest and computation stakes are lowest — the
opposite profile of modality, where one shared lattice is the whole
point. **Observed:** BSI `related` ×197 + `required` ×67; CR26
`related` ×23, `schema` ×24, `uses-term` ×222 (rules) + ×~42 (KSIs).

## C.9 Duration units and tightening

Two unit classes, one semantic boundary:
**elapsed-duration:** `seconds · minutes · hours` — clocks that run
through weekends (incident response).
**calendar-period:** `days · bizdays · weeks · months · years` — plus
a mandatory `calendar-ref`; computation fails closed without the
calendar (the representable-but-not-computable state is honest, not
broken).
The class boundary is load-bearing: "6 hours" and "1 bizday" are
different *semantics*, not different spellings — and the gate's refined count
found **zero true unit-class crossings** in CR26 (all 51 initially
flagged cases were variant-only rules with no base timeframe — a D13
ceremony question, not a D9 union question; the correction is itself
on the record). `tightening ∈ lower · higher · none` declares per parameter
which direction is stricter (deadlines: lower); bounds moves against
the declared direction ⇒ Deviation.

**Calendar contexts — `calendar-context@1` (stdlib code system, seed;
v0.6 cycle, backlog #13).** `calendar-ref` values SHOULD cite a stdlib
calendar-context code rather than a minted URL, so two jurisdictions'
tools resolve one `bizdays` value identically. Seed set:
`us-federal` (US federal holidays, Mon–Fri week), `de-bund` (German
federal holidays, Bundesland-neutral), `eu-target2` (TARGET2 banking
calendar). Each code pins holiday list + working-week + cutoff
semantics; the fail-closed rule is unchanged (no resolvable context ⇒
explained error, never a guess). The CR26 converter's ad-hoc
`…/cr26/calendar/us-federal` migrates to the `us-federal` code at the
next converter run (16 objects). Seed status: additions ship the Ch.15
way — an EU reporting corpus (NIS2/DORA) is the first expected extender.

## C.10 Small sets

**Implementation status:** `planned · partial · implemented ·
not-applicable`. **Assessment results (seed):** `satisfied ·
not-satisfied · inconclusive` — with the same C.3 smallness rule:
nuance belongs in Findings and evidence, not in result-code
proliferation. Seed status, gate-item-3 lifecycle corpus confirms.
**Risk treatment options** *(2.0.0)*: `modify · retain · avoid · share` —
adopted, not invented: ISO 31000 §6.5.2 / ISO 27005 §8.6, one-to-one with
BSI 200-3 (Reduktion · Akzeptanz · Vermeidung · Transfer); SP 800-39's
share and transfer both map to `share`. Each option binds a field
(RISK-4/5/6): modify ⇒ `treatments`, share ⇒ `shared-with-ref`,
retain ⇒ `acceptance`. Observed in the corpora (IFA re-run, 2026-11-10):
OSCAL's response `type` prop carries the option — `mitigate` ×1 →
`modify`, `accept` ×1 → `retain` (not emitted: the source has no dated
acceptance, RISK-6). The fit is not one-to-one in the other direction:
OSCAL allows seven values for that prop (`avoid · mitigate · transfer ·
accept · share · contingency · none`); `transfer` and `share` both land
on `share`, and `contingency` and `none` have no code here. Decided
2026-11-13 (backlog #47b), and neither gets one. `none` says that no
option was chosen; a Risk says the same by carrying no `treatment`, so
the absence of the field is that value. `contingency` is a plan for the
day the risk materialises and is none of the four options; a fifth code
needs a counted instance (D22, test 3), and no corpus holds one. In both
cases a converter writes no `treatment`, leaves the response verbatim in
its facet and counts it in its report, never coerced. Run on 2026-11-13
on two copies of the IFA POA&M with one response type changed: the Risk
carries no `treatment`, the facet carries the type, the bundle
validates. The question reopens with the first instance in a real
corpus.
**Pack kinds** *(2.0.0, CP-ADVICE-1)*: `advice` — a closed set
of one. The kind is what the pack rules fire on: an `advice` pack holds
Components only (ADVICE-1). A pack of Checks would be a second code with
rules of its own, added by the process of C.11, never by reading
`advice` loosely.

---

## C.11 Governance footer (applies to every system above)

Each system is versioned independently (`modality@1`, `deviation@1`…);
`code-from` validates against the *pinned* version; additions are
minor versions, removals or meaning changes are majors with
deprecation lifecycles; every proposed code arrives the Chapter 15
way — counts, corpus cases, two implementations. The seed-set
markings above (C.3, C.10) are this book's evidence-tier discipline
applied to its own vocabulary: where the corpus hasn't voted yet, the
set says so.

## C.12 to C.15 — the code systems of Check *(2.0.0)*

C.11's footer applies to each: closed sets, versioned, changed by a
proposal with counts.

**C.12 Fact types:** `string · integer · decimal · boolean · code`, with
the cardinality `one · many`. A decimal is the canonical decimal string
of the kernel and compares by value; a JSON float is no decimal fact.
An integer is a JSON number in the number domain (NUMBER-1): plain
digits, magnitude at most 2^53 − 1. A count in nanoseconds, a 64-bit
identifier or any fraction is declared `decimal` and reported as a
string.

**C.13 Comparators** (twelve): `equals · not-equals · one-of · at-least ·
at-most · present · absent · includes-all · excludes-all · subset-of ·
matches · matches-not`. Which fits which fact is the table of B.1.10.
`not-equals` joined on 2026-11-12: the census had found it 85 times
across kube-bench and twice in OVAL states, and for a number nothing
else says it.

**C.14 Check outcomes:** `satisfied · not-satisfied · inconclusive ·
not-applicable`. The three assessment results, and the one a single
check needs and an assessment does not.

**C.15 Collector runtimes** (in `collector@1`): `sh · bash · powershell ·
python · ansible · http-api`, or a namespaced URI. For `http-api` the
`source` has no declared format yet (issue 37 of the repository's
tracker, which holds the whole of API-based checks; backlog #62 was
moved there on 2026-11-15).
