#!/usr/bin/env python3
"""IFA GoodRead lifecycle set (SSP + AP + AR + POA&M) + leveraged/leveraging
SSP pair + component-definition example -> Semantic Core lifecycle bundle.
Census: drafts/gate-3-census.md §4 (2026-07-22). The five lifecycle types at
document scale: Components (with authorizations - the D5 anchor),
Implementations (param bindings against the REAL minted AC-6.1 ODPs;
inheritance via inherited-from{component-ref, basis-ref}), Assessment (AR
ConMon result, AP as method payload, observations as facet + landmark
evidence URIs), Findings (POA&M risks -> states/actions/deviations), and an
Attestation modeling the SSP's date-authorized ATO.
CP-RISK-1 re-run (kernel 2.0.0, 2026-11-10): the POA&M risks are also
emitted as Risk objects - the first corpus measurement of the tenth type.
What OSCAL cannot give the Risk shape is REPORTED, never filled in: no
owner field (derived from the imported SSP, declared), no single level
(likelihood + impact only - `assessed`/`treated` are unreachable), no dated
acceptance (`retain` is unreachable). Findings point at their Risk with
`risk-refs`; the risk@1 framework facet is retired. Referenced Requirements
(AC-6.1, AC-2) ride along as byte-identical copies from the US.SP800-53
bundle - an authorization package carries its baseline. Coverage target: 0.
Depends on: convert_nist.py output (run first).

Who wrote a record, and when (backlog #69, kernel 2.0.0-rc.4): an
Implementation, a Finding and a Risk get `provenance` pre-filled from what
their source document says about itself - its author by the rule
document_author() of the library, the day of its last-modified - and an
authorization gets the date the source states for it. Where a document
names nobody, the record gets nothing and the report says so. The caller
may overwrite both for every record:

    convert_ifa.py [--author-ref URI] [--date YYYY-MM-DD] [--out DIR]

Without arguments the run reproduces the committed conversion byte for
byte; the Validators workflow holds it to that. --out writes the conversion
somewhere else, which is where a run with an overwrite belongs.

The Attestation of the ATO is written BESIDE the manifest and binds that
manifest's digest (D3.1; backlog #46). Until 2026-11-13 it was an object
the manifest listed, so it could only digest a list of its own subjects in
place of the manifest."""
import json, os, re, sys, collections, hashlib
import jsonschema
from oscal_conv_lib import make_T, slug, Bundle, inventory, coverage, report, semantic_digest, global_occurrence, Ledger, props_by_name, response_treatment
from oscal_conv_lib import ledger_gate, ledger_by_path, path_map_check, held_row, held_rows_match
from oscal_conv_lib import document_author, document_day, is_day, provenance, provenance_override, textify
from oscal_conv_lib import known_arguments, out_dir
from oscal_conv_lib import COMPAT, referred_to, lifecycle_default_record, lifecycle_default_line
from oscal_conv_lib import ASSESSMENT_CRITERIA_FILE

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
SRCDIR = os.path.join(ROOT, "sources", "nist")
ARGV = sys.argv[1:]
known_arguments(ARGV, ("--author-ref", "--date", "--out"))      # a misspelled argument stops the run; until 2026-11-14 it was ignored
OVERRIDE = provenance_override(ARGV)        # (author, date) the caller wants on every record, or (None, None)
OUTDIR = out_dir(ARGV, os.path.join(ROOT, "converted_examples", "US.IFA-GoodRead"))
NISTB = os.path.join(ROOT, "converted_examples", "US.SP800-53", "sp800-53-core-bundle")
NS = "https://ifa.gov/goodread"          # the source's own (fictional) agency domain
F_SYS = f"{NS}/facet/system@1"
F_OBS = f"{NS}/facet/observations@1"
F_RISKA = f"{NS}/facet/risk-analysis@1"    # L2 holding pen for the parked stdlib risk-analysis@1 (App. D)
F_FTGT = f"{NS}/facet/finding-target@1"    # the Finding-side residue of the retired risk@1 facet
F_AP = f"{NS}/facet/assessment-plan@1"
F_PROTO = f"{NS}/facet/protocols@1"
F_COMP = f"{NS}/facet/component@1"        # what OSCAL says of a component and the kernel has no field for
F_IMPL = f"{NS}/facet/implementation@1"   # the narrative of a control implementation, by statement

lang_wraps = collections.Counter()
T = make_T("en", lang_wraps)

# The conversion ledger (oscal_conv_lib.Ledger): every scalar of the seven
# source documents carries its origin from here on. A value handed on
# unchanged is recorded as a copy when the bundle is accounted for at the
# end; a value this script computes is stated where it is computed, with
# D(rule, function, inputs...), so that the rule can be applied again and
# compared. What reaches no destination and has no declared reason is listed
# as unaccounted. Nothing here changes what is written: the bundle is byte
# for byte the one the script wrote before the ledger existed.
led = Ledger()
D = led.derive

SOURCE_FILES = []        # (tag, file name, document) in the order loaded, for the manifest's provenance
def load(tag, fn, key):
    doc = json.load(open(os.path.join(SRCDIR, fn), encoding="utf-8"))
    tracked = led.source(tag, {key: doc[key]})
    SOURCE_FILES.append((tag, fn, tracked))
    return tracked[key]

SSP = load("ssp", "ifa_ssp.json", "system-security-plan")
AP = load("ap", "ifa_assessment-plan.json", "assessment-plan")
AR = load("ar", "ifa_assessment-results.json", "assessment-results")
POAM = load("poam", "ifa_plan-of-action-and-milestones.json", "plan-of-action-and-milestones")
LEV = load("lev", "oscal_leveraged-example_ssp.json", "system-security-plan")
LVG = load("lvg", "oscal_leveraging-example_ssp.json", "system-security-plan")
CDEF = load("cdef", "example-component-definition.json", "component-definition")

paths = collections.Counter()
for pfx, doc, key in [("ssp", SSP, "system-security-plan"), ("ap", AP, "assessment-plan"),
                      ("ar", AR, "assessment-results"), ("poam", POAM, "plan-of-action-and-milestones"),
                      ("lev", LEV, "system-security-plan"), ("lvg", LVG, "system-security-plan"),
                      ("cdef", CDEF, "component-definition")]:
    inventory({key: doc}, pfx, paths)

findings_notes = []
def note(s): findings_notes.append(s)

# ---------- carry the referenced Requirements (closure: in-bundle) ----------
bundle = Bundle(os.path.join(OUTDIR, "ifa-core-bundle"))
carried = []
for cid in ("ac-6-1", "ac-2"):
    p = os.path.join(NISTB, "objects", "req", f"{cid}.json")
    if not os.path.exists(p):
        raise SystemExit(f"missing {p} - run convert_nist.py first")
    obj = json.load(open(p, encoding="utf-8"))
    bundle.add(f"objects/req/{cid}.json", obj)
    carried.append(obj["id"])
REQ_AC61 = f"https://ns.nist.gov/sp800-53/req/AC-6.1"
REQ_AC2 = f"https://ns.nist.gov/sp800-53/req/AC-2"

# statement-id spelling: the SSP pair writes `ac-2_stmt.a`, the catalog `ac-2_smt.a`
n_stmt_respell = 0
def _stmt_norm(sid, cid):
    """pure: the ledger applies it again when it checks the destination"""
    s = sid
    if s.startswith(cid + "_"): s = s[len(cid) + 1:]
    if s.startswith("stmt"): s = "smt" + s[4:]
    return s
def stmt_norm(sid, cid):
    global n_stmt_respell
    if not sid: return None
    s = sid[len(cid) + 1:] if sid.startswith(cid + "_") else sid
    if s.startswith("stmt"): n_stmt_respell += 1
    return D("statement id without the control prefix, in the catalogue's spelling (stmt -> smt)", _stmt_norm, sid, cid)

# PUA codepoints in source text (the soware defect)
n_pua = 0
def pua_scan(v):
    global n_pua
    if isinstance(v, str):
        n_pua += sum(1 for ch in v if 0xE000 <= ord(ch) <= 0xF8FF)
    return v

# Two rules the script applies in several places, stated once. Each is a
# plain function of the source value, so the ledger can apply it again.
def kind_of(component):
    """Component.kind from the OSCAL component `type` (KIND_MAP, defined below)."""
    return D("component kind from the OSCAL component type (KIND_MAP)", lambda t: KIND_MAP[t], component["type"])
def req_of(control_id):
    """The Requirement a lower-case OSCAL control id names in the carried SP 800-53 bundle."""
    return D("requirement URI from the control id",
             lambda c: f"https://ns.nist.gov/sp800-53/req/{c.upper()}", control_id)
KIND_MAP = {"this-system": "system", "system": "system", "software": "software",
            "application": "software", "appliance": "hardware", "service": "service"}

# ---------- parties (landmark URIs by #16 - no party objects) ----------
def party_uri(doc, uuid, default_slug):
    for p in doc["metadata"].get("parties", []) or []:
        if p["uuid"] == uuid:
            # three source values meet here: the reference, the uuid of the party
            # it names, and that party's name. The rule fails if the two uuids differ.
            return D("party reference resolved by uuid; landmark URI from the party's name",
                     lambda ref, pid, name: f"{NS}/party/{slug(name)}" if ref == pid else None,
                     uuid, p["uuid"], p.get("name", default_slug))
    return f"{NS}/party/{default_slug}"

# ---------- roles: per Component and for the whole scope ----------
# OSCAL assigns roles at every level: to the document, to a component, to a
# statement, an exported capability, an activity, a task, a user. The bundle
# carries them at TWO levels only (author decision 2026-11-13): on the
# Component, in component@1, and for the whole scope, in system@1 of the
# system Component and in the method payload of the Assessment. An
# assignment made below those levels is rolled up to the Component it sits
# under, or to the scope where it has none: if that role and party is there
# already the lower occurrence is linked to it (Ledger.same), else it joins
# the list. One entry per role: {role, parties: [landmark URI, ...]}.
# A party the source defines without a name, or does not define, cannot be
# named by a landmark URI: its uuid is carried beside the role, under
# `party-uuids` (author, 2026-11-14), and the gap is counted as a finding
# about the source.
party_gaps = collections.Counter()
source_gaps = collections.Counter()      # other references the source leaves dangling, counted for the report
ROLE_LISTS = []        # (the facet or payload that will hold the list, the list): attached when every roll-up is done
def role_list(holder):
    roles = []; ROLE_LISTS.append((holder, roles)); return roles
def party_ref(doc, ref):
    """-> the landmark URI of the party `ref` names in `doc`, or None."""
    party = next((p for p in doc["metadata"].get("parties", []) or [] if p["uuid"] == ref), None)
    if party is None or not party.get("name"):
        gap = "does not define" if party is None else "defines without a name"
        party_gaps[gap] += 1
        return None
    return D("party reference resolved by uuid; landmark URI from the party's name",
             lambda r, pid, name: f"{NS}/party/{slug(name)}" if r == pid else None, ref, party["uuid"], party["name"])
def add_roles(roles, doc, assignments, where):
    """Adds OSCAL role assignments ({role-id, party-uuids?}) to a role list."""
    rule = f"a role assigned at {where}, carried once per Component or scope"
    for a in assignments or []:
        entry = next((e for e in roles if e["role"] == a["role-id"]), None)
        if entry is None:
            entry = {"role": a["role-id"]}; roles.append(entry)
        else:
            led.same(a["role-id"], entry["role"], rule)
        for ref in a.get("party-uuids", []) or []:
            uri = party_ref(doc, ref)
            if uri is None:         # no landmark URI can name it: its uuid stands beside the role
                kept = next((u for u in entry.get("party-uuids", []) if u == ref), None)
                if kept is None: entry.setdefault("party-uuids", []).append(ref)
                else: led.same(ref, kept, rule)
                continue
            kept = next((u for u in entry.get("parties", []) if u == uri), None)
            if kept is None: entry.setdefault("parties", []).append(uri)
            else: led.same(uri, kept, rule)
def component_facet(doc, comp, own_title=True):
    """component@1: what OSCAL says of a component and the kernel has no field
    for. -> (the facet, its role list). `own_title` is False where the
    Component's kernel title comes from elsewhere and this one would be lost."""
    f = {}
    if not own_title and comp.get("title") is not None: f["title"] = comp["title"]
    if comp.get("description") is not None: f["description"] = T(pua_scan(comp["description"]), "component")
    if comp.get("purpose") is not None: f["purpose"] = T(pua_scan(comp["purpose"]), "component")
    if comp.get("status", {}).get("state") is not None: f["status"] = comp["status"]["state"]
    props = props_by_name(comp.get("props"), led)
    if props: f["props"] = props
    roles = role_list(f)
    add_roles(roles, doc, comp.get("responsible-roles"), "the component")
    return f, roles

# ---------- who wrote a record, and when (backlog #69) ----------
# Pre-filled from what the record's source document says about itself: its
# author by document_author() of the library, the day of its last-modified.
# An OSCAL document names who is responsible for it, not who wrote one of its
# statements, so the document's author is the most the source gives - and
# the day is the latest day the record can have been written, not the day it
# was. Where the document names nobody the record gets no `provenance`: the
# validator reports it (AUTHOR-2) and the report of this run counts it.
# --author-ref and --date overwrite, field by field, on every record.
PROVENANCE = collections.Counter()      # how each record's `provenance` came about, for the report
def provenance_of(doc, record):
    """-> {author-ref, date} for `record`, a record taken from `doc`, or None."""
    meta = doc["metadata"]
    author = day = None
    if not OVERRIDE[0]:
        party = document_author(meta)
        if party is not None:
            author = D("the author of a record: the party its document names as author, as a landmark URI from the party's name",
                       lambda name: f"{NS}/party/{slug(name)}", party["name"])
    if not OVERRIDE[1] and document_day(meta):
        day = D("the date of a record: the day of its document's last-modified", lambda lm: lm[:10], meta["last-modified"])
    p = provenance(author, day, OVERRIDE)
    if p is None: PROVENANCE["none"] += 1; NO_AUTHOR.append(record)
    elif OVERRIDE[0] or OVERRIDE[1]: PROVENANCE["overwritten by the caller"] += 1
    else: PROVENANCE["from the source"] += 1
    return p
NO_AUTHOR = []
def authorized_on(value):
    """The day the source states for an authorization -> {date}, if it is a date; else nothing."""
    return {"date": value} if is_day(value) else {}

# ---------- references by uuid, resolved ----------
# OSCAL links its elements by uuid. Until 2026-11-13 this script followed none
# of those links: it built the edges of the bundle by hand for this one
# example set. Each edge is now derived from the reference the source gives:
# the uuid is looked up among the elements the script minted an id for, and
# the rule fails unless the reference and the element's uuid are the same.
# A reference that names nothing the document defines is a defect of the source: it is
# carried verbatim where it stands (author, 2026-11-14) and counted for the report.
COMPONENTS = {}     # component uuid -> (that uuid, the Component id minted for it, further inputs of the rule)
PROVIDED = {}       # provided uuid of an exported capability -> (that uuid, "<component id>#<capability id>")
RESPONSIBILITIES = {}   # responsibility uuid -> (that uuid, its provided-uuid reference)
def dangling(ref, what):
    """A reference that names nothing its source defines. Nothing is invented for it: no edge
    is derived. The caller carries the reference verbatim where it stands, under a member
    `unresolved-...` (author, 2026-11-14), and it is counted for the report as a defect of the source."""
    source_gaps[what] += 1
    return None
def component_ref(ref):
    """-> the Component minted for the component a reference names."""
    if ref not in COMPONENTS: return dangling(ref, "a response names a component its document does not define")
    uuid, cid, via = COMPONENTS[ref]
    if via:     # the leveraging plan's own entry for a leveraged component: through its inherited-uuid to the provider's
        return D("the provider's Component for the leveraged component a reference names (through its inherited-uuid)",
                 lambda r, cu, inherited, pu: cid if r == cu and inherited == pu else None, ref, uuid, *via)
    return D("the Component minted for the component a reference names by uuid",
             lambda r, cu: cid if r == cu else None, ref, uuid)
def provided_ref(ref):
    """-> the exported capability a provided-uuid names, as <component id>#<capability id>."""
    if ref not in PROVIDED: return dangling(ref, "a reference names an exported capability the leveraged plan does not define")
    uuid, capref = PROVIDED[ref]
    return D("the exported capability a reference names by its provided-uuid",
             lambda r, pu: capref if r == pu else None, ref, uuid)
def responsibility_ref(ref):
    """-> the exported capability whose customer responsibility a responsibility-uuid names."""
    if ref not in RESPONSIBILITIES:
        return dangling(ref, "a satisfied entry names a responsibility the leveraged plan does not define"
                             + (" (the uuid is an exported capability's)" if ref in PROVIDED else ""))
    uuid, provided = RESPONSIBILITIES[ref]
    capref = PROVIDED[provided][1]
    return D("the exported capability whose customer responsibility a reference names",
             lambda r, ru, pr, pu: capref if r == ru and pr == pu else None, ref, uuid, provided, PROVIDED[provided][0])

def evidence_ref(ref, observations):
    """-> the evidence URI of the observation a reference names, among the observations of its own document."""
    o = next((x for x in observations or [] if x["uuid"] == ref), None)
    if o is None: return dangling(ref, "a reference names an observation its document does not define")
    return D("evidence URI of the observation a reference names by uuid",
             lambda r, ou: f"{NS}/evidence/obs-{ou[:8]}" if r == ou else None, ref, o["uuid"])

# ---------- the narrative of a control implementation ----------
def implementation_facet(doc, ir):
    """implementation@1: the texts an SSP writes about how one control is
    implemented, kept under the statement they belong to. An Implementation
    says THAT a requirement is met and by what; these say how, in the
    source's words: the remark on the control, per statement its remark and
    each component's response (naming the Component it is by) with what it
    exports, inherits and satisfies (each naming the exported capability
    concerned).
    (What is exported as a capability or as a customer responsibility has its
    kernel place and is not repeated here.) A key is written only where the
    source has the text."""
    text = lambda v: T(pua_scan(v), "implementation")
    f = {}
    if doc["control-implementation"].get("description") is not None:
        f["description"] = text(doc["control-implementation"]["description"])
    if ir.get("remarks") is not None: f["remarks"] = text(ir["remarks"])
    statements = []
    for st in ir.get("statements", []) or []:
        entry = {"statement": D("statement id without the control prefix, in the catalogue's spelling (stmt -> smt)",
                                _stmt_norm, st["statement-id"], ir["control-id"])}
        if st.get("uuid") is not None: entry["uuid"] = st["uuid"]
        if st.get("remarks") is not None: entry["remarks"] = text(st["remarks"])
        responses = []
        for b in st.get("by-components", []) or []:
            r = {}
            if b.get("uuid") is not None: r["uuid"] = b["uuid"]
            component = component_ref(b["component-uuid"])
            if component is not None: r["component"] = component
            if b.get("description") is not None: r["description"] = text(b["description"])
            if b.get("export", {}).get("description") is not None: r["export"] = text(b["export"]["description"])
            for key, ref_key, resolve in (("inherited", "provided-uuid", provided_ref),
                                          ("satisfied", "responsibility-uuid", responsibility_ref)):
                entries = []
                for x in b.get(key, []) or []:
                    e = {}
                    capability = resolve(x[ref_key]) if x.get(ref_key) is not None else None
                    if capability is not None: e["capability"] = capability
                    elif x.get(ref_key) is not None: e[f"unresolved-{ref_key}"] = x[ref_key]    # a defect of the source
                    if x.get("uuid") is not None: e["uuid"] = x["uuid"]
                    if x.get("description") is not None: e["description"] = text(x["description"])
                    if e: entries.append(e)
                if entries: r[key] = entries
            responses.append(r)
        if responses: entry["responses"] = responses
        statements.append(entry)
    if statements: f["statements"] = statements
    return f

# ================= 1. the GoodRead system (SSP) =================
V_SSP = SSP["metadata"]["version"]
sc = SSP["system-characteristics"]
COMP_SYS = f"{NS}/component/system1234"
AUTH_ATO = "auth-ifa-ato"
def system_facet(doc):
    """The system@1 facet of one system security plan: what its
    system-characteristics say (ids, status, sensitivity, impact, boundary,
    the narratives) and its users with their privileges. One function for the
    main system, the leveraged and the leveraging one. Until 2026-11-13 only
    the main system got all of this, while the path map said the other two
    carried their FIPS-199 levels. A key is written only where the source has
    the value, so nothing is filled in."""
    sc, si, f = doc["system-characteristics"], doc["system-implementation"], {}
    text = lambda v: T(pua_scan(v), "system")
    def put(key, value, wrap=lambda v: v):
        if value is not None: f[key] = wrap(value)
    put("system-ids", sc.get("system-ids"))
    put("description", sc.get("description"), text)
    put("status", sc.get("status", {}).get("state"))
    put("sensitivity", sc.get("security-sensitivity-level"))
    put("date-authorized", sc.get("date-authorized"))
    f["impact"] = {"information-types": sc.get("system-information", {}).get("information-types", []),
                   "security-impact-level": sc.get("security-impact-level", {})}
    put("boundary", sc.get("authorization-boundary", {}).get("description"), text)
    put("network-architecture", sc.get("network-architecture", {}).get("description"), text)
    put("data-flow", sc.get("data-flow", {}).get("description"), text)
    put("remarks", sc.get("remarks"), text)
    users = []
    for u in si.get("users", []) or []:
        user = {}
        if u.get("uuid") is not None: user["uuid"] = u["uuid"]
        if u.get("title") is not None: user["title"] = u["title"]
        if u.get("description") is not None: user["description"] = pua_scan(u["description"])
        user["privileges"] = [{"title": a.get("title"), "functions": a.get("functions-performed", [])}
                              for a in u.get("authorized-privileges", []) or []]
        users.append(user)
    if users: f["users"] = users
    # `props` and `components` mean what they meant; the class of each prop
    # and the props of each implemented component stand beside them
    # (`component-props` has one entry per entry of `components`, in order)
    inventory = [{**({"uuid": i["uuid"]} if i.get("uuid") is not None else {}),
                  "description": pua_scan(i.get("description")),
                  "props": props_by_name(i.get("props"), led),       # a repeated name keeps every value
                  "prop-classes": props_by_name(i.get("props"), led, field="class"),
                  "components": [c["component-uuid"] for c in i.get("implemented-components", []) or []],
                  "component-props": [props_by_name(c.get("props"), led) for c in i.get("implemented-components", []) or []]}
                 for i in si.get("inventory-items", []) or []]
    if inventory: f["inventory-items"] = inventory
    return f

ssp_comp = SSP["system-implementation"]["components"][0]
sysf_ssp = system_facet(SSP)
compf_ssp, roles_ssp = component_facet(SSP, ssp_comp)
add_roles(role_list(sysf_ssp), SSP, SSP["metadata"].get("responsible-parties"), "the document")
add_roles(roles_ssp, SSP, [{"role-id": r} for u in SSP["system-implementation"].get("users", []) or []
                           for r in u.get("role-ids", []) or []], "a user")
comp_sys = {"id": COMP_SYS, "version": V_SSP, "label": sc["system-name"], "lifecycle": "active",
            "title": ssp_comp.get("title", sc["system-name"]), "kind": kind_of(ssp_comp),
            "capabilities": [],
            "authorizations": [{"id": AUTH_ATO,
                                "authority-ref": f"{NS}/party/authorizing-official",
                                "scope-label": D("ATO scope label: date authorized and sensitivity level",
                                                 lambda d, l: f"ATO {d} ({l})",
                                                 sc.get("date-authorized", "?"), sc.get("security-sensitivity-level", "?")),
                                **authorized_on(sc.get("date-authorized"))}],
            "facets": {F_SYS: sysf_ssp, F_COMP: compf_ssp, COMPAT: {"uuid": ssp_comp["uuid"]}}}

# implemented-requirement ac-6.1 -> capability + Implementation
ir = SSP["control-implementation"]["implemented-requirements"][0]
bc = ir["by-components"][0]
REQ_IR = req_of(ir["control-id"])        # the implemented requirement names its control: ac-6.1
assert REQ_IR == REQ_AC61, f"the SSP implements {ir['control-id']}, the bundle carries {REQ_AC61}"
comp_sys["capabilities"].append({"id": "cap-ac-6.1", "requirement-ref": REQ_IR,
                                 "description": pua_scan(bc.get("description", ""))})
compf_ssp.setdefault("capabilities", []).append({"capability": "cap-ac-6.1", "uuid": bc["uuid"]})   # the by-component it is made from
pbind = {sp["param-id"]: (sp["values"][0] if len(sp["values"]) == 1 else sp["values"])
         for sp in SSP["control-implementation"].get("set-parameters", [])}
for v in pbind.values(): pua_scan(v if isinstance(v, str) else " ".join(v))
# verify bindings name declared params of the carried AC-6.1
ac61 = json.load(open(os.path.join(NISTB, "objects", "req", "ac-6-1.json"), encoding="utf-8"))
declared_61 = {p["name"] for s in ac61["statements"] for p in s.get("parameters", [])}
unresolved_bind = sorted(set(pbind) - declared_61)
COMPONENTS[ssp_comp["uuid"]] = (ssp_comp["uuid"], COMP_SYS, None)
bundle.add("objects/component/system1234.json", comp_sys)
IMPL_SYS = f"{NS}/impl/system1234-ac-6.1"
bundle.add("objects/impl/system1234-ac-6-1.json",
           {"id": IMPL_SYS, "version": V_SSP, "lifecycle": "active",
            "component-ref": component_ref(bc["component-uuid"]), "requirement-ref": REQ_IR,
            "responsibility": "provider",
            "satisfied-by": [{"capability-ref": "cap-ac-6.1"}],
            "parameter-bindings": pbind,
            "status": bc.get("implementation-status", {}).get("state", "implemented"),
            "evidence-refs": [D("document reference from the SSP's uuid", lambda u: f"{NS}/doc/ssp-{u}", SSP["uuid"])],
            "facets": {F_IMPL: implementation_facet(SSP, ir), COMPAT: {"uuid": ir["uuid"]}},
            **({"provenance": pv} if (pv := provenance_of(SSP, IMPL_SYS)) else {})})

# ================= 2. leveraged / leveraging pair (D5) =================
V_LEV, V_LVG = LEV["metadata"]["version"], LVG["metadata"]["version"]
COMP_IAAS = f"{NS}/component/csp-iaas"
COMP_APP = f"{NS}/component/csp-application"
COMP_SAAS = f"{NS}/component/saas"
COMP_APPL = f"{NS}/component/access-control-appliance"
AUTH_CSP = "auth-csp-iaas-2018"

lev_sys_comp = next(c for c in LEV["system-implementation"]["components"] if c["type"] == "this-system")
app_comp = next(c for c in LEV["system-implementation"]["components"] if c["type"] != "this-system")
lvg_sys_comp = next(c for c in LVG["system-implementation"]["components"] if c["type"] == "this-system")
appl = next(c for c in LVG["system-implementation"]["components"] if c["type"] == "appliance")
for comp, cid in ((lev_sys_comp, COMP_IAAS), (app_comp, COMP_APP), (lvg_sys_comp, COMP_SAAS), (appl, COMP_APPL)):
    COMPONENTS[comp["uuid"]] = (comp["uuid"], cid, None)
for stand_in in LVG["system-implementation"]["components"]:     # the leveraging plan's entries for leveraged components
    inherited = next((p["value"] for p in stand_in.get("props", []) or [] if p["name"] == "inherited-uuid"), None)
    if inherited in COMPONENTS and stand_in["uuid"] not in COMPONENTS:
        COMPONENTS[stand_in["uuid"]] = (stand_in["uuid"], COMPONENTS[inherited][1], (inherited, COMPONENTS[inherited][0]))

# What the leveraged plan exports. A capability goes on the Component whose
# response exports it: until 2026-11-13 both went on the system, although the
# second is exported by the application. The system's Implementation cites its
# own by id and its member's as <component id>#<capability id>.
lev_ir = LEV["control-implementation"]["implemented-requirements"][0]
lev_caps = {COMP_IAAS: [], COMP_APP: []}
lev_cap_refs, lev_resp, uuid_placeholder = [], [], 0
for st in lev_ir.get("statements", []) or []:
    for b in st.get("by-components", []) or []:
        exp = b.get("export", {})
        owner = COMPONENTS[b["component-uuid"]][1]
        for i, pv in enumerate(exp.get("provided", []) or []):
            if pv["uuid"].startswith("11111111"): uuid_placeholder += 1
            cap_id = f"cap-provided-{len(lev_cap_refs) + 1}"
            lev_caps[owner].append({"id": cap_id, "requirement-ref": REQ_AC2,
                                    "description": pua_scan(pv.get("description", ""))})
            lev_cap_refs.append(cap_id if owner == COMP_IAAS else f"{owner}#{cap_id}")
            PROVIDED[pv["uuid"]] = (pv["uuid"], f"{owner}#{cap_id}")
        for rs in exp.get("responsibilities", []) or []:
            if rs["uuid"].startswith("11111111"): uuid_placeholder += 1
            RESPONSIBILITIES[rs["uuid"]] = (rs["uuid"], rs["provided-uuid"])
            capability = provided_ref(rs["provided-uuid"])
            lev_resp.append({"uuid": rs["uuid"], "description": pua_scan(rs.get("description", "")),
                             **({"capability": capability} if capability is not None else {})})
la = (LVG["system-implementation"].get("leveraged-authorizations") or [{}])[0]
compf_iaas, roles_iaas = component_facet(LEV, lev_sys_comp, own_title=False)     # its title is the document's
compf_app, roles_app = component_facet(LEV, app_comp)
compf_saas, roles_saas = component_facet(LVG, lvg_sys_comp, own_title=False)
compf_appl, roles_appl = component_facet(LVG, appl)
for doc, roles in ((LEV, roles_iaas), (LVG, roles_saas)):
    add_roles(roles, doc, [{"role-id": r} for u in doc["system-implementation"].get("users", []) or []
                           for r in u.get("role-ids", []) or []], "a user")
# roles below the component: a response by a component, what it exports, what it satisfies.
# Each goes to the Component the response is by; the leveraging plan's own entries for the
# leveraged system and application are not Components here, so theirs go to the leveraging system.
for doc, fallback, lookup in ((LEV, roles_iaas, {lev_sys_comp["uuid"]: roles_iaas, app_comp["uuid"]: roles_app}),
                              (LVG, roles_saas, {lvg_sys_comp["uuid"]: roles_saas, appl["uuid"]: roles_appl})):
    for st in doc["control-implementation"]["implemented-requirements"][0].get("statements", []) or []:
        for b in st.get("by-components", []) or []:
            roles = lookup.get(b.get("component-uuid"), fallback)
            add_roles(roles, doc, b.get("responsible-roles"), "a response by the component")
            for pv in b.get("export", {}).get("provided", []) or []:
                add_roles(roles, doc, pv.get("responsible-roles"), "an exported capability")
            for rs in b.get("export", {}).get("responsibilities", []) or []:
                add_roles(roles, doc, rs.get("responsible-roles"), "an exported responsibility")
            for sa in b.get("satisfied", []) or []:
                add_roles(roles, doc, sa.get("responsible-roles"), "a satisfied responsibility")
# The leveraged authorization: its kernel entry on the provider's Component has no member for the
# source's uuid, its links and its party; they stand beside it in component@1, naming it by id. A
# party the leveraging plan defines without a name is carried by its uuid, as the source writes it.
la_party = party_ref(LVG, la["party-uuid"]) if la.get("party-uuid") is not None else None
compf_iaas.setdefault("authorizations", []).append(
    {"authorization": AUTH_CSP, **{k: la[k] for k in ("uuid", "links") if la.get(k) is not None},
     **({"party": la_party} if la_party else {"party-uuid": la["party-uuid"]} if la.get("party-uuid") is not None else {})})
# The leveraging plan lists the leveraged system and its application as components of its
# own. The provider's Components, converted from the leveraged plan, stand for them: a value
# that equals the provider's is linked to it (Ledger.same); what differs is carried on the
# provider's Component, in component@1 `listed-by-leveraging-plan`, in the source's shape.
for stand_in in LVG["system-implementation"]["components"]:
    inherited = props_by_name(stand_in.get("props")).get("inherited-uuid")
    provider = next((c for c in LEV["system-implementation"]["components"] if c["uuid"] == inherited), None)
    if provider is None: continue
    own = {}
    for k, v in stand_in.items():
        if v == provider.get(k):
            led.same(v, provider[k], "the leveraging plan's entry for a leveraged component; the provider's Component stands for it")
        else: own[k] = v
    {lev_sys_comp["uuid"]: compf_iaas, app_comp["uuid"]: compf_app}[provider["uuid"]]["listed-by-leveraging-plan"] = own
bundle.add("objects/component/csp-iaas.json",
           {"id": COMP_IAAS, "version": V_LEV, "label": LEV["system-characteristics"]["system-name"],
            "lifecycle": "active", "title": LEV["metadata"]["title"],
            "kind": kind_of(lev_sys_comp),
            "members": [{"component-ref": COMP_APP, "context": "application"}],
            "capabilities": lev_caps[COMP_IAAS],
            "authorizations": [{"id": AUTH_CSP,
                                "authority-ref": f"{NS}/party/csp-authorizing-official",
                                "scope-label": D("leveraged authorization scope label: its title and date",
                                                 lambda t, d: f"{t} ({d})",
                                                 la.get("title", "CSP IaaS leveraged authorization"),
                                                 la.get("date-authorized", "?")),
                                **authorized_on(la.get("date-authorized"))}],
            "facets": {F_SYS: {**system_facet(LEV), "customer-responsibilities": lev_resp}, F_COMP: compf_iaas,
                       COMPAT: {"uuid": lev_sys_comp["uuid"]}}})
bundle.add("objects/component/csp-application.json",
           {"id": COMP_APP, "version": V_LEV, "label": app_comp.get("title", "Application"),
            "lifecycle": "active", "title": app_comp.get("title", "Application"), "kind": kind_of(app_comp),
            **({"capabilities": lev_caps[COMP_APP]} if lev_caps[COMP_APP] else {}),
            "facets": {F_COMP: compf_app, COMPAT: {"uuid": app_comp["uuid"]}}})
kind_mapped = collections.Counter()
kind_mapped["appliance->hardware"] += 1
appl_title = D("title without the decoration asterisks", lambda t: t.strip(" *"), appl.get("title", ""))
bundle.add("objects/component/access-control-appliance.json",
           {"id": COMP_APPL, "version": V_LVG, "label": appl_title,
            "lifecycle": "active", "title": appl_title,
            "kind": kind_of(appl),
            "capabilities": [{"id": "cap-consumer-ac-2a", "requirement-ref": REQ_AC2,
                              # what THIS component says it satisfied: until 2026-11-13 the first
                              # `satisfied` text of the statement was taken, which is another component's
                              "description": pua_scan(next((sa.get("description", "")
                                  for st in LVG["control-implementation"]["implemented-requirements"][0].get("statements", [])
                                  for b in st.get("by-components", []) if b["component-uuid"] == appl["uuid"]
                                  for sa in b.get("satisfied", []) or []), ""))}],
            "facets": {F_COMP: compf_appl, COMPAT: {"uuid": appl["uuid"]}}})
bundle.add("objects/component/saas.json",
           {"id": COMP_SAAS, "version": V_LVG,
            "label": LVG["system-characteristics"]["system-name"], "lifecycle": "active",
            "title": LVG["metadata"]["title"],
            "kind": kind_of(lvg_sys_comp),
            "members": [{"component-ref": COMP_IAAS, "context": "leveraged system"},
                        {"component-ref": COMP_APPL, "context": "internal appliance"}],
            "facets": {F_SYS: system_facet(LVG), F_COMP: compf_saas, COMPAT: {"uuid": lvg_sys_comp["uuid"]}}})
lvg_ir = LVG["control-implementation"]["implemented-requirements"][0]
# what the leveraging plan inherits: the reference names an exported capability, and the
# edge names the leveraged system that holds the authorization
_inh = next(x for st in lvg_ir.get("statements", []) or [] for b in st.get("by-components", []) or []
            for x in b.get("inherited", []) or [])
inherited_system = D("inherited-from: the leveraged system whose component exports the capability a reference names",
                     lambda r, pu: COMP_IAAS if r == pu else None, _inh["provided-uuid"], PROVIDED[_inh["provided-uuid"]][0])
lvg_sids = sorted({stmt_norm(st.get("statement-id"), lvg_ir["control-id"])
                   for st in lvg_ir.get("statements", []) or [] if st.get("statement-id")})
lvg_bind = {sp["param-id"]: (sp["values"][0] if len(sp["values"]) == 1 else sp["values"])
            for sp in lvg_ir.get("set-parameters", [])}
ac2 = json.load(open(os.path.join(NISTB, "objects", "req", "ac-2.json"), encoding="utf-8"))
declared_2 = {p["name"] for s in ac2["statements"] for p in s.get("parameters", [])}
unresolved_bind = sorted(set(unresolved_bind) | (set(lvg_bind) - declared_2))
bundle.add("objects/impl/saas-ac-2.json",
           {"id": f"{NS}/impl/saas-ac-2", "version": V_LVG, "lifecycle": "active",
            "component-ref": COMP_SAAS, "requirement-ref": REQ_AC2,
            "statement-refs": lvg_sids,
            "responsibility": "shared",
            "satisfied-by": [{"inherited-from": {"component-ref": inherited_system, "basis-ref": AUTH_CSP}},
                             {"capability-ref": f"{COMP_APPL}#cap-consumer-ac-2a"}],
            "parameter-bindings": lvg_bind,
            "status": "implemented",
            "evidence-refs": [D("document reference from the SSP's uuid", lambda u: f"{NS}/doc/ssp-{u}", LVG["uuid"])],
            "facets": {F_IMPL: implementation_facet(LVG, lvg_ir), COMPAT: {"uuid": lvg_ir["uuid"]}},
            **({"provenance": pv} if (pv := provenance_of(LVG, f"{NS}/impl/saas-ac-2")) else {})})
lev_sids = sorted({stmt_norm(st.get("statement-id"), lev_ir["control-id"])
                   for st in lev_ir.get("statements", []) or [] if st.get("statement-id")})
lev_bind = {sp["param-id"]: (sp["values"][0] if len(sp["values"]) == 1 else sp["values"])
            for sp in lev_ir.get("set-parameters", [])}
unresolved_bind = sorted(set(unresolved_bind) | (set(lev_bind) - declared_2))
bundle.add("objects/impl/csp-iaas-ac-2.json",
           {"id": f"{NS}/impl/csp-iaas-ac-2", "version": V_LEV, "lifecycle": "active",
            "component-ref": COMP_IAAS, "requirement-ref": REQ_AC2,
            "statement-refs": lev_sids,
            "responsibility": "provider",
            "satisfied-by": [{"capability-ref": ref} for ref in lev_cap_refs],
            "parameter-bindings": lev_bind,
            "status": "implemented",
            "evidence-refs": [D("document reference from the SSP's uuid", lambda u: f"{NS}/doc/ssp-{u}", LEV["uuid"])],
            "facets": {F_IMPL: implementation_facet(LEV, lev_ir), COMPAT: {"uuid": lev_ir["uuid"]}},
            **({"provenance": pv} if (pv := provenance_of(LEV, f"{NS}/impl/csp-iaas-ac-2")) else {})})

# ================= 3. component-definition example =================
# The mapping is the one of the pack builder's OSCAL import
# (one-page-apps/jascon-pack-builder.html, importOscal; CP-ADVICE-1 section 9):
# one capability per implemented requirement; its statements become
# `statement-ids` in the catalogue's spelling and their texts follow the
# requirement's text, each under its clause id; `set-parameters` become
# `parameter-bindings` under the name the catalogue declares; OSCAL's
# `{{ insert: param, x }}` becomes `{param:<that name>}`. The catalogue is
# the SP 800-53 conversion in this repository. Until 2026-11-13 this section
# read the control id and the description and nothing below them, while the
# path map counted the rest as carried (backlog #64).
INSERT = re.compile(r"\{\{\s*insert:\s*param,\s*([^}\s]+)\s*\}\}")
def nist_req(control_id):
    """The Requirement the SP 800-53 conversion holds for an OSCAL control id, or None."""
    p = os.path.join(NISTB, "objects", "req", slug(control_id) + ".json")
    return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else None
def param_name(req, pid):
    """A parameter name as the catalogue declares it: the id itself, or the
    declared name whose alt-identifiers list it (the Rev 4 `_prm_` ids)."""
    if not req: return pid
    names = [p["name"] for st in req.get("statements", []) for p in st.get("parameters", [])]
    if pid in names: return pid
    def walk(v):
        if isinstance(v, dict):
            for k, x in v.items():
                if k in names and isinstance(x, dict) and pid in (x.get("alt-identifiers") or []): return k
                hit = walk(x)
                if hit: return hit
        elif isinstance(v, list):
            for x in v:
                hit = walk(x)
                if hit: return hit
        return None
    return walk(req.get("facets")) or pid
def capability_text(req):
    """-> the pure rule that writes a capability's text from the implemented
    requirement's description, its control id, and (statement-id, text) pairs."""
    unmark = lambda t: INSERT.sub(lambda m: "{param:%s}" % param_name(req, m.group(1)), t)
    def text(description, control_id, *pairs):
        parts = [unmark(description)] if description else []
        parts += [f"{_stmt_norm(sid, control_id)}: {unmark(d)}" for sid, d in zip(pairs[0::2], pairs[1::2]) if d]
        return "\n\n".join(parts)
    return text
V_CDEF = CDEF["metadata"]["version"]
cdef_resources = {r["uuid"]: r for r in CDEF.get("back-matter", {}).get("resources", []) or []}
cdef_stats = collections.Counter()
for c in CDEF.get("components", []) or []:
    caps, control_impls, cap_uuids = [], [], []
    for ci in c.get("control-implementations", []) or []:
        entry = {"uuid": ci["uuid"], "description": T(pua_scan(ci.get("description", "")), "component")}
        # `source` is a link into the back-matter; what it names is carried, by its JSON link
        res = cdef_resources.get(ci.get("source", "")[1:]) if ci.get("source", "").startswith("#") else None
        if res and res.get("rlinks"):
            href = next((l["href"] for l in res["rlinks"] if l["href"].lower().endswith(".json")), res["rlinks"][0]["href"])
            entry["source"] = D("control-implementation source: the back-matter resource it names, by its JSON link",
                                lambda ref, rid, h: h if ref == "#" + rid else None, ci["source"], res["uuid"], href)
            if not re.search(r"800-53", href):
                note(f"control implementation of {c.get('title')} names {href}; its requirement-refs are minted in the "
                     f"SP 800-53 namespace all the same")
        elif ci.get("source"):
            entry["source"] = ci["source"]
        control_impls.append(entry)
        if ci.get("set-parameters"):
            note(f"{len(ci['set-parameters'])} set-parameters on a whole control implementation are not placed "
                 f"(the pack builder puts them where the catalogue declares the parameter)")
        for cir in ci.get("implemented-requirements", []) or []:
            cid = cir.get("control-id", "")
            req = nist_req(cid)
            statements = [st for st in cir.get("statements", []) or [] if st.get("statement-id")]
            sids = []
            for st in statements:
                sid = stmt_norm(st["statement-id"], cid)
                if sid not in sids: sids.append(sid)
            description = cir.get("description", "")
            rule = capability_text(req)
            pairs = [x for st in statements for x in (st["statement-id"], st.get("description", ""))]
            if rule(description, cid, *pairs) != description:      # something is joined or respelled: say so
                description = D("capability text: the requirement's description, then each statement's text under "
                                "its clause id; OSCAL parameter insertions respelled {param:<catalogue name>}",
                                rule, description, cid, *pairs)
            bindings = {}
            for sp in cir.get("set-parameters", []) or []:
                pid, values = sp["param-id"], sp.get("values", [])
                name = pid if param_name(req, pid) == pid else \
                    D("parameter name as the catalogue declares it (the OSCAL param-id is one of its alt-identifiers)",
                      lambda p, req=req: param_name(req, p), pid)
                decl = next((p for st in (req or {}).get("statements", []) for p in st.get("parameters", [])
                             if p["name"] == name), None)
                many = bool(decl and decl.get("type") == "choice" and decl.get("cardinality") == "many")
                bindings[name] = values if many or len(values) != 1 else values[0]
                cdef_stats["bindings"] += 1
                if req is None or decl is None: cdef_stats["bindings the catalogue does not declare"] += 1
            cap = {"id": D("capability id from the control id", lambda c: f"cap-{slug(c)}", cir.get("control-id", "x")),
                   "requirement-ref": req_of(cid)}
            if sids: cap["statement-ids"] = sids
            cap["description"] = pua_scan(description)
            if bindings: cap["parameter-bindings"] = bindings
            caps.append(cap)
            # the uuids of the implemented requirement and its statements, beside the capability made from them
            cap_uuids.append({"capability": cap["id"], "uuid": cir["uuid"],
                              **({"statements": [{"statement": D("statement id without the control prefix, in the "
                                                                 "catalogue's spelling (stmt -> smt)",
                                                                 _stmt_norm, st["statement-id"], cid), "uuid": st["uuid"]}
                                                 for st in statements]} if statements else {})})
            cdef_stats["clauses"] += len(sids)
    kind = D("component kind from the OSCAL component type (KIND_MAP)", lambda t: KIND_MAP.get(t, "software"),
             c.get("type", "software"))
    obj = {"id": D("component id from its title", lambda t: f"{NS}/component/{slug(t)}", c.get("title", "component")),
           "version": V_CDEF, "label": c.get("title", ""), "lifecycle": "active",
           "title": c.get("title", ""), "kind": kind}
    if caps: obj["capabilities"] = caps
    protos = [{"uuid": p.get("uuid"), "name": p.get("name"), "title": p.get("title"),
               "port-ranges": p.get("port-ranges", [])} for p in c.get("protocols", []) or []]
    if protos: obj.setdefault("facets", {})[F_PROTO] = {"protocols": protos}
    compf, roles = component_facet(CDEF, c)
    for ci in c.get("control-implementations", []) or []:
        for cir in ci.get("implemented-requirements", []) or []:
            for st in cir.get("statements", []) or []:
                add_roles(roles, CDEF, st.get("responsible-roles"), "a statement")
    if control_impls: compf["control-implementations"] = control_impls
    if cap_uuids: compf["capabilities"] = cap_uuids
    obj.setdefault("facets", {})[F_COMP] = compf
    obj["facets"][COMPAT] = {"uuid": c["uuid"]}
    bundle.add(f"objects/component/{slug(c.get('title', 'component'))}.json", obj)

# ================= 4. Assessment (AR result; AP as method) =================
V_AR = AR["metadata"]["version"]
res = AR["results"][0]
ASSESS = f"{NS}/assessment/conmon-2023-06"
def subject_ref(ref):
    """An observation's subject, as the Component minted for the SSP component it names."""
    if ref != ssp_comp["uuid"]: return dangling(ref, "an observation names a subject the SSP does not define")
    return D("observation subject: the Component minted for the SSP component it names",
             lambda r, cu: COMP_SYS if r == cu else None, ref, ssp_comp["uuid"])
observations = []
for src, tag in ((res.get("observations", []), "ar"), (POAM.get("observations", []), "poam")):
    for o in src:
        subjects = [x for x in (subject_ref(sj["subject-uuid"]) for sj in o.get("subjects", []) or []) if x is not None]
        for sj in o.get("subjects", []) or []:
            if sj.get("type") is not None and sj["subject-uuid"] == ssp_comp["uuid"]:
                led.rebuilt(sj["type"], "the type of an observation's subject: `component`, the kind of the object its "
                                        "subject-uuid resolves to (the SSP component, carried as a Component)",
                            lambda r, cu: "component" if r == cu else None, sj["subject-uuid"], ssp_comp["uuid"])
        observations.append({"id": D("evidence URI from the first eight characters of the observation uuid",
                                     lambda u: f"{NS}/evidence/obs-{u[:8]}", o["uuid"]),
                             "title": o.get("title"), "description": T(pua_scan(o.get("description", "")), "observation"),
                             "methods": o.get("methods", []),
                             **({"types": o["types"]} if o.get("types") else {}),
                             **({"subjects": subjects} if subjects else {}),
                             "collected": o.get("collected"),
                             **({"expires": o["expires"]} if o.get("expires") else {}),
                             **({"remarks": T(pua_scan(o["remarks"]), "observation")} if o.get("remarks") else {}),
                             "source-doc": tag})
# dedupe by uuid (the engineer-role observation appears in both AR and POA&M)
seen, obs_dedup = {}, []
for o in observations:
    if o["id"] in seen:
        kept = seen[o["id"]]
        note(f"observation carried in both AR and POA&M (deduped): {o['title']}")
        # The ledger links every value of the dropped twin to the kept one and
        # checks that the two are equal. Where the twin says something else,
        # that is not a duplicate: it is kept beside the first, under
        # `variants`, with the document it comes from.
        differs = [k for k in o if k not in ("id", "source-doc") and o[k] != kept.get(k)]
        led.same({k: v for k, v in o.items() if k not in differs}, kept,
                 "the same observation in AR and POA&M (one uuid), kept once")
        if differs:
            kept.setdefault("variants", []).append({"source-doc": o["source-doc"], **{k: o[k] for k in differs}})
            note(f"**The two copies of one observation differ** (source finding): `{o['title']}` has the same uuid in "
                 f"the assessment results and in the POA&M, and its {', '.join('`' + k + '`' for k in differs)} "
                 f"differ{'s' if len(differs) == 1 else ''} between them. Both are carried.")
        continue
    seen[o["id"]] = o; obs_dedup.append(o)
# The method payload: what the plan lays out and what the results add to it.
# The results define an activity and a task of their own (the TEST that was
# run; the plan has the EXAMINE), so both documents contribute, each entry
# saying which. Until 2026-11-13 only the plan's were written, while the path
# map said the results' activities were "duplicated from AP; carried once".
def activity_entry(a, tag):
    return {"uuid": a["uuid"], "title": a.get("title"),
            "description": T(pua_scan(a.get("description", "")), "ap"),
            "steps": [{"uuid": st["uuid"], "title": st.get("title"),
                       "description": T(pua_scan(st.get("description", "")), "ap"),
                       **({"remarks": T(pua_scan(st["remarks"]), "ap")} if st.get("remarks") else {})}
                      for st in a.get("steps", []) or []],
            **({"props": props_by_name(a["props"], led)} if a.get("props") else {}),
            "related-controls": [ic["control-id"] for cs in a.get("related-controls", {}).get("control-selections", []) or []
                                 for ic in cs.get("include-controls", []) or []],
            "source-doc": tag}
def task_entry(t, activities, tag):
    """A task names its activity by uuid; the payload names it by its title."""
    e = {"uuid": t["uuid"], "title": t.get("title"), "type": t.get("type")}
    if t.get("description") is not None: e["description"] = T(pua_scan(t["description"]), "ap")
    named, unresolved, subjects = [], [], []
    for aa in t.get("associated-activities", []) or []:
        subjects += aa.get("subjects", []) or []         # with their type tags, as the source writes them
        act = next((a for a in activities if a["uuid"] == aa["activity-uuid"]), None)
        if act is None:
            dangling(aa["activity-uuid"], "a task names an activity its document does not define")
            unresolved.append(aa["activity-uuid"])
            continue
        named.append(D("task activity: the title of the activity it names by uuid",
                       lambda r, au, title: title if r == au else None, aa["activity-uuid"], act["uuid"], act["title"]))
    if named: e["activities"] = named
    if unresolved: e["unresolved-activity-uuids"] = unresolved      # a defect of the source, carried verbatim
    if subjects: e["subjects"] = subjects
    if t.get("remarks") is not None: e["remarks"] = T(pua_scan(t["remarks"]), "ap")
    e["source-doc"] = tag
    return e
ap_acts = AP.get("local-definitions", {}).get("activities", []) or []
ar_acts = AR.get("local-definitions", {}).get("activities", []) or []
ap_payload = {"activities": [activity_entry(a, "ap") for a in ap_acts] + [activity_entry(a, "ar") for a in ar_acts],
              "tasks": [task_entry(t, ap_acts, "ap") for t in AP.get("tasks", []) or []] +
                       [task_entry(t, ar_acts, "ar") for t in res.get("local-definitions", {}).get("tasks", []) or []],
              "subjects": [{**({"type": sj["type"]} if sj.get("type") is not None else {}),
                            "description": T(pua_scan(sj["description"]), "ap")}
                           for sj in AP.get("assessment-subjects", []) or [] if sj.get("description") is not None],
              "reviewed-controls": [ic["control-id"] for cs in AP["reviewed-controls"]["control-selections"]
                                    for ic in cs["include-controls"]]}
if not ap_payload["subjects"]: del ap_payload["subjects"]
# who assesses: one list for the Assessment, from the plan and the results and from
# every activity and task below them
roles_assessment = role_list(ap_payload)
for doc, what in ((AP, "the assessment plan"), (AR, "the assessment results")):
    add_roles(roles_assessment, doc, doc["metadata"].get("responsible-parties"), what)
    for a in doc.get("local-definitions", {}).get("activities", []) or []:
        add_roles(roles_assessment, doc, a.get("responsible-roles"), "an activity")
for t in (AP.get("tasks", []) or []) + (res.get("local-definitions", {}).get("tasks", []) or []):
    add_roles(roles_assessment, AP, t.get("responsible-roles"), "a task")
finding_src = res["findings"][0]
# the result reviews one control, and it is the one the Assessment is about
reviewed = [req_of(ic["control-id"]) for cs in res["reviewed-controls"]["control-selections"]
            for ic in cs["include-controls"]]
assert reviewed == [REQ_AC61], f"the assessment result reviews {reviewed}, the bundle carries {REQ_AC61}"
bundle.add("objects/assessment/conmon-2023-06.json",
           {"id": ASSESS, "version": V_AR, "lifecycle": "active",
            "title": res.get("title", AR["metadata"]["title"]),
            "subject-refs": [COMP_SYS, *reviewed],
            "method": {F_AP: ap_payload},
            "performer-ref": party_uri(AR, AR["metadata"]["responsible-parties"][0]["party-uuids"][0], "assessor")
                             if AR["metadata"].get("responsible-parties") else f"{NS}/party/assessor",
            "time": res.get("start", "2023-06-02"),
            "result": D("assessment result from the finding's target status",
                        lambda st: "not-satisfied" if st == "not-satisfied" else "satisfied",
                        finding_src["target"]["status"]["state"]),
            "evidence-refs": [o["id"] for o in obs_dedup],
            "facets": {F_OBS: {**({"description": T(pua_scan(res["description"]), "observation")} if res.get("description") else {}),
                               **({"end": res["end"]} if res.get("end") else {}),
                               "observations": obs_dedup},
                       COMPAT: {"uuid": res["uuid"]}}})

# ================= 5. Risks + Findings (POA&M risks, AR finding) =================
V_POAM = POAM["metadata"]["version"]
risks = {r["uuid"]: r for r in POAM.get("risks", [])}
items = POAM.get("poam-items", [])
target_obj = finding_src["target"]["target-id"]           # ac-6.1_obj - the 53A objective address

# --- CP-RISK-1: the ex-ante record. Every field below names its source; what
# --- the source cannot supply is counted in risk_gaps and printed in the report.
# OSCAL response `type` prop -> C.10 treatment option: response_treatment() of
# the library, which also says what happens to the two values without a code.
risk_gaps = collections.Counter()
response_types = collections.Counter()
_owner = next((rp["party-uuids"][0] for rp in SSP["metadata"].get("responsible-parties", []) or []
               if rp.get("role-id") == "owner" and rp.get("party-uuids")), None)
RISK_OWNER = party_uri(SSP, _owner, "system-owner")
_poam_sys = (POAM.get("system-id") or {}).get("id")
_ssp_sys = {x.get("id") for x in sc.get("system-ids", []) or []}
# the POA&M's system-id names the SSP's system by an id the SSP lists with its identifier-type (carried in
# system@1 `system-ids`): the POA&M's identifier-type is rebuilt from that entry
_ssp_sid = next((x for x in sc.get("system-ids", []) or [] if x.get("id") == _poam_sys), None)
if _ssp_sid is not None and (POAM.get("system-id") or {}).get("identifier-type") is not None:
    led.rebuilt(POAM["system-id"]["identifier-type"],
                "the identifier-type of the POA&M's system-id: that of the SSP system-id with the same id",
                lambda pid, sid, stype: stype if pid == sid else None, _poam_sys, _ssp_sid["id"], _ssp_sid["identifier-type"])

def risk_analysis(rk):
    """Everything App. F Q14 keeps out of the kernel: how the level would be
    computed (likelihood, impact, their scale system, who rated), plus the
    source's own status and response narrative, verbatim."""
    for rm in rk.get("remediations", []) or []:
        for p in rm.get("props", []) or []:
            # no content, by a rule the ledger checks (author, 2026-11-14): the name says which field the
            # value belongs in. A prop of another name is not covered and ends the run as unaccounted.
            if p.get("name") == "type":
                led.selector(p["name"], "the name of a remediation's prop `type` selects the field its value is "
                                        "written to (`responses[].type`)", p["value"], among=("type",))
    f = {"risk-status": rk.get("status"),
         "description": T(pua_scan(rk.get("description", "")), "risk"),
         "characterizations": [{"facets": [{"name": x["name"], "value": x["value"], "system": x["system"]}
                                           for x in ch.get("facets", [])],
                                # each actor as the source writes it: its uuid with its type tag beside it
                                "origin-actors": list(ch.get("origin", {}).get("actors", []))}
                               for ch in rk.get("characterizations", []) or []],
         "responses": [{"uuid": rm["uuid"],
                        "type": next((p.get("value") for p in rm.get("props", []) or [] if p.get("name") == "type"), None),
                        "lifecycle": rm.get("lifecycle"), "title": rm.get("title"),
                        "description": T(pua_scan(rm.get("description", "")), "risk"),
                        # Finding.actions[] is {description, due, status}; the task's type,
                        # narrative and START have no kernel field and ride here verbatim
                        "tasks": [{"uuid": t["uuid"], "type": t.get("type"), "title": t.get("title"),
                                   "description": T(pua_scan(t.get("description", "")), "risk"),
                                   **{k: v for k, v in (t.get("timing", {}).get("within-date-range", {}) or {}).items()}}
                                  for t in rm.get("tasks", []) or []]}
                       for rm in rk.get("remediations", []) or []]}
    mit = [{"uuid": m["uuid"], "description": T(pua_scan(m.get("description", "")), "risk")}
           for m in rk.get("mitigating-factors", []) or []]
    if mit: f["mitigating-factors"] = mit
    seen_in = [x for x in (evidence_ref(ro["observation-uuid"], POAM.get("observations"))
                           for ro in rk.get("related-observations", []) or []) if x is not None]
    if seen_in: f["observations"] = seen_in
    return f

def risk_object(rk, name, treats):
    """One POA&M risk -> one Risk. `treats`: the requirement the paired
    Finding is against (the control the response modifies), or None."""
    o = {"id": f"{NS}/risk/{name}", "version": V_POAM, "lifecycle": "active",
         "title": rk.get("title", ""),
         "scenario": pua_scan(rk.get("statement", "")),            # OSCAL `statement` IS the risk statement
         "owner-ref": RISK_OWNER}
    risk_gaps["owner absent in source (derived from the SSP `owner` role)"] += 1
    # state: `closed` retires; every other OSCAL status is at most `identified`,
    # because assessed/treated require a rating (RISK-2) and an OSCAL
    # characterization carries likelihood and impact, never the level.
    o["state"] = D("Risk state from the OSCAL risk status (closed -> retired, anything else -> identified)",
                   lambda st: "retired" if st == "closed" else "identified", rk.get("status"))
    if o["state"] == "identified":
        if rk.get("characterizations"):
            risk_gaps["analysed in source (likelihood + impact) but no level: `assessed` unreachable (RISK-2)"] += 1
    if _poam_sys and _poam_sys in _ssp_sys:                        # POA&M system-id == the SSP's system id
        o["component-refs"] = [D("the system Component, because the POA&M's system-id is an id of the SSP's system",
                                 lambda sid: COMP_SYS if sid in _ssp_sys else None, _poam_sys)]
    rtypes = [r["type"] for r in risk_analysis(rk)["responses"] if r["type"]]
    for rt in rtypes: response_types[rt] += 1
    tcode, why_none = response_treatment(rtypes[0]) if rtypes else (None, None)
    if why_none: risk_gaps[why_none] += 1
    treatment = lambda: D("treatment option from the response type (C.10)", lambda t: response_treatment(t)[0], rtypes[0])
    if tcode == "modify" and treats:
        o["treatment"] = treatment()
        o["treatments"] = [{"requirement-ref": treats}]
    elif tcode == "avoid":
        o["treatment"] = treatment()
    elif tcode == "retain":
        # RISK-6: retain requires acceptance{approver-ref, date, rationale}. The
        # source has the rationale (the response narrative) and names the
        # approver only in prose; it has NO acceptance date. A date is not
        # invented: the option stays in the facet, the approval stays on the
        # Finding's Deviation, and the gap is reported.
        risk_gaps["response `accept` without a dated acceptance: `retain` unreachable (RISK-6)"] += 1
    elif tcode == "share":
        risk_gaps["response `transfer`/`share` names no party: `share` unreachable (RISK-5)"] += 1
    elif tcode == "modify":
        risk_gaps["response `mitigate` with no control linked in source: `modify` unreachable (RISK-4)"] += 1
    if rk.get("deadline"):
        o["review-due"] = {"type": "datetime", "value": rk["deadline"]}   # OSCAL deadline: date-time-with-timezone
    o["facets"] = {F_RISKA: risk_analysis(rk), COMPAT: {"uuid": rk["uuid"]}}
    pv = provenance_of(POAM, o["id"])
    if pv: o["provenance"] = pv
    return o

def actions_of(rk):
    out = []
    for rm in rk.get("remediations", []) or []:
        for t in rm.get("tasks", []) or []:
            due = t.get("timing", {}).get("within-date-range", {}).get("end")
            a = {"description": D("action description: remediation title, then task title",
                                  lambda r, k: f"{r}: {k}", rm.get("title", ""), t.get("title", "")),
                 "status": rm.get("lifecycle", "planned")}
            if due: a["due"] = {"type": "datetime", "value": due}
            out.append(a)
    return out or [{"description": rk.get("title", "remediation"), "status": "planned"}]

# RISK-2 continues the AR finding (same observation); RISK-1 is POA&M-only (Django panel)
rk2 = next(r for r in risks.values() if "Engineers" in r["title"])
rk1 = next(r for r in risks.values() if r is not rk2)
# The assessment results carry the same risk in its earlier state (the path
# map: "consolidated with the POA&M risks"). Where its text equals the POA&M
# risk's, the ledger links it to what is kept; where it differs (the title
# gained a prefix, the status moved on), it is carried on the Risk, in
# risk-analysis@1 `assessment-results-state` (author, 2026-11-14).
ar_earlier = {}
for ar_risk in res.get("risks", []) or []:
    for field in ("title", "statement", "status", "description"):
        if field not in ar_risk: continue
        if ar_risk[field] == rk2.get(field):
            led.same(ar_risk[field], rk2[field], "the same risk in the assessment results and in the POA&M, kept once")
        else: ar_earlier[field] = ar_risk[field]
sca = rk1["characterizations"][0]["facets"][0]["system"]   # https://ifa.gov/division/ociso/sca
# The AR finding (target: an AC-6(1) objective) names this risk through
# related-risks - that is the source's own risk -> control edge.
RISK2 = risk_object(rk2, "goodread-risk-2", REQ_AC61)
if ar_earlier: RISK2["facets"][F_RISKA]["assessment-results-state"] = ar_earlier
RISK1 = risk_object(rk1, "goodread-risk-1", None)
RISK_ID = {rk2["uuid"]: (rk2["uuid"], RISK2["id"]), rk1["uuid"]: (rk1["uuid"], RISK1["id"])}
def risk_ref(ref):
    """-> the Risk minted for the POA&M risk a reference names."""
    if ref not in RISK_ID: return dangling(ref, "a POA&M item names a risk the POA&M does not define")
    uuid, rid = RISK_ID[ref]
    return D("the Risk minted for the POA&M risk a reference names by uuid",
             lambda r, ru: rid if r == ru else None, ref, uuid)
def finding_risk(ref):
    """The assessment results' finding names the results' own risk, which is the
    earlier state of a POA&M risk (same description). -> the Risk of that POA&M risk."""
    earlier = next((r for r in res.get("risks", []) or [] if r["uuid"] == ref), None)
    if earlier is None: return dangling(ref, "a finding names a risk the assessment results do not define")
    later = next((r for r in POAM.get("risks", []) or [] if r["description"] == earlier["description"]), None)
    if later is None:
        source_gaps["a finding's risk has no later state in the POA&M (no risk there has its description)"] += 1
        return None
    rid = RISK_ID[later["uuid"]][1]
    return D("the Risk of the POA&M risk that carries the later state of the risk a finding names (same description)",
             lambda r, eu, ed, ld: rid if r == eu and ed == ld else None,
             ref, earlier["uuid"], earlier["description"], later["description"])
bundle.add("objects/risk/goodread-risk-2.json", RISK2)
bundle.add("objects/risk/goodread-risk-1.json", RISK1)
def poam_item_of(rk):
    """The POA&M item of a risk, for the Finding of that risk: its title and
    description. An item names its risk by uuid; where that uuid names no risk
    of the document (a source defect, counted), the item is the one that
    shares an observation with the risk."""
    uuids = lambda xs, key: {x[key] for x in xs or []}
    item = next((it for it in items if rk["uuid"] in uuids(it.get("related-risks"), "risk-uuid")), None)
    if item is None:
        item = next((it for it in items if uuids(it.get("related-observations"), "observation-uuid")
                     & uuids(rk.get("related-observations"), "observation-uuid")), None)
    if item is None: return {}
    named = [x for x in (risk_ref(rr["risk-uuid"]) for rr in item.get("related-risks", []) or []) if x is not None]
    unresolved = [rr["risk-uuid"] for rr in item.get("related-risks", []) or [] if rr["risk-uuid"] not in RISK_ID]
    seen_in = [x for x in (evidence_ref(ro["observation-uuid"], POAM.get("observations"))
                           for ro in item.get("related-observations", []) or []) if x is not None]
    return {"poam-item": {"uuid": item["uuid"], "title": item.get("title"),
                          "description": T(pua_scan(item.get("description", "")), "finding"),
                          **({"risks": named} if named else {}),
                          **({"unresolved-risk-uuids": unresolved} if unresolved else {}),    # a defect of the source, verbatim
                          **({"observations": seen_in} if seen_in else {})}}
item2, item1 = poam_item_of(rk2), poam_item_of(rk1)
# each Finding's edges, from the references the source gives
finding2_risks = [x for x in (finding_risk(rr["risk-uuid"]) for rr in finding_src.get("related-risks", []) or [])
                  if x is not None]
assert finding2_risks == [RISK2["id"]], f"the finding names {finding2_risks}, the bundle wired {RISK2['id']}"
finding2_obs = [x for x in (evidence_ref(ro["observation-uuid"], res.get("observations"))
                            for ro in finding_src.get("related-observations", []) or []) if x is not None]
dev_ref = rk1["related-observations"][0]["observation-uuid"]          # the observation the accepted risk rests on
dev_obs = next(o for o in POAM["observations"] if o["uuid"] == dev_ref)
bundle.add("objects/finding/goodread-risk-2.json",
           {"id": f"{NS}/finding/goodread-risk-2", "version": V_POAM, "lifecycle": "active",
            "title": finding_src.get("title", rk2["title"]),
            "assessment-ref": ASSESS, "requirement-ref": REQ_AC61,
            "state": "in-remediation",
            "risk-refs": finding2_risks,
            "actions": actions_of(rk2),
            "facets": {COMPAT: {"uuid": finding_src["uuid"]},
                       F_FTGT: {"target-objective-id": target_obj,
                                **({"target-type": finding_src["target"]["type"]} if finding_src["target"].get("type") else {}),
                                "implementation-statement-uuid": finding_src.get("implementation-statement-uuid"),
                                **({"description": T(pua_scan(finding_src["description"]), "finding")}
                                   if finding_src.get("description") else {}),
                                **({"target-description": T(pua_scan(finding_src["target"]["description"]), "finding")}
                                   if finding_src["target"].get("description") else {}),
                                **({"observations": finding2_obs} if finding2_obs else {}),
                                **item2}},
            **({"provenance": pv} if (pv := provenance_of(POAM, f"{NS}/finding/goodread-risk-2")) else {})})
bundle.add("objects/finding/goodread-risk-1.json",
           {"id": f"{NS}/finding/goodread-risk-1", "version": V_POAM, "lifecycle": "active",
            "title": rk1.get("title", ""),
            "assessment-ref": ASSESS, "requirement-ref": REQ_AC61,
            "state": "in-remediation",
            "risk-refs": [RISK1["id"]],
            "actions": actions_of(rk1),
            # RISK-9: the risk-adjustment Deviation names the Risk it adjusts for
            "deviations": [{"type": "risk-adjustment", "state": "approved",
                            "rationale": pua_scan(rk1.get("mitigating-factors", [{}])[0].get("description",
                                          "Risk accepted per POA&M deviation approval.")),
                            "approver-ref": sca,
                            "opened": D("date part of the observation's collected timestamp", lambda c: c[:10],
                                        dev_obs.get("collected", "2023-05-19")),
                            "refs": [evidence_ref(dev_ref, POAM["observations"]), RISK1["id"]]}],
            **({"facets": {F_FTGT: item1}} if item1 else {}),
            **({"provenance": pv} if (pv := provenance_of(POAM, f"{NS}/finding/goodread-risk-1")) else {})})

# every role list is complete now: attach the ones that hold something
for holder, roles in ROLE_LISTS:
    if roles: holder["responsible-roles"] = roles
for gap, n in sorted(source_gaps.items()):
    note(f"**Dangling reference x{n}** (a defect of the source): {gap}. Nothing is invented for it; the reference is "
         f"carried verbatim where it stands, under a member `unresolved-...`.")
# What the ledger cannot see: it follows source values into the bundle, not the
# other way. These three values are written by this script with nothing in the
# source behind them (the SSP defines no such role). Left as they are and said
# here (author's decision 2026-11-13).
note(f"**Values without a source x3**: `authority-ref` of the two authorizations and the Attestation's `signer` are "
     f"written as `{NS}/party/authorizing-official` and `{NS}/party/csp-authorizing-official`. No source value "
     f"stands behind them: none of the plans defines an authorizing official. The conversion ledger traces source "
     f"values into the bundle and does not list values the converter writes on its own.")
for gap, n in sorted(party_gaps.items()):
    note(f"**Parties the source {gap} x{n}** (source finding): a role assignment names a party by uuid, and the "
         f"document {'has no such party' if gap == 'does not define' else 'gives that party no name'} - the leveraged "
         f"pair's parties carry a type and at most a remark. The party's uuid is carried beside the role "
         f"(`party-uuids`), and on the leveraged authorization as `party-uuid`.")

# ---------- stubs + write ----------
# carried Requirements bring their facet pins along (#17 fail-closed:
# a bundle pins every facet schema its objects use). The pins are the files
# their own bundle pins, verbatim: one id and version is one schema (backlog
# #88). Until 2026-11-14 this converter wrote stubs of its own for them, and
# its narrative stub lacked the member `overview` that the SP 800-53 bundle
# pins under the same id and version.
for _fn in ("sp800-53-narrative-stub.json", "sp800-53-odp-stub.json"):
    with open(os.path.join(NISTB, "schemas", _fn), encoding="utf-8") as _f: bundle.schemas[f"schemas/{_fn}"] = json.load(_f)
bundle.pin_stdlib(ASSESSMENT_CRITERIA_FILE)   # their assessment objectives stand in the standard facet since 2026-11-14 (backlog #83)
bundle.stub("goodread-system-stub.json", F_SYS.split("@")[0], [],
            {"system-ids": {"type": "array"}, "description": {"type": "object"},
             "status": {"type": "string"}, "sensitivity": {"type": "string"},
             "date-authorized": {"type": "string"}, "impact": {"type": "object"},
             "boundary": {"type": "object"}, "network-architecture": {"type": "object"},
             "data-flow": {"type": "object"}, "users": {"type": "array"},
             "inventory-items": {"type": "array"}, "customer-responsibilities": {"type": "array"},
             "remarks": {"type": "object"}, "responsible-roles": {"type": "array"}})
bundle.stub("goodread-observations-stub.json", F_OBS.split("@")[0], [],
            {"description": {"type": "object"}, "end": {"type": "string"}, "observations": {"type": "array"}})
bundle.stub("goodread-risk-analysis-stub.json", F_RISKA.split("@")[0], [],
            {"risk-status": {"type": "string"}, "description": {"type": "object"},
             "characterizations": {"type": "array"}, "responses": {"type": "array"},
             "mitigating-factors": {"type": "array"}, "observations": {"type": "array"},
             "assessment-results-state": {"type": "object"}},
            version="1.1.0")   # backlog #88: members came on 2026-11-14, under the 1.0.0 it had carried without them
bundle.stub("goodread-finding-target-stub.json", F_FTGT.split("@")[0], [],
            {"target-objective-id": {"type": "string"}, "target-type": {"type": "string"},
             "implementation-statement-uuid": {"type": "string"},
             "description": {"type": "object"}, "target-description": {"type": "object"},
             "observations": {"type": "array"}, "poam-item": {"type": "object"}},
            version="1.1.0")   # backlog #88: members came on 2026-11-14, under the 1.0.0 it had carried without them
# The schema of the Assessment's method payload (backlog #55). `tasks` and
# `reviewed-controls` were written since 1.0.0 and missing from this pin
# until 2026-11-13; since then it named the five members and said of each
# only that it is an array. It now says what an entry is, closed at every
# level, so that a payload this script writes is held to its own pin (the
# check after the write). No validator holds a method payload to its pin
# yet: that half of #55 is open.
_STR = {"type": "string"}
_TEXT = {"type": "object", "minProperties": 1, "additionalProperties": {"type": "string"}}     # a language map
_FROM = {"enum": ["ap", "ar"]}                    # the plan or the results: which document an entry is from
def _entry(required, properties):
    return {"type": "array", "items": {"type": "object", "additionalProperties": False,
                                       "required": required, "properties": properties}}
bundle.stub("goodread-ap-stub.json", F_AP.split("@")[0], [],
            {"activities": _entry(["title", "description", "steps", "related-controls", "source-doc"],
                                  {"uuid": _STR, "title": _STR, "description": _TEXT,
                                   "steps": _entry(["title", "description"],
                                                   {"uuid": _STR, "title": _STR, "description": _TEXT, "remarks": _TEXT}),
                                   "props": {"type": "object",
                                             "additionalProperties": {"anyOf": [_STR, {"type": "array", "items": _STR}]}},
                                   "related-controls": {"type": "array", "items": _STR},
                                   "source-doc": _FROM}),
             "tasks": _entry(["title", "type", "source-doc"],
                             {"uuid": _STR, "title": _STR, "type": _STR, "description": _TEXT,
                              "activities": {"type": "array", "items": _STR},
                              "unresolved-activity-uuids": {"type": "array", "items": _STR},     # a defect of the source
                              "subjects": {"type": "array", "items": {"type": "object"}},          # as the source writes them
                              "remarks": _TEXT, "source-doc": _FROM}),
             "subjects": _entry(["description"], {"type": _STR, "description": _TEXT}),
             "reviewed-controls": {"type": "array", "items": _STR},
             "responsible-roles": _entry(["role"], {"role": _STR, "parties": {"type": "array", "items": _STR}})},
            version="1.1.0")   # backlog #88: members came on 2026-11-14, under the 1.0.0 it had carried without them
bundle.stub("goodread-protocols-stub.json", F_PROTO.split("@")[0], [], {"protocols": {"type": "array"}})
bundle.stub("goodread-implementation-stub.json", F_IMPL.split("@")[0], [],
            {"description": {"type": "object"}, "remarks": {"type": "object"}, "statements": {"type": "array"}})
bundle.stub("goodread-component-stub.json", F_COMP.split("@")[0], [],
            {"title": {"type": "string"}, "description": {"type": "object"}, "purpose": {"type": "object"},
             "status": {"type": "string"}, "props": {"type": "object"}, "responsible-roles": {"type": "array"},
             "control-implementations": {"type": "array"},
             "capabilities": {"type": "array"},                # the uuids of what each capability is made from
             "authorizations": {"type": "array"},              # what the kernel's authorization entry has no member for
             "listed-by-leveraging-plan": {"type": "object"}}   # the leveraging plan's own entry, where it differs
            ,version="1.1.0")   # backlog #88: members came on 2026-11-14, under the 1.0.0 it had carried without them
bundle.pin_compat()      # `uuid` of the source element an object is made from: the one compat schema (1.1.0)
# what each source document says about itself, handed on as it stands: the
# bundle's objects come from seven documents, and the manifest names them.
# This bundle has no Set that stands for a document, so each document's entry
# here holds the rest (the author's decisions of 2026-11-14): its uuid, the
# rest of its metadata in the source's shape (revisions, roles, parties with
# their uuids, responsible parties), its import link, and the back-matter
# resources something in the document refers to, with their uuids. A resource
# nothing refers to is an orphan and stays out by the ledger's rule (R1).
DOC_META = ("title", "version", "oscal-version", "last-modified", "published", "remarks")
R_ORPHAN = "a back-matter resource that nothing in its document refers to: nobody can reach it, and it is not carried"
R_DOC_DAY = "date of a source document: the day of its last-modified"
ORPHANS = []
def source_document(tag, fn, wrapped):
    (key, doc), = wrapped.items()
    # The members the kernel types of a source (backlog #80): title, version, uuid, date, format, format-version.
    # What else the document says of itself stands beside them, as before.
    meta = doc["metadata"]
    entry = {"file": fn, "title": meta["title"], "version": meta["version"], "uuid": doc["uuid"]}
    if document_day(meta): entry["date"] = D(R_DOC_DAY, lambda lm: lm[:10], meta["last-modified"])
    entry["format"] = "OSCAL"
    entry["format-version"] = meta["oscal-version"]
    entry.update({k: meta[k] for k in DOC_META if k in meta and k not in ("title", "version", "oscal-version")})
    rest = {k: v for k, v in doc["metadata"].items() if k not in DOC_META}
    if rest: entry["metadata"] = rest
    for k in ("import-profile", "import-ssp", "import-ap"):
        if k in doc: entry[k] = doc[k]
    kept = []
    for r in doc.get("back-matter", {}).get("resources", []) or []:
        if referred_to(wrapped, r): kept.append(r)
        else: led.orphan(r["uuid"], R_ORPHAN); ORPHANS.append(f"{tag}: {r['uuid']}")
    if kept: entry["back-matter"] = {"resources": kept}
    return entry
source_documents = [source_document(tag, fn, doc) for tag, fn, doc in SOURCE_FILES]
STATED = []          # no object's lifecycle is a status of the source mapped by a rule: `active` is the converter's
LIFECYCLE_DEFAULT = lifecycle_default_record(bundle.objects, STATED)
manifest = bundle.write({"sources": source_documents,
              "source-note": "OSCAL IFA GoodRead example set (SSP 1.1.1, AP, AR, POA&M) + leveraged/leveraging SSP "
                             "pair + component-definition example (usnistgov/oscal-content). FICTIONAL example "
                             "content by NIST; converted as the gate-3 lifecycle corpus",
              "source-commit": "usnistgov/oscal-content@9402f031 (2026-07-14; the state fetched 2026-07-22)",
              "converter": "convert_ifa.py v0.5 (provenance pre-filled from the source documents; "
                           "the Attestation beside the manifest; conversion ledger)",
              "carried-requirements": carried,
              "attestation-note": "the Attestation of the ATO is the file attestation-ifa-ato.json beside this "
                                  "manifest; it is not listed here, because it binds the digest of this file (D3.1)"})

# ================= 6. Attestation (the ATO as attestation), beside the manifest =================
# D3.1: an Attestation binds the manifest by the digest of the manifest's
# bytes, so the manifest cannot list it - nothing that is signed contains its
# own signature. It is written after the manifest, into the manifest's
# folder. Until 2026-11-13 it was an object of the bundle and bound "a
# deterministic mini-manifest", the list of its own three subjects; and it
# took the system Component's digest before the bundle's free text was
# language-tagged at the write, so one of its three subject digests matched
# no object of the bundle (measured on the committed conversion, backlog #46).
ATTESTATION_FILE = "attestation-ifa-ato.json"
_written = {e["id"]: e["semantic-digest"] for e in manifest["objects"]}
with open(os.path.join(bundle.out, "content-manifest.json"), "rb") as f:
    _manifest_digest = "sha256:" + hashlib.sha256(f.read()).hexdigest()
attestation = {"id": f"{NS}/attestation/ifa-ato", "version": V_SSP, "lifecycle": "active",
               "title": D("attestation title naming the system",
                          lambda n: f"IFA ATO for {n} (modeled from SSP date-authorized)", sc["system-name"]),
               "subject-semantic-digests": [{"id": e["id"], "semantic-digest": e["semantic-digest"]}
                                            for e in manifest["objects"] if e["id"] in (COMP_SYS, IMPL_SYS, REQ_AC61)],
               "content-manifest-digest": _manifest_digest,
               "signer": f"{NS}/party/authorizing-official",
               "timestamp": D("ATO timestamp: midnight UTC of the date authorized", lambda d: f"{d}T00:00:00Z",
                              sc.get("date-authorized", "2025-05-19"))}
textify(attestation, bundle.lang)
bundle._w(ATTESTATION_FILE, attestation)

# ---------- what was written is held to what it claims ----------
# Checked here, so that a conversion that does not hold them is never
# written out as finished. The validator has held an Attestation to what it
# binds since 2026-11-14 (attestation-binds on a bundle, backlog #46); it
# does not hold a method payload to its schema yet (#55).
#   - every facet payload and the method payload pass the schema the bundle pins for them;
#   - every subject of the Attestation is an object of the bundle, with that semantic digest;
#   - the Attestation binds the digest of the manifest as it lies on disk.
def _self_check():
    pins = {sd["id"]: jsonschema.Draft202012Validator(sd["schema"]) for sd in bundle.schemas.values()}
    wrong = []
    for rel, o in bundle.objects.items():
        for member in ("facets", "method"):
            for fid, payload in (o.get(member) or {}).items():
                pin = pins.get(fid.rsplit("@", 1)[0])
                if pin is None: wrong.append(f"{rel}: {member} {fid} has no pinned schema"); continue
                for e in pin.iter_errors(payload):
                    wrong.append(f"{rel}: {member} {fid}: {e.message[:120]} at /{'/'.join(map(str, e.absolute_path))}")
    subjects = attestation["subject-semantic-digests"]
    if len(subjects) != 3: wrong.append(f"{ATTESTATION_FILE}: {len(subjects)} of its 3 subjects are objects of the bundle")
    for sj in subjects:
        if _written.get(sj["id"]) != sj["semantic-digest"]:
            wrong.append(f"{ATTESTATION_FILE}: subject {sj['id']} does not carry the digest of the bundle's object")
    with open(os.path.join(bundle.out, "content-manifest.json"), "rb") as f:
        if "sha256:" + hashlib.sha256(f.read()).hexdigest() != attestation["content-manifest-digest"]:
            wrong.append(f"{ATTESTATION_FILE}: content-manifest-digest is not the digest of content-manifest.json")
    if any(e["path"].startswith("objects/attestation/") for e in manifest["objects"]):
        wrong.append("the manifest lists an Attestation (D3.1)")
    if wrong: raise SystemExit("convert_ifa.py wrote a bundle that does not hold what it claims:\n  " + "\n  ".join(wrong))
_self_check()
note(f"**Who wrote a record, and when x{sum(PROVENANCE.values())}** (backlog #69): `provenance` on the Implementations, the "
     f"Findings and the Risks - {PROVENANCE['from the source']} from the source, {PROVENANCE['overwritten by the caller']} "
     f"overwritten by the caller, {PROVENANCE['none']} without. From the source means: the author is the party the record's "
     f"document names as its author (a `creator`, else who prepared it, else the one responsible party, else the one party, "
     f"else the one organization), and the date is the day of that document's `last-modified`. That is the latest day the "
     f"record can have been written, not the day it was: OSCAL dates the document, not its statements. "
     + (f"Without an author, because their documents name none the rule can take (the plan of action defines no party; the "
        f"leveraged pair defines parties without a name): {', '.join(x.rsplit('/', 2)[-2] + '/' + x.rsplit('/', 1)[-1] for x in NO_AUTHOR)}. "
        f"Nothing is invented for them; the validator reports each (AUTHOR-2). " if NO_AUTHOR else "")
     + "`--author-ref` and `--date` overwrite both, field by field, on every record.")
note("**Authorization dates x2**: `date-authorized` of the system and of the leveraged authorization -> "
     "`authorizations[].date`. **The day a Deviation was decided x0**: the plan of action says that the risk's deviation is "
     "approved and not when; `decided` is not written (AUTHOR-3).")

# ---------- coverage ----------
RULES = [
 (r"^(ssp|ap|ar|poam|lev|lvg|cdef)\.[a-z-]+\.(uuid$|metadata\.|import-profile|import-ssp|import-ap|back-matter\.)", "L1",
  "bundle manifest provenance: sources, one entry per document (title, version, its uuid, the day of its "
  "last-modified as date, OSCAL and its oscal-version as format and format-version, last-modified, published, "
  "remarks, the rest of its metadata - revisions, roles, parties, responsible "
  "parties - in the source's shape, its import link, the back-matter resources something refers to); parties -> "
  "landmark party URIs where a role names them; an orphaned back-matter resource is not carried (ledger rule)"),
 (r"^ssp\.system-security-plan\.system-characteristics\.", "L1",
  "system Component: authorizations[] (date-authorized -> the D5 anchor + Attestation) + system@1 facet "
  "(ids, status, sensitivity, FIPS-199 impact, boundary/network/data-flow, language-tagged)"),
 (r"^ssp\.system-security-plan\.system-implementation\.users\[\]\.", "L2", "system@1 facet users[]"),
 (r"^ssp\.system-security-plan\.system-implementation\.inventory-items\[\]\.", "L2",
  "system@1 facet inventory-items[] (props by name, their classes in `prop-classes`, the props of each "
  "implemented component in `component-props`)"),
 (r"^ssp\.system-security-plan\.system-implementation\.components\[\]\.", "L1",
  "Component (kind mapped) id/title + component@1 facet (description, purpose, status, props, responsible-roles)"),
 (r"^ssp\.system-security-plan\.control-implementation\.", "L1",
  "Implementation: requirement-ref = minted AC-6.1 (in-bundle copy), by-component -> capability + "
  "satisfied-by, its component-uuid resolved to component-ref, set-parameters -> parameter-bindings (verified "
  "against the declared ODPs), implementation-status -> status; the narrative by statement -> implementation@1"),
 (r"^ap\.assessment-plan\.(local-definitions|tasks|assessment-subjects|reviewed-controls)", "L2",
  "Assessment.method payload (assessment-plan@1): activities with their steps, method prop and related controls, "
  "tasks (each naming its activity by title), subjects, reviewed-controls; roles -> the payload's responsible-roles"),
 (r"^ar\.assessment-results\.results\[\]\.(uuid|title|description|start|end)$", "L1",
  "Assessment id/title/time (start); description and end -> observations@1"),
 (r"^ar\.assessment-results\.results\[\]\.reviewed-controls\.", "L1", "Assessment subject-refs"),
 (r"^ar\.assessment-results\.results\[\]\.observations\[\]\.", "L1",
  "observations@1 facet + landmark evidence URIs (methods, types, subjects as Components, collected, expires, remarks)"),
 (r"^ar\.assessment-results\.results\[\]\.findings\[\]\.", "L1",
  "Finding: target.status -> Assessment result + Finding state; target-id (53A objective) + "
  "implementation-statement-uuid -> finding-target@1 facet; related-risks -> Finding.risk-refs (the results' risk "
  "resolved to the Risk of its later state in the POA&M); related-observations -> finding-target@1 observations"),
 (r"^ar\.assessment-results\.results\[\]\.(risks|local-definitions)", "L1",
  "risk content consolidated with the POA&M risks (same risk graph, later state); what differs -> "
  "risk-analysis@1 `assessment-results-state` on the Risk"),
 (r"^ar\.assessment-results\.local-definitions\.", "L2",
  "Assessment.method payload: the results' own activity (the TEST that was run) beside the plan's, marked source-doc ar"),
 (r"^poam\.plan-of-action-and-milestones\.(uuid$|system-id)", "L1", "provenance / system id (system@1)"),
 (r"^poam\.plan-of-action-and-milestones\.observations\[\]\.", "L1",
  "observations@1 facet + landmark evidence URIs (deduped against AR by uuid; a field that differs from the "
  "AR's copy is kept under `variants`)"),
 (r"^poam\.plan-of-action-and-milestones\.risks\[\]\.(uuid|title|statement|status|deadline)$", "L1",
  "Risk id/title; statement -> scenario; deadline -> review-due (datetime); status -> Risk state "
  "(+ verbatim in risk-analysis@1) and Finding state (deviation-approved -> approved Deviation; "
  "open+remediation -> in-remediation)"),
 (r"^poam\.plan-of-action-and-milestones\.risks\[\]\.description$", "L2",
  "risk-analysis@1 description (the kernel's `scenario` is the OSCAL statement)"),
 (r"^poam\.plan-of-action-and-milestones\.risks\[\]\.characterizations\[\]\.", "L2",
  "risk-analysis@1 characterizations (likelihood/impact + scale system, origin actors) - scoring stays out of the kernel (App. F Q14)"),
 (r"^poam\.plan-of-action-and-milestones\.risks\[\]\.remediations\[\]\.props\[\]\.", "L1",
  "response `type` -> Risk.treatment (C.10: mitigate->modify, accept->retain, transfer|share->share, avoid->avoid) "
  "+ verbatim in risk-analysis@1 responses[]"),
 (r"^poam\.plan-of-action-and-milestones\.risks\[\]\.remediations\[\]\.(lifecycle|title|description)$", "L1",
  "Finding.actions[] description/status + risk-analysis@1 responses[] (lifecycle, title, narrative)"),
 (r"^poam\.plan-of-action-and-milestones\.risks\[\]\.remediations\[\]\.", "L1",
  "Finding.actions[] (task title; within-date-range.end -> due); remediation/task uuids are source identity (L0)"),
 (r"^poam\.plan-of-action-and-milestones\.risks\[\]\.(mitigating-factors|related-observations)\[?\]?\.", "L1",
  "Deviation rationale (RISK-1) + risk-analysis@1 mitigating-factors; related-observations -> risk-analysis@1 "
  "observations (evidence URIs) and, for the accepted risk, the Deviation's refs"),
 (r"^poam\.plan-of-action-and-milestones\.poam-items\[\]\.", "L1",
  "poam-item title and description -> finding-target@1 `poam-item` on the Finding of the risk the item names; "
  "its related-risks and related-observations -> `risks` and `observations` there, resolved (a risk the POA&M "
  "does not define: verbatim under `unresolved-risk-uuids`, a defect of the source)"),
 (r"^(lev|lvg)\.system-security-plan\.system-characteristics\.", "L1",
  "provider/consumer Components: system@1 facet, the same content as for the main system "
  "(ids, status, sensitivity, FIPS-199 impact, boundary, remarks)"),
 (r"^(lev|lvg)\.system-security-plan\.system-implementation\.components\[\]\.", "L1",
  "Components (kind mapped: appliance->hardware, application->software) + component@1 facet; the leveraging "
  "plan's entries for components of the leveraged system: what equals the provider's is linked to it, the rest "
  "-> component@1 `listed-by-leveraging-plan` of the provider's Component"),
 (r"^lvg\.system-security-plan\.system-implementation\.(users|leveraged-authorizations)\[\]\.", "L1",
  "leveraged-authorizations -> provider Component authorizations[] (the basis-ref anchor; uuid, links and party "
  "-> component@1 `authorizations`); users -> system@1"),
 (r"^lev\.system-security-plan\.system-implementation\.users\[\]\.", "L2", "system@1 facet users[]"),
 (r"^lev\.system-security-plan\.control-implementation\.", "L1",
  "provider Implementation: export.provided -> capabilities on the Component that exports them "
  "(consumer-inheritable), export.responsibilities -> system@1 customer-responsibilities, each naming its "
  "capability; the narrative by statement -> implementation@1; statement ids respelled _stmt.->smt. (counted)"),
 (r"^lvg\.system-security-plan\.control-implementation\.", "L1",
  "consumer Implementation: inherited -> satisfied-by inherited-from{component resolved through the provided "
  "capability, basis-ref} (D5), satisfied -> consumer capability; responsibility shared; the narrative by "
  "statement, with each inherited/satisfied entry naming its capability -> implementation@1"),
 (r"^cdef\.component-definition\.(uuid$|metadata\.)", "L1", "bundle manifest / L0 provenance"),
 (r"^cdef\.component-definition\.components\[\]\.protocols\[\]\.", "L2", "protocols@1 facet"),
 (r"^cdef\.component-definition\.components\[\]\.responsible-roles\[\]\.", "L1",
  "component@1 responsible-roles: {role, parties: [landmark party URI]} (#16: parties stay landmark)"),
 (r"^cdef\.component-definition\.components\[\]\.control-implementations\[\]\.", "L1",
  "capabilities with requirement-ref (landmark - the component asserts support, no system binds it): statements -> "
  "statement-ids and clause texts, set-parameters -> parameter-bindings under the catalogue's names; the control "
  "implementation's description and source -> component@1"),
 (r"^cdef\.component-definition\.components\[\]\.(uuid|type|title|description|purpose)$", "L1",
  "Component (kind mapped) id/title + component@1 facet (description, purpose)"),
]
# What the ledger may find for the values of each row (backlog #89): one
# entry per row of RULES, in its order - the row's pattern, the outcomes the
# record measured for it, and the places its values stand at, as the record
# by path writes them (a JSON Pointer into the object, array positions as
# `[]`). After the account the record is held against this table, and a value
# with another outcome or at another place ends the run (path_map_check). The
# rows of this map are wide, a subtree of a document each, and so are their
# entries: they are what the record of the pinned documents measured, a
# member that holds four places or more written as the member and all below
# it.
CARRIED = ("copied", "transformed"); NO_CONTENT = ("not-content",)
_COMP = r"/facets/https:~1~1ifa\.gov~1goodread~1facet~1component@1"
_COMPAT = r"/facets/https:~1~1ns\.jascon\.net~1compat~1oscal-1x@1"
_IMPL = r"/facets/https:~1~1ifa\.gov~1goodread~1facet~1implementation@1"
_OBS = r"/facets/https:~1~1ifa\.gov~1goodread~1facet~1observations@1"
_PROT = r"/facets/https:~1~1ifa\.gov~1goodread~1facet~1protocols@1"
_RISKA = r"/facets/https:~1~1ifa\.gov~1goodread~1facet~1risk-analysis@1"
_SYS = r"/facets/https:~1~1ifa\.gov~1goodread~1facet~1system@1"
_TARGET = r"/facets/https:~1~1ifa\.gov~1goodread~1facet~1finding-target@1"
HELD = [
 (r"^(ssp|ap|ar|poam|lev|lvg|cdef)\.[a-z-]+\.(uuid$|metadata\.|import-profile|import-ssp|import-ap|back-matter\.)", CARRIED + NO_CONTENT,
  (r"/evidence-refs/\[\]",
   _COMP + r"/control-implementations/\[\]/source",
   _COMP + r"/responsible-roles/\[\]/parties/\[\]",
   _SYS + r"/responsible-roles/\[\]/parties/\[\]",
   _SYS + r"/responsible-roles/\[\]/role",
   r"/method/https:~1~1ifa\.gov~1goodread~1facet~1assessment-plan@1/responsible-roles/\[\]/parties/\[\]",
   r"/method/https:~1~1ifa\.gov~1goodread~1facet~1assessment-plan@1/responsible-roles/\[\]/role",
   r"/objects/\[\]/version",
   r"/owner-ref",
   r"/performer-ref",
   r"/provenance(/.*)?",
   r"/title/en",
   r"/version")),
 (r"^ssp\.system-security-plan\.system-characteristics\.", CARRIED,
  (r"/authorizations/\[\]/date",
   r"/authorizations/\[\]/scope-label",
   _SYS + r"/boundary/en",
   _SYS + r"/data-flow/en",
   _SYS + r"/date-authorized",
   _SYS + r"/description/en",
   _SYS + r"/impact(/.*)?",
   _SYS + r"/network-architecture/en",
   _SYS + r"/sensitivity",
   _SYS + r"/status",
   _SYS + r"/system-ids/\[\]/id",
   _SYS + r"/system-ids/\[\]/identifier-type",
   r"/label",
   r"/timestamp",
   r"/title/en")),
 (r"^ssp\.system-security-plan\.system-implementation\.users\[\]\.", CARRIED, (_COMP + r"/responsible-roles/\[\]/role", _SYS + r"/users(/.*)?")),
 (r"^ssp\.system-security-plan\.system-implementation\.inventory-items\[\]\.", CARRIED, (_SYS + r"/inventory-items(/.*)?",)),
 (r"^ssp\.system-security-plan\.system-implementation\.components\[\]\.", CARRIED,
  (r"/component-ref",
   _COMP + r"/description/en",
   _COMP + r"/responsible-roles/\[\]/parties/\[\]",
   _COMP + r"/responsible-roles/\[\]/role",
   _COMP + r"/status",
   _OBS + r"/observations/\[\]/subjects/\[\]",
   _COMPAT + r"/uuid",
   r"/kind",
   r"/title/en")),
 (r"^ssp\.system-security-plan\.control-implementation\.", CARRIED,
  (r"/capabilities/\[\]/description/en",
   r"/capabilities/\[\]/requirement-ref",
   r"/component-ref",
   _COMP + r"/capabilities/\[\]/uuid",
   _IMPL + r"/description/en",
   _COMPAT + r"/uuid",
   r"/parameter-bindings(/.*)?",
   r"/requirement-ref",
   r"/status")),
 (r"^ap\.assessment-plan\.(local-definitions|tasks|assessment-subjects|reviewed-controls)", CARRIED,
  (r"/method(/.*)?",
   r"/provenance/sources/\[\]/metadata/responsible-parties/\[\]/role-id")),
 (r"^ar\.assessment-results\.results\[\]\.(uuid|title|description|start|end)$", CARRIED,
  (_OBS + r"/description/en",
   _OBS + r"/end",
   _COMPAT + r"/uuid",
   r"/time",
   r"/title/en")),
 (r"^ar\.assessment-results\.results\[\]\.reviewed-controls\.", CARRIED, (r"/subject-refs/\[\]",)),
 (r"^ar\.assessment-results\.results\[\]\.observations\[\]\.", CARRIED + NO_CONTENT,
  (r"/evidence-refs/\[\]",
   _TARGET + r"/observations/\[\]",
   _OBS + r"/observations(/.*)?")),
 (r"^ar\.assessment-results\.results\[\]\.findings\[\]\.", CARRIED,
  (_TARGET + r"/description/en",
   _TARGET + r"/implementation-statement-uuid",
   _TARGET + r"/observations/\[\]",
   _TARGET + r"/target-description/en",
   _TARGET + r"/target-objective-id",
   _TARGET + r"/target-type",
   _COMPAT + r"/uuid",
   r"/result",
   r"/risk-refs/\[\]",
   r"/title/en")),
 (r"^ar\.assessment-results\.results\[\]\.(risks|local-definitions)", CARRIED,
  (_RISKA + r"/assessment-results-state/statement",
   _RISKA + r"/assessment-results-state/status",
   _RISKA + r"/assessment-results-state/title",
   _RISKA + r"/description/en",
   r"/method(/.*)?",
   r"/risk-refs/\[\]")),
 (r"^ar\.assessment-results\.local-definitions\.", CARRIED,
  (r"/method(/.*)?",
   r"/provenance/sources/\[\]/metadata/responsible-parties/\[\]/role-id")),
 (r"^poam\.plan-of-action-and-milestones\.(uuid$|system-id)", CARRIED + NO_CONTENT, (r"/component-refs/\[\]",)),
 (r"^poam\.plan-of-action-and-milestones\.observations\[\]\.", CARRIED + NO_CONTENT,
  (r"/deviations/\[\]/opened",
   r"/deviations/\[\]/refs/\[\]",
   r"/evidence-refs/\[\]",
   _TARGET + r"/poam-item/observations/\[\]",
   _OBS + r"/observations(/.*)?",
   _RISKA + r"/observations/\[\]")),
 (r"^poam\.plan-of-action-and-milestones\.risks\[\]\.(uuid|title|statement|status|deadline)$", CARRIED,
  (_TARGET + r"/poam-item/risks/\[\]",
   _RISKA + r"/risk-status",
   _COMPAT + r"/uuid",
   r"/review-due/value",
   r"/scenario/en",
   r"/state",
   r"/title/en")),
 (r"^poam\.plan-of-action-and-milestones\.risks\[\]\.description$", CARRIED, (_RISKA + r"/description/en", r"/risk-refs/\[\]")),
 (r"^poam\.plan-of-action-and-milestones\.risks\[\]\.characterizations\[\]\.", CARRIED,
  (r"/deviations/\[\]/approver-ref",
   _RISKA + r"/characterizations(/.*)?")),
 (r"^poam\.plan-of-action-and-milestones\.risks\[\]\.remediations\[\]\.props\[\]\.", CARRIED + NO_CONTENT,
  (_RISKA + r"/responses/\[\]/type",
   r"/treatment")),
 (r"^poam\.plan-of-action-and-milestones\.risks\[\]\.remediations\[\]\.(lifecycle|title|description)$", CARRIED,
  (r"/actions/\[\]/description/en",
   r"/actions/\[\]/status",
   _RISKA + r"/responses/\[\]/description/en",
   _RISKA + r"/responses/\[\]/lifecycle",
   _RISKA + r"/responses/\[\]/title")),
 (r"^poam\.plan-of-action-and-milestones\.risks\[\]\.remediations\[\]\.", CARRIED,
  (r"/actions/\[\]/description/en",
   r"/actions/\[\]/due/value",
   _RISKA + r"/responses(/.*)?")),
 (r"^poam\.plan-of-action-and-milestones\.risks\[\]\.(mitigating-factors|related-observations)\[?\]?\.", CARRIED,
  (r"/deviations/\[\]/rationale/en",
   r"/deviations/\[\]/refs/\[\]",
   _RISKA + r"/mitigating-factors/\[\]/description/en",
   _RISKA + r"/mitigating-factors/\[\]/uuid",
   _RISKA + r"/observations/\[\]")),
 (r"^poam\.plan-of-action-and-milestones\.poam-items\[\]\.", CARRIED, (_TARGET + r"/poam-item(/.*)?",)),
 (r"^(lev|lvg)\.system-security-plan\.system-characteristics\.", CARRIED,
  (_SYS + r"/boundary/en",
   _SYS + r"/description/en",
   _SYS + r"/impact(/.*)?",
   _SYS + r"/remarks/en",
   _SYS + r"/sensitivity",
   _SYS + r"/status",
   _SYS + r"/system-ids/\[\]/id",
   r"/label")),
 (r"^(lev|lvg)\.system-security-plan\.system-implementation\.components\[\]\.", CARRIED,
  (_COMP + r"/description/en",
   _COMP + r"/listed-by-leveraging-plan(/.*)?",
   _COMP + r"/props/implementation-point",
   _COMP + r"/props/virtual",
   _COMP + r"/responsible-roles/\[\]/party-uuids/\[\]",
   _COMP + r"/responsible-roles/\[\]/role",
   _COMP + r"/status",
   _COMP + r"/title",
   _IMPL + r"/statements/\[\]/responses/\[\]/component",
   _COMPAT + r"/uuid",
   r"/kind",
   r"/label",
   r"/title/en")),
 (r"^lvg\.system-security-plan\.system-implementation\.(users|leveraged-authorizations)\[\]\.", CARRIED,
  (r"/authorizations/\[\]/date",
   r"/authorizations/\[\]/scope-label",
   _COMP + r"/authorizations(/.*)?",
   _COMP + r"/responsible-roles/\[\]/role",
   _SYS + r"/users/\[\]/privileges/\[\]/functions/\[\]",
   _SYS + r"/users/\[\]/privileges/\[\]/title",
   _SYS + r"/users/\[\]/uuid")),
 (r"^lev\.system-security-plan\.system-implementation\.users\[\]\.", CARRIED,
  (_COMP + r"/responsible-roles/\[\]/role",
   _SYS + r"/users/\[\]/privileges/\[\]/functions/\[\]",
   _SYS + r"/users/\[\]/privileges/\[\]/title",
   _SYS + r"/users/\[\]/uuid")),
 (r"^lev\.system-security-plan\.control-implementation\.", CARRIED,
  (r"/capabilities/\[\]/description/en",
   _COMP + r"/responsible-roles/\[\]/party-uuids/\[\]",
   _COMP + r"/responsible-roles/\[\]/role",
   _IMPL + r"/description/en",
   _IMPL + r"/remarks/en",
   _IMPL + r"/statements(/.*)?",
   _SYS + r"/customer-responsibilities/\[\]/capability",
   _SYS + r"/customer-responsibilities/\[\]/description",
   _SYS + r"/customer-responsibilities/\[\]/uuid",
   _COMPAT + r"/uuid",
   r"/parameter-bindings/ac-2_prm_1",
   r"/satisfied-by/\[\]/inherited-from/component-ref",
   r"/statement-refs/\[\]")),
 (r"^lvg\.system-security-plan\.control-implementation\.", CARRIED,
  (r"/capabilities/\[\]/description/en",
   _COMP + r"/responsible-roles/\[\]/party-uuids/\[\]",
   _COMP + r"/responsible-roles/\[\]/role",
   _IMPL + r"/description/en",
   _IMPL + r"/remarks/en",
   _IMPL + r"/statements(/.*)?",
   _COMPAT + r"/uuid",
   r"/parameter-bindings/ac-2_prm_1",
   r"/satisfied-by/\[\]/inherited-from/component-ref",
   r"/statement-refs/\[\]")),
 (r"^cdef\.component-definition\.(uuid$|metadata\.)", CARRIED, (r"/provenance(/.*)?",)),   # no value reaches this row: the first row of the map takes these paths
 (r"^cdef\.component-definition\.components\[\]\.protocols\[\]\.", CARRIED, (_PROT + r"/protocols(/.*)?",)),
 (r"^cdef\.component-definition\.components\[\]\.responsible-roles\[\]\.", CARRIED,
  (_COMP + r"/responsible-roles/\[\]/parties/\[\]",
   _COMP + r"/responsible-roles/\[\]/role")),
 (r"^cdef\.component-definition\.components\[\]\.control-implementations\[\]\.", CARRIED,
  (r"/capabilities(/.*)?",
   _COMP + r"/capabilities(/.*)?",
   _COMP + r"/control-implementations/\[\]/description/en",
   _COMP + r"/control-implementations/\[\]/source",
   _COMP + r"/control-implementations/\[\]/uuid",
   _COMP + r"/responsible-roles/\[\]/role")),
 (r"^cdef\.component-definition\.components\[\]\.(uuid|type|title|description|purpose)$", CARRIED,
  (_COMP + r"/description/en",
   _COMP + r"/purpose/en",
   _COMPAT + r"/uuid",
   r"/id",
   r"/kind",
   r"/label",
   r"/objects/\[\]/id",
   r"/title/en")),
]
_misaligned = held_rows_match(HELD, [r[0] for r in RULES])
def _held_row(path): return held_row(HELD, next((i for i, r in enumerate(RULES) if re.search(r[0], path)), None))
rows, unmapped = coverage(paths, RULES)
# global occurrence (measured, not declared): the path map above says where
# each source path is MEANT to go; this counts the source values that have an
# equal value SOMEWHERE in the output. It is an upper bound on what was
# carried and does not trace an occurrence to its destination (see
# oscal_conv_lib.global_occurrence).
VA = global_occurrence(list(led.docs.items()), list(bundle.objects.values()))

# the ledger: one entry per source value, each checked against the files just
# written. No drop is declared (the author's decisions of 2026-11-14: every
# drop the first ledger declared is carried now, or is no content by a rule
# the ledger checks - an orphaned back-matter resource, a type tag rebuilt
# from what its reference resolves to, a value equal to one that is kept).
LEDGER = led.account(bundle.out, {**bundle.objects, "content-manifest.json": manifest, ATTESTATION_FILE: attestation})
with open(os.path.join(OUTDIR, "ifa-conversion-ledger.json"), "w", encoding="utf-8") as f:
    json.dump(LEDGER, f, indent=1, ensure_ascii=False); f.write("\n")
LT = LEDGER["totals"]
# the path map held against the record by path, which is made for this check and not written
MAP_NOT_HELD = [_misaligned] if _misaligned else path_map_check(ledger_by_path(LEDGER)["paths"], _held_row)["sentences"]

types = collections.Counter(rel.split("/")[1] for rel in bundle.objects)
j = report(
    os.path.join(OUTDIR, "ifa-coverage-report.md"),
    os.path.join(OUTDIR, "ifa-coverage-report.json"),
    "IFA GoodRead lifecycle set -> Semantic Core: Coverage Report (computed)",
    f"Source: **OSCAL IFA GoodRead example set** (SSP v{V_SSP} + AP + AR + POA&M) + "
    f"leveraged/leveraging SSP pair + component-definition example (usnistgov/oscal-content; "
    f"FICTIONAL example content by NIST). Census: `drafts/gate-3-census.md` §4.",
    [f"- Objects emitted: " + ", ".join(f"{v} {k}" for k, v in sorted(types.items())) + ", and 1 attestation beside the manifest" +
     f" - the five lifecycle types and the Risk type (kernel 2.0.0) at document scale, manifest with both digests.",
     f"- Carried Requirements (closure): {', '.join(carried)} - byte-identical copies from the "
     f"US.SP800-53 bundle; an authorization package carries its baseline."],
    [f"- **SSP -> Component + Implementation**: by-component -> capability + satisfied-by; "
     f"5 set-parameters bind the REAL minted AC-6.1 ODPs (unresolved bindings: {unresolved_bind or 'none'}).",
     f"- **date-authorized -> Component.authorizations (with its `date`) + Attestation**: the ATO modeled as an "
     f"Attestation beside the manifest (`{ATTESTATION_FILE}`, not listed in it: D3.1). It binds the digest of the "
     f"manifest and the semantic digests of {{system Component, Implementation, AC-6.1}}; this script checks both "
     f"against what it wrote. Unsigned (no envelope). The validator reads it there and holds it to both "
     f"(`attestation-binds`, Appendix B.1.7; backlog #46).",
     f"- **Leveraged/leveraging pair -> D5 inheritance**: consumer Implementation satisfied-by "
     f"inherited-from{{csp-iaas, {AUTH_CSP}}} - basis-ref names the provider Component's authorization "
     f"(edge-local closure enforced by the validator); provider export.provided -> capabilities, "
     f"export.responsibilities -> customer-responsibilities.",
     f"- **AR + AP -> one Assessment**: AP activities/steps ride Assessment.method "
     f"(assessment-plan@1 payload); result not-satisfied from the finding target; observations "
     f"(AR + POA&M, deduped by uuid) -> observations@1 facet + landmark evidence URIs.",
     f"- **POA&M risks -> Risk objects (CP-RISK-1, kernel 2.0.0)**: statement -> `scenario`; "
     f"deadline -> `review-due` (datetime - OSCAL's type is date-time-with-timezone); POA&M system-id -> "
     f"`component-refs`; response `type` prop -> `treatment` (observed: "
     f"{', '.join(f'{k} x{v}' for k, v in sorted(response_types.items())) or 'none'}); the AR finding's "
     f"related-risks edge -> `treatments[]` (RISK-2 is modified by AC-6.1). likelihood/impact, the source "
     f"status and the response narrative -> risk-analysis@1 (the L2 holding pen for the parked stdlib facet).",
     f"- **POA&M risks -> Findings**: RISK-2 (open + planned remediation) -> state in-remediation with "
     f"actions[] (due = within-date-range.end); RISK-1 (status deviation-approved) -> approved "
     f"`risk-adjustment` Deviation (rationale = mitigating factor, approver = the SCA division URI) whose "
     f"`refs` name the Risk (RISK-9). Each Finding carries `risk-refs` to its Risk; the risk@1 framework "
     f"facet is retired.",
     f"- **Finding target `{target_obj}`** is a 53A OBJECTIVE id - it addresses into the sp800-53a@1 "
     f"facet of the carried AC-6.1 (kept in finding-target@1.target-objective-id; kernel statement-ref "
     f"stays statement-scoped).",
     f"- **Parties stay landmark** (#16, D22 0-of-3): performer/signer/approver are minted party URIs, "
     f"no party objects.",
     f"- **Payload free text language-tagged**: " + ", ".join(f"{k} x{v}" for k, v in sorted(lang_wraps.items())) + "."],
    [f"- **Statement-id respelling x{n_stmt_respell}** (source finding): the SSP pair writes "
     f"`ac-2_stmt.a` where the Rev 5 catalog writes `ac-2_smt.a` - same publisher, two spellings of "
     f"the same address; normalized to the catalog form. REPORTED upstream.",
     f"- **PUA codepoints x{n_pua}** (source finding): U+E0xx private-use characters embedded in IFA "
     f"SSP prose (ligature artifacts, e.g. 'so\\ue002ware') - carried verbatim, never patched. "
     f"REPORTED upstream.",
     f"- **Placeholder uuids x{uuid_placeholder}**: every export.provided/responsibility uuid in the "
     f"leveraged pair is 11111111-... - the provided-uuid dereference is degenerate in source; "
     f"inheritance wired via the authorization anchor instead.",
     f"- **Unresolved parameter bindings**: {unresolved_bind or 'none'}" +
     (f" - `ac-2_prm_1` is a Rev-5.1-era param id; Rev 5.2.0 declares the _odp layer instead "
      f"(the binding is carried verbatim; a resolver follows the odp@1 aggregates map)." if unresolved_bind else "."),
     # these sources are no catalogue, and they state a status on Components and Risks that no rule maps to a
     # lifecycle: the line says that
     lifecycle_default_line(LIFECYCLE_DEFAULT,
         why="the plans, the results and the POA&M of a system that is in operation describe what is in place",
         tail=f" The source states a status on {sum(1 for o in bundle.objects.values() if (o.get('facets') or {}).get(F_COMP, {}).get('status'))} "
         f"Components (component@1 `status`) and on {sum(1 for o in bundle.objects.values() if (o.get('facets') or {}).get(F_RISKA, {}).get('risk-status'))} "
         f"Risks (risk-analysis@1 `risk-status`, mapped to the Risk's `state`); no rule maps one of them to a lifecycle."),
     f"- **Orphaned back-matter resources x{len(ORPHANS)}** (not carried, by the ledger's rule: nothing in their "
     f"document refers to them): {', '.join(ORPHANS) or 'none'}.",
     f"- **Kind mapping**: " + (", ".join(f"{k} x{v}" for k, v in kind_mapped.items()) or "none") +
     f" (OSCAL free-text component types vs. the kernel's closed componentKind).",
     f"- **Global occurrence (measured; path coverage above is a DECLARATION)**: {VA['exact']:,} of "
     f"{VA['leaf-values']:,} source leaf values have an equal value of the same type somewhere in the emitted "
     f"objects. This is an **upper bound** on what was carried: all sources and all objects share one search "
     f"space, so one output value satisfies every equal source value, and a value dropped in one place is hidden "
     f"by an equal value in another. It does not trace an occurrence to its destination. Not counted: "
     f"{VA['key-only']} values that equal only an output key and {VA['embedded']} that occur only inside a longer "
     f"output text (candidates, to be argued per path). No equal value anywhere: "
     f"{VA['absent']['identity']} identity values (uuids/hrefs - re-minted as URIs by design), "
     f"{VA['absent']['document-metadata']} document-metadata values, and **{VA['absent']['content']} content "
     f"values ({VA['absent-content-prose']} of them prose of 40+ characters)** - each either transformed on "
     f"purpose (a mapped code, a respelled id) or DROPPED. That list is a **lower bound** on the losses, not "
     f"the complete work queue. `UNMAPPED: 0` sees none of this; the per-path lists, with the indexed pointer "
     f"of every value, are in the JSON report (`global-occurrence`; backlog #41).",
     f"- **Conversion ledger (measured per source value)**: each of the {LEDGER['leaf-values']:,} source leaf values "
     f"has one entry in `ifa-conversion-ledger.json` saying where it went. **{LT['copied']} copied** (the value "
     f"stands, with its type, at the destination named, read back from the written file), "
     f"**{LT['transformed']} transformed** (a named rule made the destination from it; the rule was applied to the "
     f"source again and compared), **{LT['not-content']} no content** (a name that only selects a field, a "
     f"namespace, an id that is rebuilt exactly - each by a rule the ledger checked), "
     f"**{LT['intentionally-dropped']} dropped for a declared reason**, "
     f"**{LT['unaccounted']} unaccounted**. Unlike the global figure above, an equal value elsewhere does not count: "
     f"a value is traced by what the converter did with it. Checks that failed: {len(LEDGER['verification-failures'])}. "
     f"A run with an unaccounted value or a failed check ends with exit code 1. The declared drops are listed by "
     f"reason at the end of this report: whether one of them is content is the author's decision, not the "
     f"converter's (2026-11-14: \"real content is never dropped\").",
     f"- **What OSCAL cannot give the Risk shape** (model findings, REPORTED; nothing is invented - the one derived value is the owner): " +
     "; ".join(f"{k} x{v}" for k, v in sorted(risk_gaps.items())) +
     f". Owner source: the SSP `owner` role -> {RISK_OWNER}.",
     *(f"- {n}" for n in findings_notes)],
    rows, unmapped,
    {"objects-emitted": dict(types), "carried-requirements": carried,
     "stmt-respell": n_stmt_respell, "pua-codepoints": n_pua,
     "placeholder-uuids": uuid_placeholder, "unresolved-bindings": unresolved_bind,
     "lang-wraps": dict(lang_wraps),
     "risk-shape-gaps": dict(risk_gaps), "response-types": dict(response_types),
     "global-occurrence": VA,
     "lifecycle-default": LIFECYCLE_DEFAULT,
     "ledger": {"file": "ifa-conversion-ledger.json", "leaf-values": LEDGER["leaf-values"], "totals": LT,
                "verification-failures": len(LEDGER["verification-failures"])}})
_by_reason, _by_rule = collections.defaultdict(list), collections.Counter()
for _e in LEDGER["entries"]:
    if _e["outcome"] == "intentionally-dropped": _by_reason[_e["reason"]].append(_e)
    if _e["outcome"] == "not-content": _by_rule[(_e["kind"], _e["rule"])] += 1
def _source_value(entry):
    tag, pointer = entry["source"].split("#", 1)
    node = led.docs[tag]
    for part in pointer.split("/")[1:]:
        part = part.replace("~1", "/").replace("~0", "~")
        node = node[int(part)] if isinstance(node, list) else node[part]
    text = json.dumps(node, ensure_ascii=False)
    return (text[:57] + "...") if len(text) > 60 else text
with open(os.path.join(OUTDIR, "ifa-coverage-report.md"), "a", encoding="utf-8") as f:
    f.write("\n## No content, by a rule the ledger checked (conversion ledger)\n\n"
            "| kind | rule | values |\n|---|---|---:|\n" +
            "".join(f"| {kind} | {rule} | {n} |\n" for (kind, rule), n in sorted(_by_rule.items())))
    f.write("\n## Declared drops (conversion ledger)\n\n"
            "A value that reached no destination and for which the converter states a reason. Whether a value "
            "of these is content, and must then be carried, is decided by the author; the converter only lists "
            "them. Pointers to every single value are in `ifa-conversion-ledger.json`.\n\n"
            "| values | paths | reason | first value |\n|---:|---:|---|---|\n" +
            "".join(f"| {len(es)} | {len({e['path'] for e in es})} | {why} | `{es[0]['source']}` = `{_source_value(es[0]).replace('|', '/')}` |\n"
                    for why, es in sorted(_by_reason.items(), key=lambda kv: (-len(kv[1]), kv[0]))))
    f.write("\n## Unaccounted source values (conversion ledger)\n\n"
            "No destination, no rule and no declared reason. A run that lists a value here ends with exit code 1. "
            "Pointers to every single value are in `ifa-conversion-ledger.json`.\n\n"
            "| path | count | first value |\n|---|---:|---|\n" +
            "".join(f"| `{u['path']}` | {u['count']} | `{u['pointers'][0]}` |\n" for u in LEDGER["unaccounted-paths"]))
print(f"objects: {sum(types.values())} {dict(types)}")
print(f"leaves: {j['totals']['leaf-values']:,}  mapped: {j['totals']['mapped']:,}  "
      f"UNMAPPED: {j['totals']['unmapped']}")
print(f"global occurrence: {VA['exact']}/{VA['leaf-values']} exact (upper bound); key-only {VA['key-only']}, "
      f"embedded {VA['embedded']}; absent content values: {VA['absent']['content']} ({VA['absent-content-prose']} prose)")
print(f"ledger: copied {LT['copied']}, transformed {LT['transformed']}, no content {LT['not-content']}, dropped for a "
      f"declared reason {LT['intentionally-dropped']}, unaccounted {LT['unaccounted']}; "
      f"failed checks {len(LEDGER['verification-failures'])}")
print(f"respell: {n_stmt_respell}  pua: {n_pua}  placeholder-uuids: {uuid_placeholder}  "
      f"unresolved-bindings: {unresolved_bind}")
if unmapped:
    for p, n in unmapped[:40]: print("  UNMAPPED", p, "x", n)
# last: a run whose ledger has a claim that does not hold or an unaccounted value ends with 1. Everything
# above is written by then, so that the folder says why.
if MAP_NOT_HELD:
    for x in MAP_NOT_HELD: print("  PATH MAP NOT HELD", x, file=sys.stderr)
    sys.stdout.flush()
    raise SystemExit(f"convert_ifa.py: {len(MAP_NOT_HELD)} disagreement(s) between the path map and the record of this run: "
                     f"a value has an outcome its row does not allow, or stands at a place its row does not name")
ledger_gate(LEDGER, "convert_ifa.py")
